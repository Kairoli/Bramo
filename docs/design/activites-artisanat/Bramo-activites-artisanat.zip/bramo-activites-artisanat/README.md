# Bramo — Activités et artisanat

Complément de conception v0.1, 22 octobre 2026. **Aucun changement du jeu : les fichiers sont des propositions.**

## Lire

- **Bramo-activites-artisanat.html** : dossier autonome, navigation, calculateur de recette et illustration de la pente solo. Aucun serveur ni téléchargement requis pour le lire.
- **Bramo-activites-artisanat.md** : texte complet à donner à Claude, 21 chapitres.
- Le ZIP contient les deux versions et les données/outils ci-dessous.

Base de catalogue : `Kairoli/Bramo` à `cfa4b9e7c1be88e9578c7100874335bdb3fe2447`. Relecture finale des décisions de combat dans `integration.md` à `5077fa79e285eadc4e4583072a1cb3c9eff4c8aa`. Ne pas revenir sur `combat-voies-v1` ni le réappliquer une deuxième fois.

## Données

| Fichier | Usage |
|---|---|
| `proposition.json` | Paramètres, paliers, 28 patrons, 12 zones, activités et fournitures |
| `recettes-resolues.json` | 4 293 propositions : 717 classiques et 3 576 variantes d’ensemble |
| `preparations.json` | 122 recettes de préparation et 107 sources, dont 30 vestiges régionaux |
| `audit-catalogue.json` | Statut des 769 modèles actuels ; 52 exclusions explicites |
| `fournitures.json` | Huit fournitures d’activité et sources supplémentaires |
| `references-catalogue.json` | Capture de travail des modèles/ensembles utilisés pour régénérer, pas une sauvegarde à importer dans le jeu |
| `sources.json` | Commit, empreintes des sources et relecture finale |
| `verification.json` | 20 contrôles de données et coûts de sept chaînes explicitement hypothétiques |
| `verification-html.json` | 14 contrôles DOM ; aucune certification de rendu graphique |

Les identifiants de matière comme `metal_t40` sont des identifiants de conception, avec certains alias vers les données existantes. Les sorties `proposal_*` n’existent pas encore dans le jeu. **Ne pas importer les JSON dans `data/` sans adaptation des modèles, références et schémas.** La partie recettes ne crée pas des milliers de nouveaux effets ou de nouveaux dessins : elle déplie un petit nombre de patrons.

## Régénérer les données et le Markdown

Python 3, bibliothèque standard seulement, sans réseau ni dépôt voisin :

```bash
python3 generer.py
```

Cette commande écrase les données dérivées et le Markdown à partir des scripts, de `references-catalogue.json`, de `fournitures.json` et de `dossier-source.md`. Pour modifier durablement une règle, modifier sa source, puis régénérer. La capture de catalogue reste figée sur le commit documenté.

Contrôles seuls :

```bash
python3 verifier.py
```

## Régénérer le HTML

Node.js et les deux dépendances déclarées dans `package.json` :

```bash
npm install
npm run render
npm run check:html
```

Le fichier HTML déjà livré ne nécessite aucune de ces commandes pour être lu. `rendre.mjs` et `verifier_html.cjs` ont un chemin de secours vers les dépendances de l’environnement de création ; une installation locale de `marked` et `linkedom` est prioritaire et suffit sur une autre machine.

Un contrôle Playwright est fourni dans `verifier_visuel.cjs`, avec installation de Playwright et de Chromium à prévoir. Il n’a pas pu être exécuté avec succès dans l’environnement de création, faute de navigateur disponible et de téléchargement exploitable. Il n’existe donc pas de captures ou de validation mobile/bureau annoncées comme réussies.

## Portée des résultats

- Les contrôles ne lancent **aucun combat**.
- Les coûts de chaînes ne simulent ni prix, ni demande, ni marché, ni bonus, ni chef-d’œuvre.
- Les affinités des zones, les formules de scaling et les rendements de loot sont à éprouver dans le moteur réel.
- Les activités collectives, les groupes de quatre et le classement de clan ne sont pas implémentés.
- Les décisions nouvelles doivent être arbitrées avec Louis, puis intégrées progressivement avec le moteur et les données actuelles.
