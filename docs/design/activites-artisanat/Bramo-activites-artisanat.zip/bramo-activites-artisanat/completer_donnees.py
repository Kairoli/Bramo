from pathlib import Path
import json,math
R=Path(__file__).resolve().parent
D=json.loads((R/'proposition.json').read_text())
# Les matières finales symboliques sont toutes reliées à une transformation ou à une collecte.
prep=[];raw={}
def source(id,name,job,level,seconds,alias=None):
 raw[id]=dict(id=id,name=name,profession=job,level=level,seconds_per_unit=seconds,existing_alias=alias,status='existing_alias_or_new_gathering_proposal')
 return id
def tr(id,job,level,seconds,inputs,qty=1,alias=None,variant='default'):
 prep.append(dict(id='prepare_'+id+'_'+variant,output=id,profession=job,level=level,seconds=seconds,inputs=inputs,quantity=qty,existing_alias=alias,variant=variant))
orealias=['copper_ore','iron_ore','iron_ore','iron_ore','mithril_ore','mithril_ore','orichalcum_ore','azurite_ore','umbral_ore','astralite_ore']
woodalias=['pine_log','oak_log','ash_log','yew_log','moonwood_log',None,None,None,None,None]
herbalias=['mint','thyme','nettle_root','sage','lantern_lily',None,'frost_flower',None,None,None]
oresecs=[12,14,14,14,20,20,24,26,28,30]
coal=source('raw_coal','Charbon','mining',20,16,'coal');bark=source('raw_bark','Écorce','woodcutting',1,12,'bark');sand=source('raw_sand','Sable','mining',1,12,'sand')
copper=source('raw_copper','Minerai de cuivre','mining',1,12,'copper_ore');tin=source('raw_tin','Minerai d’étain','mining',1,12,'tin_ore');silver=source('raw_silver','Minerai d’argent','mining',30,18,'silver_ore');gold=source('raw_gold','Minerai d’or','mining',50,22,'gold_ore')
for i,t in enumerate(D['tiers']):
 L=t['level'];sec=12+2*i
 ore=source(f'raw_ore_t{L}',t['metal']+' : minerai principal','mining',L if L not in [20,30,50] else {20:10,30:10,50:40}[L],oresecs[i],orealias[i])
 wood=source(f'raw_wood_t{L}',t['wood']+' brut','woodcutting',L,sec,woodalias[i])
 hide=source(f'raw_hide_t{L}','Peau du grade '+str(L),'hunting',L,sec)
 fiber=source(f'raw_fiber_t{L}','Fibre du grade '+str(L),'herbalism',L,sec)
 herb=source(f'raw_herb_t{L}','Herbe du grade '+str(L),'herbalism',L,sec,herbalias[i])
 gemstone=source(f'raw_gem_t{L}',t['gem']+' brut','mining',35 if L==30 else L,60,'rough_amethyst' if L==30 else None)
 rune=source(f'raw_rune_t{L}','Pierre runique du grade '+str(L),'mining',max(20,L),sec,'rune_stone' if L in [1,10,20] else None)
 if L==1: mi={copper:1,tin:1};mt=8
 elif L==10: mi={ore:2};mt=10
 elif L==20: mi={ore:2,coal:2};mt=12
 elif L==30: mi={ore:2,coal:3};mt=14
 elif L==50: mi={ore:2,coal:2};mt=18
 else: mi={ore:2,coal:1};mt=12+2*(i-4)
 tr(f'metal_t{L}','smithing',L,mt,mi,alias={1:'bronze_bar',10:'iron_bar',20:'steel_bar'}.get(L))
 tr(f'wood_t{L}','carpentry',L,8+2*i,{wood:1},alias={1:'pine_plank',10:'oak_plank'}.get(L))
 tr(f'leather_t{L}','tanning',L,30,{hide:1,bark:2})
 tr(f'leather_t{L}','tanning',L,15,{hide:1,'tannin_extract':1},variant='fast')
 tr(f'thread_t{L}','tailoring',L,8,{fiber:1},2)
 tr(f'cloth_t{L}','tailoring',L,16,{f'thread_t{L}':4})
 if L<=20: pi={copper:2};pt=12 if L==1 else 14 if L==10 else 16
 elif L==30: pi={silver:2};pt=12
 elif L==40: pi={silver:2,rune:1};pt=14
 elif L==50: pi={gold:2};pt=12
 elif L==60: pi={gold:2,rune:2};pt=16
 elif L==70: pi={gold:1,silver:1};pt=16
 else: pi={gold:1,silver:1,ore:1};pt=20
 tr(f'precious_t{L}','jewelcrafting',L,pt,pi)
 tr(f'gem_t{L}','jewelcrafting',L,60,{gemstone:1})
 tr(f'ink_t{L}','alchemy',min(L,20),40,{herb:4,coal:2},2)
 tr(f'atelier_powder_t{L}','alchemy',min(L,20),10,{sand:2,herb:1},2)
 tr(f'memory_binder_t{L}','enchanting',20,45,{rune:4,f'ink_t{L}':2,f'atelier_powder_t{L}':1})
 tr(f'runic_core_t{L}','enchanting',20,45,{rune:4,f'ink_t{L}':2})
tr('raw_coal','smithing',1,8,{'raw_wood_t1':2},1,variant='charcoal')
tr('tannin_extract','alchemy',10,20,{bark:4,'raw_herb_t1':1},4)
# Reliquats régionaux : sorties de rencontre, pas ressources accessibles par collecte de métier.
for base,name in D['regional_materials'].items():
 for L in [40,50,60,70,80,90]:
  raw[f'{base}_t{L}']=dict(id=f'{base}_t{L}',name=f'{name} · {L}',profession=None,level=L,seconds_per_unit=None,status='renewable_encounter_material',units_per_reference_victory=2)
zones=[
('lantern_road','La Chaussée des lanternes','outskirts','Une cible résistante prépare des coups espacés ; un porteur fragile renforce brièvement sa garde.','Dégâts soutenus ou priorité sur le porteur.','Ralentir les coups et ouvrir une Rupture.','Tenir les coups puis utiliser sa conversion offensive.','DPS','Pas de chronomètre de rage plus court que les autres zones.','stoneback'),
('gray_ditches','Les Fossés gris','outskirts','Une érosion faible s’accumule jusqu’à trois charges et expire ; une purification la retire.','Abréger l’exposition, garder une réponse de survie.','Réduire les coups qui posent l’érosion.','Récupérer pendant les intervalles et purifier.','Soutien','Jamais de réduction totale des soins ni de charge permanente.','marsh_collector'),
('three_blows','La Cour des trois coups','old_bastion','Deux coups ordinaires puis un coup renforcé annoncé ; longue récupération.','Conclure dans la récupération, garder un bouton défensif automatique.','Préparer la Rupture ou l’affaiblissement.','Placer une garde ou récupérer entre les coups.','Contrôle / soutien','Un coup correctement préparé ne devient pas létal sans alternative.','bastion_warden'),
('glass_orchard','Les Vergers de verre','watcher_wood','Deux renforts fragiles arrivent à des moments fixes, sans rendre le chef invulnérable.','Dégâts répartis ou poursuite du chef.','Neutraliser les renforts pendant la poursuite.','Absorber les renforts avec une offense adaptée.','DPS / contrôle','Nombre de renforts borné ; pas de croissance infinie de cibles.','cinder_stag'),
('balance_cloister','Le Cloître des balances','sunken_archive','Une garde renouvelée se dissipe, s’use ou expire ; la fin laisse une ouverture.','User la garde ou préparer ses gros impacts.','Dissiper, rompre ou affaiblir la transition.','Attendre la fenêtre en limitant les pertes.','Contrôle','Aucune immunité totale aux petits coups.','tide_notary'),
('reheat_furnace','Les Fours de recuit','old_forges','Exposition régulière et lourde charge ; une protection réellement utilisée aide à ouvrir la fenêtre suivante.','Passer la charge avec un outil défensif puis accélérer.','Affaiblir la charge et profiter de la Rupture.','Transformer une absorption réelle en poursuite.','Soutien','Une garde commune suffit à bénéficier de la règle ; pas de contrôle de voie.','furnace_keeper'),
('echo_hall','La Salle des échos','sunken_archive','Alternance de périodes de garde et de vulnérabilité assez longues ; les attaques ordinaires continuent.','Choisir la cadence qui exploite les périodes ouvertes.','Maintenir une pression utile entre les fenêtres.','Protéger pendant la garde puis convertir son aide.','Mixte','Aucun silence qui invalide les lanceurs ; pas de réglage à la demi-seconde.','archive_witness'),
('wound_ford','Le Gué des plaies','old_bastion','Un éclat périodique laisse une affliction courte ; une purification aide sans être indispensable.','Prévoir une défense puis raccourcir le combat.','Affaiblir les sources de dégâts directs.','Réparer l’érosion et choisir la bonne protection.','Soutien','Affliction bornée ; un build sans soin peut répondre par garde et vitesse.','glass_custodian'),
('two_seals','La Chambre aux deux sceaux','watcher_wood','Deux adversaires alternent le soutien de leur garde ; tous deux restent vulnérables.','Répartir les dégâts ou concentrer une proie.','Empêcher un soutien et ouvrir la seconde cible.','Tenir les deux puis gagner par poursuite.','DPS','Pas de mort simultanée obligatoire ni de résurrection automatique.','hollow_huntsman'),
('watch_terraces','Les Terrasses de la vigie','old_forges','Une frappe de cloche précède une garde courte ; la Stabilité ouvre une fenêtre offensive.','Préparer ses dégâts après la garde, absorber un choc.','Produire une Rupture quand elle compte.','Amortir la frappe et convertir la garde en attaque.','Contrôle','Le plafond de ralentissement du boss reste inchangé.','iron_bell'),
('bad_day_workshop','L’Atelier des mauvais jours','threewind_rift','Un auxiliaire soigne au plus trois fois ou renforce une défense finie, selon la variante annoncée.','Priorité sur l’auxiliaire ou débit offensif.','Interrompre, rompre ou dissiper.','Dépasser le soutien fini de l’ennemi sans mourir.','DPS / contrôle','Réserve de soin finie ; aucun mur de régénération perpétuelle.','rift_sentinel'),
('threewind_belvedere','Le Belvédère des trois vents','threewind_rift','Deux règles des zones précédentes, annoncées avant l’étape, sur un calendrier fixe.','Assembler poursuite et une réponse de sécurité.','Choisir les menaces à affaiblir.','Protéger les pics et conserver assez de dégâts.','Mixte','Deux règles au plus, choisies dans une liste de combinaisons validées.','wind_regent')]
# Le dernier identifiant du Régent peut différer du catalogue : conserver la référence réelle.
old=json.loads((R/'references-catalogue.json').read_text())['design']; bossids={b['id'] for b in old['bosses']}
for z in zones:
 if z[-1] not in bossids:
  candidates=[b for b in old['bosses'] if 'Régent' in b['name']]
  if z[0]=='threewind_belvedere' and candidates:
   z=list(z);z[-1]=candidates[0]['id']
  else: raise ValueError(z[-1])
 D.setdefault('solo_zones',[]).append(dict(zip(['id','name','region','mechanic','dps_response','control_response','support_response','favored_role','guardrail','boss'],z)))
D['dungeon']['classic_expected_per_route']=D['dungeon'].pop('classic_probability_per_route')
D['dungeon']['set_cache_expected_per_route']=D['dungeon'].pop('set_cache_probability_per_route')
D['dungeon']['pity_scope']='Each notable room has its own eligible boss target; three credits across three sources, never three for a single boss absent from the other rooms.'
D['clan']['points_per_stage']=1000
D['clan']['maximum_integrity_bonus']=100
D['clan']['maximum_secondary_bonus']=50
D['raw_sources']=list(raw.values());D['preparations']=prep
(R/'proposition.json').write_text(json.dumps(D,ensure_ascii=False,indent=2)+'\n')
(R/'preparations.json').write_text(json.dumps(dict(raw_sources=list(raw.values()),recipes=prep),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(zones=len(D['solo_zones']),preparations=len(prep),raw_sources=len(raw)),ensure_ascii=False))
