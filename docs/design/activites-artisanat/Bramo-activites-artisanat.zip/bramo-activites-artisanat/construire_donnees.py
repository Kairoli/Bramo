from pathlib import Path
import json, math, collections
ROOT=Path(__file__).resolve().parent
REF=json.loads((ROOT/'references-catalogue.json').read_text())
P=REF['design']
MODELS=REF['models']
GEAR=REF['gear']
def save(name,obj): (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
# Proposition, non chargée par le jeu. Les noms nouveaux restent explicitement proposés.
tiers=[]
metals=['Bronze','Fer','Acier','Acier trempé','Mithril','Mithril renforcé','Orichalque','Azurite','Sombracier','Astralite']
woods=['Pin','Chêne','Frêne','If','Bois de lune','Charme','Cèdre','Ébène','Bois d’ombre','Bois d’aurore']
leathers=['Cuir brut','Cuir souple','Cuir renforcé','Cuir de lande','Cuir de veille','Cuir de voyage','Cuir lamellaire','Cuir de rafale','Cuir nocturne','Cuir astral']
cloths=['Toile de lin','Lin serré','Sergé de lin','Toile de chanvre','Toile de coton','Coton croisé','Soie végétale','Toile des brumes','Étoffe nocturne','Étoffe d’aurore']
precious=['Cuivre','Cuivre poli','Cuivre ciselé','Argent','Argent pur','Or','Or pur','Électrum','Électrum sombre','Électrum astral']
gems=['Quartz','Quartz clair','Agate','Améthyste','Opale','Topaze','Saphir','Aigue-marine','Onyx','Cristal astral']
for i,L in enumerate([1,10,20,30,40,50,60,70,80,90]):
 tiers.append(dict(level=L,quantity_factor=[1,1.25,1.5,1.75,2,2.25,2.5,2.75,3,3.5][i],time_factor=1+0.1*i,metal=metals[i],wood=woods[i],leather=leathers[i],cloth=cloths[i],precious=precious[i],gem=gems[i]))
rarities=[dict(id='common',name='Commun',materials=1,time=1,powder=0),dict(id='rare',name='Rare',materials=1.35,time=1.25,powder=1),dict(id='epic',name='Épique',materials=1.8,time=1.6,powder=2),dict(id='legendary',name='Légendaire',materials=2.6,time=2.2,powder=4)]
# Entrées = matériaux préparés, jamais une poignée d'objets dans un sac magique.
bases=[]
def b(key,name,job,mins,**inputs): bases.append(dict(id=key,name=name,profession=job,minutes=mins,inputs=inputs))
for slot,name,metal,leather,cloth,mins in [('head','Coiffe métallique',10,2,0,4),('torso','Plastron',18,4,2,8),('hands','Gantelets',6,2,0,3),('legs','Jambières',14,3,2,6),('feet','Bottes ferrées',8,2,0,3)]: b('metal_'+slot,name,'smithing',mins,metal=metal,leather=leather,cloth=cloth)
for slot,name,leather,cloth,metal,mins in [('head','Capuche de cuir',8,2,1,4),('torso','Pourpoint',16,4,2,8),('hands','Gants de cuir',5,2,1,3),('legs','Chausses de cuir',12,3,2,6),('feet','Bottes de cuir',7,2,1,3)]: b('leather_'+slot,name,'tanning',mins,leather=leather,cloth=cloth,metal=metal)
for slot,name,cloth,leather,mins in [('head','Coiffe textile',8,1,4),('torso','Robe',18,2,8),('hands','Mitaines',6,1,3),('legs','Pantalon textile',14,2,6),('feet','Chaussures textiles',8,2,3)]: b('cloth_'+slot,name,'tailoring',mins,cloth=cloth,leather=leather)
b('cape','Cape','tailoring',4,cloth=10,leather=2)
b('belt','Ceinture','tanning',3,leather=6,metal=2)
b('ring','Anneau','jewelcrafting',4,precious=4,gem=1)
b('necklace','Collier','jewelcrafting',5,precious=6,gem=1,leather=1)
b('hammer','Marteau','smithing',8,metal=16,wood=4,leather=2)
b('sword_shield','Épée et bouclier','smithing',10,metal=18,wood=6,leather=3)
b('axe','Hache','smithing',8,metal=14,wood=3,leather=2)
b('longbow','Arc','carpentry',8,wood=20,thread=4,leather=2)
b('crossbow','Arbalète','carpentry',10,wood=18,metal=6,thread=4,leather=2)
b('daggers','Dagues','smithing',8,metal=12,wood=2,leather=2)
b('staff','Bâton','carpentry',8,wood=20,gem=2,thread=2)
b('scepter','Sceptre','jewelcrafting',8,precious=12,wood=4,gem=1)
b('grimoire','Grimoire','enchanting',8,cloth=4,leather=6,wood=2,ink=2)
base_by={x['id']:x for x in bases}
weights={'head':.8,'torso':1.4,'hands':.6,'legs':1,'feet':.6,'cape':.6,'belt':.6,'necklace':.7,'ring':.5,'weapon':1.6}
regional_by={'old_forges':'scorie_de_memoire','watcher_wood':'ambre_de_veille','sunken_archive':'encre_fossile','old_bastion':'eclat_de_serment','threewind_rift':'quartz_de_faille'}
regional_names={'scorie_de_memoire':'Scorie de mémoire','ambre_de_veille':'Ambre de veille','encre_fossile':'Encre fossile','eclat_de_serment':'Éclat de serment','quartz_de_faille':'Quartz de faille'}
set_units={'head':4,'torso':6,'hands':3,'legs':5,'feet':3,'cape':3,'belt':3,'necklace':3,'ring':2,'weapon':6}
def base_key(item):
 slot=item['slot'];fam=item['family']
 if slot in ['cape','belt','ring','necklace']: return slot
 if slot=='weapon': return fam
 prefix={'armor':'metal','cuirass':'metal','trail':'leather','robe':'cloth'}[fam]
 return prefix+'_'+slot

def resolve(key,L,rarity,slot,set_id=None):
 t=next(x for x in tiers if x['level']==L);q=next(x for x in rarities if x['id']==rarity);base=base_by[key]
 primary = {'metal'} if key.startswith('metal_') else {'leather'} if key.startswith('leather_') else {'cloth'} if key.startswith('cloth_') else {'cape':{'cloth'},'belt':{'leather'},'ring':{'precious','gem'},'necklace':{'precious','gem'},'hammer':{'metal'},'sword_shield':{'metal'},'axe':{'metal'},'daggers':{'metal'},'longbow':{'wood'},'crossbow':{'wood'},'staff':{'wood','gem'},'scepter':{'precious','gem'},'grimoire':{'leather','ink'}}[key]
 inputs={f'{k}_t{L if k in primary else 1}':math.ceil(v*t['quantity_factor']*q['materials']) for k,v in base['inputs'].items() if v}
 if q['powder']: inputs[f'atelier_powder_t{L}']=math.ceil(q['powder']*weights[slot])
 if set_id:
  st=next(x for x in P['sets'] if x['id']==set_id)
  inputs[regional_by[st['source']]+f'_t{L}']=math.ceil(set_units[slot]*(1.5 if rarity=='legendary' else 1))
  inputs[f'memory_binder_t{L}']=2 if rarity=='legendary' else 1
 seconds=math.ceil(base['minutes']*60*t['time_factor']*q['time'])
 return dict(base=key,profession=base['profession'],level=L,rarity=rarity,duration_seconds=seconds,inputs=inputs,output_quantity=1,set_id=set_id)
resolved=[];audit=[]
namednames={x['name'] for x in P['named_items']}
for g in GEAR:
 reasons=[]
 if g.get('starter'): reasons.append('starter_not_craftable')
 if g.get('set'): reasons.append('legacy_set_requires_migration')
 if g['name'] in namednames: reasons.append('named_name_collision_requires_migration')
 if reasons:
  audit.append(dict(model_id=g['id'],name=g['name'],status='excluded_pending_migration',reasons=reasons));continue
 key=base_key(g);r=resolve(key,g['tier'],g['rarity'],g['slot']);r.update(id='recipe_'+g['id'],output_model_id=g['id'],scope='existing_classic_proposal',name=g['name'],slot=g['slot'])
 resolved.append(r);audit.append(dict(model_id=g['id'],name=g['name'],status='recipe_proposed',recipe_id=r['id']))
for m in MODELS:
 for L in [40,50,60,70,80,90]:
  for rarity in ['epic','legendary']:
   key=base_key(m);r=resolve(key,L,rarity,m['slot'],m['set_id']);r.update(id=f"recipe_set_{m['id']}_t{L}_{rarity}",output_model_id=f"proposal_{m['id']}_t{L}_{rarity}",scope='new_set_proposal',name=m['name'],slot=m['slot'],canonical_piece=m['canonical_piece'])
   resolved.append(r)
# Ce catalogue en français est une proposition de contenu : pas un format importable tel quel dans data/.
D=dict(version='0.1-proposition',date='2026-10-22',source_commit='cfa4b9e7c1be88e9578c7100874335bdb3fe2447',status='design_not_implemented_not_economically_balanced',tiers=tiers,rarities=rarities,base_recipes=bases,slot_weights=weights,set_extra_units=set_units,regional_materials=regional_names,set_sources=[dict(id=s['id'],name=s['name'],region=s['source']) for s in P['sets']],normal_loot=dict(reference_seconds=360,classic_probability=.20,set_cache_probability=.10,named_target_probability=.05,named_pity_clears=20,gold=0,regional_vestiges=2,rift_exchange_rate=4),dungeon=dict(party_sizes=[1,2,3,4],daily_limit=None,slots=6,rests_seconds=15,squad_contract_seconds=14400,assistance_slots_per_owner=1,simultaneous_owner_jobs=1,complete_route_reference_seconds=1080,classic_probability_per_route=.60,set_cache_probability_per_route=.30,named_target_probability_per_route=1-.95**3,pity_credits_per_route=3,regional_vestiges_per_route=6),solo=dict(name='La Route des Lointains',zones_per_circuit=12,stages_per_zone=10,stages_per_circuit=120,permanent_reset=False,reward_scope='account_stage_once',scaling_anchor=120,hp_factor_per_stage=1.012,damage_factor_per_stage=1.008,fight_limit_seconds=240,combat_power_bonus_cap=.03,economic_bonus_default=0),world=dict(name='La Veille des Géants',window_hours=72,assault_minutes=10,personal_reward_minutes=60,respawn_seconds=60,party_max=4,rank_rewards='cosmetic_only'),clan=dict(name='Les Routes franches',divisions=[3,6,12],counted_orders_per_player=6,order_minutes=20,rank_rewards='cosmetic_only'))
save('proposition.json',D);save('recettes-resolues.json',resolved);save('audit-catalogue.json',audit)
# Provenance réutilisable, pas de copie de code du jeu.
save('sources.json',REF['source_manifest'])
print(json.dumps(dict(bases=len(bases),recipes=len(resolved),existing_recipes=sum(x['scope']=='existing_classic_proposal' for x in resolved),new_set_recipes=sum(x['scope']=='new_set_proposal' for x in resolved),audit=collections.Counter(x['status'] for x in audit),exclusion_reasons=collections.Counter(y for x in audit for y in x.get('reasons',[]))),ensure_ascii=False))
