from pathlib import Path
import json
R=Path(__file__).resolve().parent
D=json.loads((R/'proposition.json').read_text());V=json.loads((R/'verification.json').read_text());REC=json.loads((R/'recettes-resolues.json').read_text())
J={'smithing':'Forge','tanning':'Tannerie','tailoring':'Couture','carpentry':'Menuiserie','jewelcrafting':'Joaillerie','enchanting':'Enchantement'}
N={'metal':'Métal','wood':'Bois préparé','leather':'Cuir','cloth':'Tissu','thread':'Fil','precious':'Métal précieux','gem':'Gemme taillée','ink':'Encre'}
def table(cols,rows):
 return '\n'.join(['| '+' | '.join(cols)+' |','| '+' | '.join('---' for x in cols)+' |']+['| '+' | '.join(str(c).replace('|','/') for c in row)+' |' for row in rows])
def fr(x): return str(round(x,2)).replace('.',',')
s=(R/'dossier-source.md').read_text()
s=s.replace('<!-- TABLE_BASE_RECIPES -->',table(['Patron','Métier','Matières de base','Finition de base'],[[b['name'],J[b['profession']],', '.join(f'{q} {N[k].lower()}' for k,q in b['inputs'].items() if q),f"{b['minutes']} min"] for b in D['base_recipes']]))
s=s.replace('<!-- TABLE_TIERS -->',table(['Palier','Métal','Bois','Cuir','Tissu','Bijou / pierre','Facteur de quantité','Facteur de temps'],[[t['level'],t['metal'],t['wood'],t['leather'],t['cloth'],t['precious']+' / '+t['gem'],fr(t['quantity_factor']),fr(t['time_factor'])] for t in D['tiers']]))
examples=[]
for key in ['metal_torso','leather_torso','cloth_torso','hammer','crossbow','scepter','ring']:
 r=next(x for x in REC if x['base']==key and x['level']==40 and x['rarity']=='epic' and x['set_id'])
 b=next(x for x in D['base_recipes'] if x['id']==key)
 main=[]
 for k,q in r['inputs'].items():
  base=k.rsplit('_t',1)[0]
  if base in N:main.append(f'{q} {N[base].lower()} ({k.rsplit("_t",1)[1]})')
 examples.append([b['name']+' · 40 Épique',', '.join(main),J[r['profession']],f"{r['duration_seconds']//60} min {r['duration_seconds']%60:02} s"])
s=s.replace('<!-- TABLE_RESOLVED_EXAMPLES -->',table(['Exemple de pièce d’ensemble','Matières préparées ; grade entre parenthèses','Dernier métier','Finition seule'],examples))
s=s.replace('<!-- TABLE_SOLO_ZONES -->',table(['Zone','Mécanique','DPS','Contrôle','Soutien','Affinité recherchée'],[[str(i+1)+'. '+z['name'],z['mechanic'],z['dps_response'],z['control_response'],z['support_response'],z['favored_role']] for i,z in enumerate(D['solo_zones'])]))
mark='Les petits calculs de chaînes ne constituent pas une économie simulée'
cost=table(['Pièce d’ensemble 40 Épique','Chaîne ordinaire avec finition','Vestiges à cadence de référence','Total autonome de référence'],[[next(b['name'] for b in D['base_recipes'] if b['id']==x['base']),fr(x['ordinary_chain_minutes'])+' min',fr(x['regional_reference_minutes'])+' min',fr(x['total_reference_minutes'])+' min'] for x in V['chain_examples']])
s=s.replace(mark,cost+'\n\nCes coûts additionnent les étapes d’un autonome, avec les fibres sauvages et le tannage lent ; ils ne décrivent pas le délai d’une commande passée au marché. L’Agriculture en parallèle peut modifier la chaîne textile. Les sept exemples n’établissent pas l’équilibre de tous les grades.\n\n'+mark)
s=s.replace('Les vérifications locales couvrent','Les **'+str(V['checks_count'])+' vérifications locales** couvrent')
if '<!-- TABLE_' in s:raise AssertionError('table non rendue')
(R/'Bramo-activites-artisanat.md').write_text(s)
print(json.dumps({'words':len(s.split()),'bytes':len(s.encode()),'tables':s.count('| ---')}))
