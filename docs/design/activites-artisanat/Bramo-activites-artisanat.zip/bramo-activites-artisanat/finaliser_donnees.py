from pathlib import Path
import json
R=Path(__file__).resolve().parent
D=json.loads((R/'proposition.json').read_text());D.update(json.loads((R/'fournitures.json').read_text()))
D['normal_loot']['reference_weight_milli']=1000
D['normal_loot']['fractional_weight_policy']='Use encounter reference weight; no per-monster copy of full-unit rates. Partial-unit direct probability: 1-(1-p)^weight. Pity stores integer milliunits and resolves thresholds once.'
D['normal_loot']['ordinary_materials_from_repeat_combat']=0
D['exclusions_are_intentional']=True
(R/'proposition.json').write_text(json.dumps(D,ensure_ascii=False,indent=2)+'\n')
