from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
for f in ['construire_donnees.py','completer_donnees.py','finaliser_donnees.py','verifier.py','ecrire_dossier.py']:
 subprocess.run([sys.executable,str(r/f)],check=True)
