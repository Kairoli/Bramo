"""Contrôles de conception : références, conservation des grades et calculs explicites.
Ne lance aucun combat et ne prédit aucun prix de marché.
"""
from pathlib import Path
import json,math,collections
R=Path(__file__).resolve().parent
D=json.loads((R/'proposition.json').read_text());REC=json.loads((R/'recettes-resolues.json').read_text());AUD=json.loads((R/'audit-catalogue.json').read_text())
P=json.loads((R/'preparations.json').read_text())
checks=[]
def check(name,condition,detail):
 checks.append(dict(name=name,ok=bool(condition),detail=detail))
 if not condition: raise AssertionError(name+': '+str(detail))
check('Catalogue examiné sans omission',len(AUD)==769 and len({a['model_id'] for a in AUD})==769,{'total':len(AUD),'statuses':dict(collections.Counter(a['status'] for a in AUD))})
check('Les départs liés et anciennes familles sont explicitement exclus',all(a['status']!='recipe_proposed' for a in AUD if 'starter_not_craftable' in a.get('reasons',[]) or 'legacy_set_requires_migration' in a.get('reasons',[])),dict(collections.Counter(r for a in AUD for r in a.get('reasons',[]))))
check('Les recettes sont uniques',len({r['id'] for r in REC})==len(REC),len(REC))
check('Une recette correspond à un modèle de sortie unique',len({r['output_model_id'] for r in REC})==len(REC),len(REC))
check('Quantités positives et une sortie',all(r['output_quantity']==1 and r['duration_seconds']>0 and all(isinstance(q,int) and q>0 for q in r['inputs'].values()) for r in REC),'pas de quantité nulle, négative ou fractionnaire')
levels={t['level'] for t in D['tiers']}
check('Les paliers sont ceux du jeu',all(r['level'] in levels for r in REC),sorted(levels))
check('Les ensembles commencent à 40 et restent Épiques ou Légendaires',all(r['level']>=40 and r['rarity'] in ['epic','legendary'] for r in REC if r['set_id']),3576)
check('Chaque patron appartient à un métier existant',set(b['profession'] for b in D['base_recipes']) <= {'smithing','tanning','tailoring','carpentry','jewelcrafting','enchanting'},sorted({b['profession'] for b in D['base_recipes']}))
prepared={p['output'] for p in P['recipes']};raw={s['id'] for s in P['raw_sources']}
check('Aucune entrée d’équipement orpheline',all(set(r['inputs'])<=prepared|raw for r in REC),'toutes les entrées existent dans le catalogue de préparation ou les sources')
supply_ids={r['id'] for r in D['supply_recipes']}
supply_sources={r['id'] for r in D['supply_extra_sources']}
check('Les fournitures ont des entrées connues',all(set(r['inputs']) <= prepared|raw|supply_ids|supply_sources for r in D['supply_recipes']),'sources supplémentaires explicitement listées pour céréale, pigment, poisson et pierre')
check('Aucune préparation orpheline',all(set(r['inputs'])<=prepared|raw for r in P['recipes']),'préparations reliées à des entrées connues')
# Les variantes de tannage ont le même output mais ne créent pas de cycles.
by={}
for p in P['recipes']:
 if p['output'] not in by or p['variant']=='default': by[p['output']]=p
seen=set();visiting=set()
def walk(x):
 if x in seen:return
 if x in visiting: raise AssertionError('cycle de préparation '+x)
 if x in by:
  visiting.add(x)
  for i in by[x]['inputs']: walk(i)
  visiting.remove(x)
 seen.add(x)
for x in prepared: walk(x)
check('Pas de boucle dans les préparations par défaut',True,len(prepared))
check('Les vestiges consommés sont au grade de la pièce',all(int(k.rsplit('_t',1)[1])==r['level'] for r in REC for k in r['inputs'] if k.startswith(tuple(D['regional_materials']))),'pas de substitution 40 vers 90')
check('La référence de sortie rejoint le canon de la pièce',all(r['canonical_piece'].startswith(r['set_id']+'/') and r['canonical_piece'].endswith('/'+r['slot']) for r in REC if r['set_id']),'canon conservé dans les variantes')
check('Douze zones, six régions réutilisées',len(D['solo_zones'])==12 and len({z['region'] for z in D['solo_zones']})==6,[(z['id'],z['region']) for z in D['solo_zones']])
check('Un parcours complet bat toute tentative incomplète au score',D['clan']['points_per_stage'] > D['clan']['maximum_integrity_bonus']+D['clan']['maximum_secondary_bonus'],'6 000 minimum contre 5 150 maximum pour cinq étapes')
# Un exemple contractuel rend visibles le palier des compléments et les unités de finition.
example=next(r for r in REC if r['scope']=='new_set_proposal' and r['base']=='metal_torso' and r['level']==40 and r['rarity']=='epic' and r['set_id']=='cendres')
expected={'metal_t40':65,'leather_t1':15,'cloth_t1':8,'atelier_powder_t40':3,'scorie_de_memoire_t40':6,'memory_binder_t40':1}
check('Le plastron publié correspond au catalogue',example['inputs']==expected and example['duration_seconds']==1076,example)
# Coût de chaîne autonome : version fibres sauvages, aucun prix ni bonus. Les vestiges sont comptés séparément.
rawby={s['id']:s for s in P['raw_sources']}
def effort(x,stack=()):
 if x in stack: raise AssertionError('cycle '+x)
 if x in by:
  p=by[x];a=p['seconds'];v=0
  for k,n in p['inputs'].items():
   c,rv=effort(k,stack+(x,));a+=n*c;v+=n*rv
  value=a/p['quantity']
  if x in rawby and rawby[x]['seconds_per_unit'] is not None:
   value=min(value,rawby[x]['seconds_per_unit'])
  return value,v/p['quantity']
 s=rawby[x]
 if s['status']=='renewable_encounter_material':return 0,1
 return s['seconds_per_unit'],0
selected=[]
for key in ['metal_torso','leather_torso','cloth_torso','hammer','crossbow','scepter','ring']:
 r=next(x for x in REC if x['base']==key and x['level']==40 and x['rarity']=='epic' and x['set_id'] and x['scope']=='new_set_proposal')
 seconds=r['duration_seconds'];vest=0
 for k,n in r['inputs'].items():
  e,v=effort(k);seconds+=e*n;vest+=v*n
 # 2 vestiges par 360 s de référence ; l’échange Quartz n’est pas utilisé dans ces exemples.
 selected.append(dict(base=key,recipe_id=r['id'],assembly_minutes=r['duration_seconds']/60,ordinary_chain_minutes=seconds/60,regional_units=vest,regional_reference_minutes=vest*3,total_reference_minutes=seconds/60+vest*3,assumptions='wild_fibers_no_prices_no_bonuses_no_parallel_farming'))
body=[x['total_reference_minutes'] for x in selected if x['base'].endswith('_torso')]
check('Les torses n’ont pas un coût d’une autre échelle',max(body)/min(body)<1.35,{'ratio_max_min':max(body)/min(body),'note':'seuil de revue, aucune prédiction de marché'})
expected_named=(1-.95**20)/.05
check('Garantie à vingt essais : espérance et plafond distingués',12.82<expected_named<12.84,dict(expected_units=expected_named,expected_reference_minutes=expected_named*6,maximum_reference_minutes=120))
check('Parcours et cible : même budget par unité, sans or',D['dungeon']['regional_vestiges_per_route']==3*D['normal_loot']['regional_vestiges'] and D['normal_loot']['gold']==0,dict(target_seconds=360,route_seconds=1080,named_targets='distinct source counters'))
report=dict(status='passed',checks_count=len(checks),checks=checks,chain_examples=selected,scaling_examples=[dict(steps=s,hp=1.012**s,damage=1.008**s) for s in [30,60,120,240]],named=dict(expected_units=expected_named,expected_minutes=expected_named*6,probability_at_least_one_direct_in_three=1-.95**3),limitations=['No combat simulation','No market simulation','No new content imported into game','Ordinary chain costs use dedicated proposed raw sources and no market prices','Grade 30 amethyst uses existing mining level 35; cross-profession levels need not equal equipment level'])
(R/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='passed',checks=len(checks),chains=selected),ensure_ascii=False))
