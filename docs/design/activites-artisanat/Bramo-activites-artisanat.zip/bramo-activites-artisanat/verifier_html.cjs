/* Contrôles DOM et interactions avec LinkeDOM. Aucun rendu graphique n'est certifié. */
const fs=require('fs'),path=require('path'),vm=require('vm');
let parseHTML;try{({parseHTML}=require('linkedom'))}catch{({parseHTML}=require('/workspace/scratch/bramo-visual-check/node_modules/linkedom'))}
const html=fs.readFileSync(path.join(__dirname,'Bramo-activites-artisanat.html'),'utf8');
const {document}=parseHTML(html);const checks=[];
function check(name,ok,details){checks.push({name,ok:!!ok,details});if(!ok)throw new Error(name+': '+JSON.stringify(details));}
// Émuler les propriétés d'input/select non implémentées dans LinkeDOM.
for(const el of document.querySelectorAll('select'))Object.defineProperty(el,'value',{get(){return [...el.options].find(o=>o.hasAttribute('selected'))?.value??el.options[0]?.value??''},set(v){for(const o of el.options){if(o.value===String(v))o.setAttribute('selected','');else o.removeAttribute('selected')}}});
for(const el of document.querySelectorAll('*'))el.scrollIntoView=()=>{};
const printed=[];
const context={document,window:{print:()=>printed.push(true)},location:{hash:''},setTimeout:f=>f(),Intl,console};
const scripts=[...document.querySelectorAll('script')].filter(s=>!s.type).map(s=>s.textContent);
for(const code of scripts)new vm.Script(code).runInNewContext(context);
check('Le script démarre sans exception',true,scripts.length);
check('21 chapitres présents',document.querySelectorAll('details.chapter').length===21);
const broken=[...document.querySelectorAll('a[href^="#"]')].filter(a=>!document.getElementById(decodeURIComponent(a.getAttribute('href').slice(1)))).map(a=>a.getAttribute('href'));
check('Toutes les ancres existent',broken.length===0,broken);
check('Aucun actif externe obligatoire',document.querySelectorAll('script[src],link[rel=stylesheet],img[src]').length===0);
let entries=[...document.querySelectorAll('.ingredient')].map(e=>({name:e.dataset.material,grade:e.dataset.grade,text:e.textContent}));
check('Exemple initial : 65 métaux du grade 40',entries.some(e=>e.name==='metal'&&e.grade==='40'&&e.text.endsWith('65')),entries);
check('Exemple initial : 15 cuirs du grade 1',entries.some(e=>e.name==='leather'&&e.grade==='1'&&e.text.endsWith('15')));
const $=id=>document.getElementById(id);
$('recipeBase').value='longbow';$('recipeBase').onchange();
check('Arc : aucun ensemble qui n’en possède pas',$('recipeSet').options.length===1);
$('recipeBase').value='metal_torso';$('recipeBase').onchange();$('recipeTier').value='10';$('recipeTier').onchange();
check('Pas de set avant 40',$('recipeSet').options.length===1);
$('recipeTier').value='90';$('recipeTier').onchange();$('recipeBase').value='ring';$('recipeBase').onchange();$('recipeRarity').value='legendary';$('recipeRarity').onchange();$('recipeSet').value='cendres';$('recipeSet').onchange();
check('Recette Légendaire 90 accessible',$('recipeSummary').textContent.includes('90')&&$('recipeSummary').textContent.includes('Légendaire'));
check('Pas de matière indéfinie',[...document.querySelectorAll('.ingredient')].every(e=>!e.textContent.includes('undefined')));
$('stage').value='240';$('stage').oninput();
check('Multiplicateur de PV illustratif calculé',$('hpValue').textContent.includes('17,51'),$('hpValue').textContent);
$('search').value='escóuade';$('search').oninput();check('Recherche avec accents et casse',document.querySelectorAll('#results a').length>0);
$('print').onclick();check('Impression ouvre les chapitres',printed.length===1);
check('12 zones présentées',document.querySelectorAll('.zone-card').length===12);
const report={status:'passed_dom_only',checks_count:checks.length,checks,browser_render:'not_run_browser_binary_unavailable_download_failed',limitations:['DOM emulation does not certify Chromium layout, mobile overflow or screenshots','The Playwright check is supplied but was not executed successfully in this environment']};
fs.writeFileSync(path.join(__dirname,'verification-html.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,checks:checks.length,chapters:21,broken_links:broken.length}));
