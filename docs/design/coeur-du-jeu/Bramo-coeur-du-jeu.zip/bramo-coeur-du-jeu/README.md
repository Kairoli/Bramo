# Bramo — le cœur du jeu

Commencer par **Bramo-coeur-du-jeu.html**. C’est un fichier autonome avec navigation,
recherche dans les sorts/objets/adversaires et comparaison des voies.
**Bramo-coeur-du-jeu.md** contient le même texte pour Claude ou un éditeur.

Le dépôt Kairoli/Bramo n’a pas été modifié. Référence : `706f70a` du 21 octobre 2026.
Tout le nouveau contenu est une proposition. Les fichiers JSON sont des données de
conception, **pas des fichiers à copier directement dans `data/`**.

## Contenu

- 3 mécaniques de classe, 9 passifs de voie.
- 66 sorts ; 16 accessibles par voie à terme, 5 places au niveau 30.
- 18 ensembles : 12 partagés + 2 par classe ; 144 pièces canoniques,
  298 modèles de silhouette/arme au rang de base.
- 24 objets nommés, 18 gemmes majeures et 8 familles mineures.
- 6 régions, 18 adversaires marquants, 6 parcours de donjon.
- 27 plans d’équipement complets, avec répertoires de sorts 40 et 80.

## Reproduire les vérifications

Python 3.10+ ; bibliothèque standard uniquement. Depuis ce dossier :

```sh
python3 -X utf8 verifier.py
python3 -X utf8 banc_combat.py --seeds 12
python3 -X utf8 chercher_assemblages.py
python3 -X utf8 calculer_butin.py
```

Sur Windows, remplacer `python3` par `python` si nécessaire. `-X utf8` conserve
correctement les libellés français.

Les scripts remplacent leurs résultats JSON. Garder une copie avant de comparer
deux variantes. Les résultats de combat portent les empreintes des données et du
banc. Pour recalculer le texte après une modification :

```sh
python3 -X utf8 ecrire_dossier.py
```

Le fichier HTML livré correspond aux données et résultats livrés. Si les données
changent, recalculer les résultats, puis le Markdown ; l’HTML doit être régénéré
ou relu séparément. Aucun de ces scripts ne pousse de commit, ne modifie le dépôt
ni n’envoie des résultats à un service externe.

## Portée des résultats

Le banc Python est **indépendant du moteur TypeScript de production**. Il résout
les compétences, les mécaniques et les effets retenus, sur des profils PvE solo.
Les répertoires 40 et 80 utilisent des statistiques normalisées identiques : ils
isolent l’accès aux sorts, pas la vraie courbe de niveaux du jeu.

La recherche passe en revue les paires 4+4 avec trois plans de sorts par voie
et leurs talents majeurs fixés. Elle ne cherche pas toutes les permutations
de sorts, d’horaires, d’affixes et d’armes. Les résultats à danger doublé sont des
stress tests, pas une difficulté déclarée prête pour l’ouverture.

Les effets de groupe, le PvP, les dix-huit scripts détaillés des boss, les
enchaînements de donjons, la progression réelle et le marché ne sont pas simulés.
Le soin de groupe, les protections et les effets économiques attendent donc des
tests du vrai moteur partagé. Le mini-calcul de butin exclut temps et matériaux
d’artisanat ainsi que prix du marché.

L’ensemble du contrat technique et des changements de données est décrit dans
les chapitres 17 à 21 du dossier. Ne pas confondre un exemple qui fonctionne dans
le banc avec une preuve d’équilibre pour toutes les combinaisons possibles.
