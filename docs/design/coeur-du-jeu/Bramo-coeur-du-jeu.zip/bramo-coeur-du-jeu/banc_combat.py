"""Banc SOLO de conception. Aucun import ni modification du moteur Bramo.

python3 banc_combat.py --seeds 12
Les valeurs viennent de projet.json. Voir README et le dossier pour les limites.
"""
from pathlib import Path
import argparse,collections,copy,hashlib,itertools,json,math,random,statistics,time

HERE=Path(__file__).resolve().parent
DATA=json.loads((HERE/'projet.json').read_text())
PROVENANCE={'data_sha256':hashlib.sha256((HERE/'projet.json').read_bytes()).hexdigest(),'engine_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
CFG=DATA['simulation_parameters']
SPELLS={s['id']:s for s in DATA['spells']}
SETDATA=CFG['set_numbers']; NAMED=CFG['named_numbers']; GEMS=CFG['gem_numbers']
PATHS={p['id']:p for c in DATA['classes'] for p in c['paths']}

class Battle:
    def __init__(self,build,scenario,seed=0,level=80,trace=False,gear=True,stat_scale=1):
        self.b=build;self.sc=scenario;self.rand=random.Random(seed);self.enemy_rand=random.Random(seed^91309);self.level=level
        self.p=CFG['power']*stat_scale;self.hpmax=CFG['max_hp']*stat_scale;self.hp=self.hpmax
        self.t=0.;self.dt=CFG['tick'];self.action=0;self.gcd=0;self.basic_next=1.
        self.ss=build['sets'] if gear else {};self.nn=set(build['named']) if gear else set();self.gg=set(build['gems']) if gear else set()
        self.path=build['path_id'];self.c=build['class_id'];self.trace_on=trace;self.trace=[]
        weapon=next((n for n in DATA['named_items'] if n['id'] in build['named'] and n['slot']=='weapon'),None)
        self.weapon_period=CFG['weapon_periods'].get(weapon['family'] if weapon else 'staff',2)
        self.cool={};self.preps={};self.count=collections.Counter();self.last={};self.shields=[];self.hots=[]
        self.heat=0;self.angle=-1.;self.angle_target=-1;self.order=-1.;self.rune=None;self.rune_element='lightning';self.ink=0
        self.rebattue=0;self.rebattue_n=0;self.rebattue_until=-1.;self.rivets=0;self.rivets_until=-1.
        self.sceau_pool=0.;self.sceau_next=8.;self.absorb_window=[];self.rancune=0;self.plate_counter=0
        self.m=collections.Counter();self.min_hp=self.hp;self.max_shield=0;self.sequence=[]
        self.plan=[dict(SPELLS[x['spell']],offset=x['offset'],ready=x['offset'],opened=False) for x in build['plans'][str(level)]]
        n=scenario['targets'];self.enemies=[]
        for i in range(n):
            self.enemies.append(dict(i=i,hp=float(scenario['hp']),maxhp=float(scenario['hp']),guard=0.,guard_until=0.,slow=0.,slow_until=0.,stun=0.,mark=0.,antiheal=0.,antiheal_until=0.,weaken=[],vuln=[],dots={},stability=CFG['stability'],break_until=-1.,break_recover=-1.,next_hit=2.+i*.5,boss=n==1))
        self.target=0
        base=CFG['defense_reduction'];cap=.45;ratio=base/(cap-base)
        if self.has('enclume',2):ratio*=1+SETDATA['enclume']['defense_score']
        self.dr=cap*ratio/(1+ratio)
        cap=.35;ratio=CFG['haste']/(cap-CFG['haste'])
        if self.has('orage',2):ratio*=1+SETDATA['orage']['haste_score']
        self.haste=cap*ratio/(1+ratio)
        self.shield_mult=1+(SETDATA['enclume']['shield_mult']-1 if self.has('enclume',3) else 0)+(SETDATA['sceau']['support_mult']-1 if self.has('sceau',2) else 0)+(SETDATA['rivets']['shield_mult']-1 if self.has('rivets',2) else 0)
        self.heal_mult=1+(SETDATA['sceau']['support_mult']-1 if self.has('sceau',2) else 0)+(SETDATA['relais']['heal_mult']-1 if self.has('relais',2) else 0)
        self.dot_mult=1+(SETDATA['cendres']['dot_mult']-1 if self.has('cendres',3) else 0)+(SETDATA['passeurs']['dot_mult']-1 if self.has('passeurs',2) else 0)
        if 'bastion' in self.gg:
            d=GEMS['bastion'];self.shield(d['shield']*self.p,'gem:bastion',False,d['duration']);self.cool['gem:bastion']=d['cd']

    def has(self,id,n=4):return self.ss.get(id,0)>=n
    def log(self,kind,**kw):
        if self.trace_on:self.trace.append({'t':round(self.t,2),'kind':kind,**kw})
    def alive(self):return [e for e in self.enemies if e['hp']>0]
    def current(self):
        if self.enemies[self.target]['hp']<=0:
            alive=self.alive()
            if not alive:return self.enemies[self.target]
            old=self.enemies[self.target]
            self.target=alive[0]['i']
            if self.c=='tracker' and self.angle>self.t and self.angle_target==old['i']:
                self.angle=min(self.angle,self.t+3);self.angle_target=self.target
            self.count['empreinte']=0
        return self.enemies[self.target]
    def ready(self,key):return self.t+1e-8>=self.cool.get(key,-1)
    def proc(self,key,cd):
        if not self.ready(key):return False
        self.cool[key]=self.t+cd;self.m['procs:'+key]+=1;return True
    def put(self,key,kind,amount=0,duration=8,cd=0,eligible='direct',**kw):
        if key in self.preps or not self.ready(key):return False
        self.preps[key]=dict(kind=kind,amount=amount,until=self.t+duration,born=self.action,cd=cd,eligible=eligible,**kw)
        self.log('prepare',source=key,effect=kind);return True
    def counter(self,key,threshold):
        self.count[key]=min(threshold,self.count[key]+1)
        if self.count[key]>=threshold and self.ready(key) and key not in self.preps:
            self.count[key]=0;return True
        return False
    def mark(self,e,duration):
        if self.has('empreinte',3):duration*=SETDATA['empreinte']['mark_mult']
        e['mark']=max(e['mark'],self.t+duration)
    def slow(self,e,amount,duration):
        if self.has('ronces',2):duration*=SETDATA['ronces']['slow_mult']
        if e['boss']:amount=min(.15,amount)
        if e['slow_until']<=self.t or amount>=e['slow']:
            e['slow']=amount;e['slow_until']=self.t+duration
            return True
        return False
    def weaken(self,e,amount,duration=6,once=False):e['weaken'].append(dict(amount=amount,until=self.t+duration,once=once))
    def vulnerability(self,e,amount,duration):e['vuln'].append((amount,self.t+duration))
    def damage(self,e,amount,origin='equipment',element='physical',crit=False,penetration=0):
        if e['hp']<=0:return 0
        # Défense ennemie uniforme 10 % dans ce banc ; aucun profil élémentaire.
        mult=1-.10*(1-min(1,penetration))
        if crit:mult*=CFG['crit_multiplier']
        vuln=max([v for v,t in e['vuln'] if t>self.t]+([CFG['break_damage_taken']] if e['break_until']>self.t else [0]))
        amount*=mult*(1+min(CFG['vulnerability_cap'],vuln))
        g=min(e['guard'],amount);e['guard']-=g;amount-=g
        dealt=min(e['hp'],amount);e['hp']-=dealt
        self.m['damage:'+origin]+=dealt;self.m['guard_damage']+=g
        self.m['element:'+element]+=dealt
        if e['hp']<=0:self.death(e)
        return dealt+g
    def dot(self,e,key,coefficient,kind='burn',duration=6,secondary=False,transferred=False):
        if e['hp']<=0:return
        actual_duration=duration*(SETDATA['cendres']['duration_mult'] if self.has('cendres',2) else 1)
        # Le débit reste celui de la durée de base ; prolonger ajoute des ticks.
        d=dict(rate=coefficient*self.p*self.dot_mult/duration,end=self.t+actual_duration,next=self.t+1,kind=kind,secondary=secondary,extended=0,transferred=transferred)
        same=[(k,x) for k,x in e['dots'].items() if x['kind']==kind and k!=key]
        if len(same)>=3:
            weakest=min(same,key=lambda x:x[1]['rate'])
            if weakest[1]['rate']>d['rate']:return
            del e['dots'][weakest[0]]
        e['dots'][key]=d
    def heal(self,amount,primary=False):
        effective=min(self.hpmax-self.hp,amount*self.heal_mult);self.hp+=effective
        self.m['heal_primary' if primary else 'heal_secondary']+=effective
        if primary and self.has('sceau'):
            d=SETDATA['sceau'];self.sceau_pool=min(d['cap']*self.p,self.sceau_pool+d['share']*effective)
        return effective
    def hot(self,amount,duration,source):
        self.hots=[h for h in self.hots if h['source']!=source]
        self.hots.append(dict(rate=amount/duration,end=self.t+duration,next=self.t+1,source=source))
    def shield(self,amount,source,primary=False,duration=6,plate_damage=0):
        amount*=self.shield_mult
        # Libérer la réserve remplacée AVANT de vérifier le plafond.
        self.shields=[x for x in self.shields if x['source']!=source]
        cap=CFG['total_shield_cap']*self.p
        if not primary:
            sec=sum(x['amount'] for x in self.shields if not x['primary'])
            amount=min(amount,max(0,CFG['secondary_shield_cap']*self.p-sec))
        amount=min(amount,max(0,cap-sum(x['amount'] for x in self.shields)))
        if amount<=0:return 0
        # Une même source remplace ; remplacement sans expiration ni bris.
        if primary and self.has('revers',2):duration+=SETDATA['revers']['duration_bonus']
        self.shields.append(dict(amount=amount,source=source,primary=primary,end=self.t+duration,plate_damage=plate_damage))
        self.max_shield=max(self.max_shield,sum(x['amount'] for x in self.shields));self.m['shield_produced']+=amount
        return amount
    def pressure(self,e,amount,hard=False):
        if amount<=0 or e['hp']<=0:return False
        if self.has('fracture',2):amount*=SETDATA['fracture']['pressure_mult']
        if e['break_recover']>self.t:return False
        loss=min(e['stability'],amount);e['stability']-=loss;self.m['pressure']+=loss
        if hard and 'doubt' in self.nn:
            d=NAMED['doubt']
            if self.proc('named:doubt',d['cd']):self.shield(d['shield']*self.p,'named:doubt')
        if e['stability']<=0:
            e['stability']=CFG['stability'];e['break_until']=self.t+CFG['break_duration'];e['break_recover']=self.t+CFG['break_recovery']
            self.weaken(e,CFG['break_next_hit_reduction'],CFG['break_duration'],True);self.m['breaks']+=1
            if 'bad_omen' in self.nn:
                d=NAMED['bad_omen'];self.put('named:bad_omen','damage',d['damage']*self.p,cd=d['cd'])
        return loss>0
    def rune_effect(self,rune,e,share=1,primary=False):
        if rune is None:return
        if self.has('palimpseste',2):share*=SETDATA['palimpseste']['rune_mult']
        if rune=='trait':self.damage(e,CFG['glyph_trait']*self.p*share,'class' if primary else 'equipment',self.rune_element)
        elif rune=='circle':
            for target in self.alive()[:2]:self.damage(target,CFG['glyph_circle']*self.p*share,'class' if primary else 'equipment',self.rune_element)
            if e['hp']>0:return self.slow(e,CFG['glyph_slow'],2)
        elif rune=='seal':self.shield(CFG['glyph_seal']*self.p*share,'native_rune' if primary else 'copied_rune',primary,CFG['glyph_duration'])
    def consume_preps(self,s,e,is_basic):
        extra={'damage':0,'heal':0,'shield':0}
        for key,v in list(self.preps.items()):
            if v['until']<=self.t:del self.preps[key];continue
            if v['born']>=self.action:continue
            elig=v['eligible'];tags=s.get('tags',[])
            ok=elig=='direct' or (elig=='auto' and is_basic) or (elig=='skill' and not is_basic) or (elig=='builder' and 'heat' in tags) or (elig=='setup' and 'setup' in tags) or (elig=='healing' and bool(s.get('heal'))) or (elig=='temper' and 'temper' in tags) or (elig=='companion' and 'companion' in tags)
            if not ok:continue
            del self.preps[key];self.proc(key,v['cd']);self.log('consume',source=key,effect=v['kind'])
            kind=v['kind'];amount=v['amount']
            if kind in ['damage','auto_damage']:
                self.damage(e,amount,'class' if key.startswith('class:') else 'equipment',s.get('element','physical'))
                if v.get('cleave'):
                    others=[x for x in self.alive() if x['i']!=e['i']]
                    if others:self.damage(others[0],v['cleave'],'equipment',s.get('element','physical'))
            elif kind in ['heal','auto_heal']:self.heal(amount)
            elif kind in ['shield','auto_shield']:self.shield(amount,key)
            elif kind=='vulnerability':self.vulnerability(e,amount,v['effect_duration'])
            elif kind=='dot':self.dot(e,key,amount,'bleed',v.get('dot_duration',6),True)
            elif kind=='mark':self.mark(e,amount)
            elif kind=='mark_rune':self.mark(e,amount);self.rune_effect(self.rune,e,v['rune_share'])
            elif kind=='mark_heal':self.mark(e,amount);self.heal(v['heal'])
            elif kind=='rune':self.rune_effect(v['rune'],e,amount)
            elif kind=='incise':self.damage(e,amount,'equipment',s.get('element','physical'));self.shield(v['guard'],key)
        return extra
    def cast(self,s,basic=False):
        if not self.alive():return
        if s.get('element')=='inherit':s={**s,'element':self.rune_element}
        self.action+=1;e=self.current();self.m['primary_actions']+=1
        tags=s.get('tags',[]);form=s.get('form');oldrune=self.rune
        native_shield=bool(s.get('shield')) or (self.c=='runist' and oldrune=='seal' and not basic)
        oldorder=self.order>self.t;oldangle=self.angle>self.t and self.angle_target==e['i']
        snap=dict(marked=e['mark']>self.t,afflicted=bool(e['dots']),slowed=e['slow_until']>self.t,shielded=bool(self.shields))
        pressure_before=self.m['pressure']
        crit=self.rand.random()<min(.50,CFG['crit_chance']+(SETDATA['empreinte']['crit'] if self.has('empreinte',2) and snap['marked'] else 0))
        self.consume_preps(s,e,basic)
        coefficient=s['damage'];primary_bonus=0;heat=0;angle=False;control=False;effective_heal=0;dispelled=False;cleansed=False
        if not basic:
            self.m['skill_casts']+=1;self.log('cast',spell=s['id'],heat=self.heat,rune=oldrune,angle=oldangle)
            if 'temper' in tags:
                heat=self.heat;self.heat=0;primary_bonus+=CFG['temper_damage']*heat;self.m['heat_spent']+=heat
                if self.path=='red_temper':self.rebattue=PATHS[self.path]['knob']*self.p*heat;self.rebattue_n=3;self.rebattue_until=self.t+8
                elif self.path=='anvil' and heat:
                    control=self.pressure(e,PATHS[self.path]['knob']*heat) or control;self.weaken(e,.08*heat,6,True)
                    self.put('class:assise','damage',PATHS[self.path]['followup']*heat*self.p,eligible='builder')
                elif self.path=='whetter' and heat:
                    self.shield(PATHS[self.path]['knob']*heat*self.p,'class_plate',False,6,plate_damage=.12*heat*self.p)
                if self.has('recuit',3) and heat==3:self.shield(SETDATA['recuit']['shield']*self.p,'set:recuit3')
                if self.has('recuit') and heat>=SETDATA['recuit']['min_heat'] and self.proc('set:recuit',SETDATA['recuit']['cd']):self.heat+=SETDATA['recuit']['returned_heat']
                if self.has('rivets',3):self.put('set:rivets3','auto_damage',SETDATA['rivets']['auto']*self.p,eligible='auto',cd=SETDATA['rivets']['cd'])
                if self.has('rivets'):self.rivets=heat;self.rivets_until=self.t+8
            if 'exploit' in tags and oldangle:
                self.angle=-1;angle=True;primary_bonus+=CFG['angle_damage'];self.m['angles_consumed']+=1
                if self.path=='beastslayer':self.dot(e,'class:morsure',PATHS[self.path]['knob'],'bleed',6)
                elif self.path=='trapper':
                    self.weaken(e,.25,6,True);e['countertrap']=(PATHS[self.path]['knob']*self.p,self.t+6)
                    control=self.pressure(e,10) or control
                elif self.path=='packleader':self.order=self.t+8
            if self.c=='runist':
                rune_control=self.rune_effect(oldrune,e,1,True)
                if oldrune=='circle':control=bool(rune_control) or control
                if self.path=='glyphkeeper' and form in ['trait','circle']:
                    primary_bonus+=self.ink/self.p;self.ink=0
                if self.path=='fulgurant' and self.counter('class:last_word',3):
                    extra=PATHS[self.path]['knob']*self.p
                    if oldrune=='seal':extra-=.15*self.p;self.shield(.15*self.p,'class:last_word')
                    others=[x for x in self.alive() if x['i']!=e['i']]
                    if oldrune=='circle' and others:self.damage(others[0],extra/2,'class',s['element']);extra/=2
                    self.damage(e,extra,'class',s['element'])
            if 'companion' in tags and self.path=='packleader' and oldorder:
                self.order=self.t+8 if angle else -1;primary_bonus+=.35;effective_heal+=self.heal(PATHS[self.path]['knob']*self.p,True);self.m['pack_orders']+=1
            if self.has('intervalles',2) and s['cooldown']>=SETDATA['intervalles']['long_cd']:coefficient*=1+SETDATA['intervalles']['long_bonus']
            if self.has('recuit',2) and 'heat' in tags:coefficient*=1+SETDATA['recuit']['builder_bonus']
            if self.has('battue',3) and 'setup' in tags:coefficient*=1+SETDATA['battue']['setup_bonus']
            if self.has('meute',2) and 'companion' in tags:coefficient*=1+SETDATA['meute']['companion_bonus']
        else:
            self.m['basic_attacks']+=1
            if self.has('vigie',2):coefficient*=SETDATA['vigie']['auto_mult']
            if self.rebattue_n and self.rebattue_until>self.t:
                coefficient+=self.rebattue/self.p;self.rebattue_n-=1;self.m['rebattue_hits']+=1
            if self.rivets and self.rivets_until>self.t:
                self.rivets-=1;self.shield(SETDATA['rivets']['shield']*self.p,'set:rivets4')
            self.log('basic')
        bonus=0
        if self.has('orage',3) and self.last.get('orage_bonus',-1)>self.t:bonus+=SETDATA['orage']['direct_bonus']
        if self.has('fracture',3) and self.last.get('fracture_bonus',-1)>self.t:bonus+=SETDATA['fracture']['direct_bonus']
        if self.has('incise',2) and self.last.get('incise_bonus',-1)>self.t:bonus+=SETDATA['incise']['direct_bonus']
        element=s.get('element','physical')
        if element=='inherit':element=self.rune_element
        targets=[e]+[x for x in self.alive() if x['i']!=e['i']][:s.get('targets',1)-1]
        for i,x in enumerate(targets):
            impact=coefficient*(1 if i==0 else .55)+(primary_bonus if i==0 else 0)
            self.damage(x,impact*self.p*(1+bonus),'basic' if basic else 'skill',element,crit,s.get('penetration',0))
            if s.get('dot'):self.dot(x,'spell:'+s['id'],s['dot']*(1 if i==0 else .55),s['dot_type'],s['dot_duration'])
        if not basic:
            if s.get('heal'):effective_heal+=self.heal(s['heal']*self.p,True)
            if s.get('shield'):self.shield(s['shield']*self.p,'spell:'+s['id'],True,s.get('duration',6))
            for victim in targets:
                if victim['hp']<=0:continue
                if s.get('slow'):control=self.slow(victim,s['slow'],s.get('duration',4)) or control
                if s.get('stun'):
                    if victim['boss']:control=self.pressure(victim,s['stun']*15,True) or control
                    else:victim['stun']=self.t+min(CFG['hard_control_cap'],s['stun']);control=True
                if s.get('pressure'):control=self.pressure(victim,s['pressure']) or control
                if s.get('mark'):self.mark(victim,s['mark'])
                if s.get('weaken'):self.weaken(victim,s['weaken'],s.get('duration',6))
                if s.get('antiheal'):victim['antiheal']=s['antiheal'];victim['antiheal_until']=self.t+s.get('duration',6)
                if s.get('dispel') and victim['guard']>0:victim['guard']=0;dispelled=True;self.m['dispels']+=1
            if s.get('cleanse') and self.sc.get('aura',0) and self.t>0 and self.last.get('aura_clean',-1)<=self.t:self.last['aura_clean']=self.t+6;cleansed=True;self.m['cleanses']+=1
            if s.get('empower_auto'):self.put('class:auto','auto_damage',s['empower_auto']*self.p,eligible='auto')
            if self.c=='forgefire':self.heat=min(CFG['heat_cap'],self.heat+s.get('heat',0))
            if self.c=='tracker' and 'setup' in tags:
                self.angle=self.t+CFG['angle_duration']+(SETDATA['battue']['angle_bonus'] if self.has('battue',2) else 0);self.angle_target=e['i']
            if self.c=='runist':
                self.rune=form;self.rune_element=element;self.m['runes_read']+=int(oldrune is not None)
            if self.path=='sigilbinder' and control and self.counter('class:scelles',3):
                self.damage(e,PATHS[self.path]['knob']*self.p,'class',element);self.weaken(e,.30,6,True);self.m['interdits']+=1
        pressure_loss=self.m['pressure']>pressure_before
        self.equipment_events(s,e,basic,snap,crit,heat,angle,oldrune,oldorder,control,effective_heal,dispelled,cleansed,native_shield,pressure_loss)
        if not basic:
            self.sequence=(self.sequence+[form])[-3:];self.last['skill']=s['id'];self.last['skill_at']=self.t;self.last['form']=form
        self.min_hp=min(self.min_hp,self.hp)

    def equipment_events(self,s,e,basic,snap,crit,heat,angle,oldrune,oldorder,control,effheal,dispelled,cleansed,native_shield,pressure_loss):
        direct=True;skill=not basic;cd=s.get('cooldown',0);tags=s.get('tags',[]);P=self.p
        for sid in sorted(self.ss):
            d=SETDATA[sid]
            if sid=='cendres' and self.has(sid) and snap['afflicted'] and self.counter('set:cendres',d['count']):self.put('set:cendres','damage',d['damage']*P,cd=d['cd'],cleave=d['cleave']*P)
            elif sid=='empreinte' and self.has(sid):
                if snap['marked'] and self.counter('set:empreinte',d['count']):self.put('set:empreinte','damage',d['damage']*P,cd=d['cd'])
            elif sid=='ronces' and self.has(sid) and skill and control and self.counter('set:ronces',d['count']):self.put('set:ronces','vulnerability',d['vulnerability'],cd=d['cd'],effect_duration=d['duration'])
            elif sid=='orage' and skill and self.last.get('skill') not in [None,s['id']] and self.t-self.last.get('skill_at',-100)<=d['burst_window']:
                if self.has(sid,3):self.last['orage_bonus']=self.t+4
                if self.has(sid):self.put('set:orage','damage',d['damage']*P,eligible='skill',cd=d['cd'])
            elif sid=='relais':
                if self.has(sid,3) and effheal>0:self.put('set:relais3','auto_damage',d['auto']*P,eligible='auto',cd=6)
                if self.has(sid) and skill:
                    if (effheal>0 or native_shield) and self.last.get('relais',-1)>self.t:
                        if self.proc('set:relais',d['cd']):self.damage(e,d['damage']*P)
                        self.last['relais']=-1
                    else:self.last['relais']=self.t+6
            elif sid=='intervalles' and skill:
                if self.has(sid,3) and cd>=d['long_cd']:self.put('set:intervalles3','auto_damage',d['auto']*P,eligible='auto',cd=8)
                if self.has(sid):
                    if cd<=d['short_cd'] and self.last.get('interval',-1)>self.t:
                        if self.proc('set:intervalles',d['cd']):self.damage(e,d['damage']*P)
                        self.last['interval']=-1
                    elif cd>=d['long_cd']:self.last['interval']=self.t+6
            elif sid=='vigie':
                if self.has(sid,3) and basic and snap['marked'] and self.proc('set:vigie3',6):self.shield(d['shield']*P,'set:vigie3')
                if self.has(sid) and basic and self.t-self.last.get('skill_at',-100)>=d['idle_window'] and self.proc('set:vigie',d['cd']):
                    if self.hp/self.hpmax<d['hp_gate']:
                        self.damage(e,(d['damage']-d['heal'])*P);self.heal(d['heal']*P)
                    else:self.damage(e,d['damage']*P)
            elif sid=='fracture' and skill and (pressure_loss or dispelled):
                if self.has(sid,3):self.last['fracture_bonus']=self.t+4
                if self.has(sid):
                    self.put('set:fracture','damage',d['damage']*P,eligible='skill',cd=d['cd'])
                    self.put('set:fracture_vuln','vulnerability',d['vulnerability'],eligible='skill',cd=d['cd'],effect_duration=d['duration'])
            elif sid=='battue' and self.has(sid) and angle and self.proc('set:battue',d['cd']):
                others=[x for x in self.alive() if x['i']!=e['i']]
                if others:self.damage(others[0],d['cleave']*P)
                else:self.put('set:battue_auto','auto_damage',d['solo_auto']*P,eligible='auto')
            elif sid=='meute' and skill:
                if 'companion' in tags:
                    if self.has(sid,3):self.put('set:meute3','auto_damage',d['auto']*P,eligible='auto',cd=6)
                    if self.has(sid) and self.last.get('meute',-1)>self.t and self.proc('set:meute',d['cd']):self.damage(e,d['damage']*P);self.heal(d['heal']*P);self.last['meute']=-1
                else:self.last['meute']=self.t+6
            elif sid=='palimpseste' and skill and oldrune is not None:
                if self.has(sid,3) and oldrune=='seal':self.put('set:palimpseste3','auto_damage',d['auto']*P,eligible='auto',cd=8)
                if oldrune!=self.last.get('palimpseste_form'):self.count['set:palimpseste']=0
                self.last['palimpseste_form']=oldrune
                if self.has(sid) and self.counter('set:palimpseste',d['count']):self.put('set:palimpseste','rune',d['rune_share'],eligible='skill',cd=d['cd'],rune=oldrune)
            elif sid=='incise' and skill:
                form=s.get('form')
                if oldrune and form!=oldrune and self.has(sid,2):self.last['incise_bonus']=self.t+3
                if self.has(sid,3) and oldrune=='seal' and form=='trait' and self.proc('set:incise3',8):self.shield(d['shield']*P,'set:incise3')
                seq=(self.sequence+[form])[-3:]
                if self.has(sid) and len(seq)==3 and seq[0] is not None and seq[0]==seq[2] and seq[0]!=seq[1]:self.put('set:incise','incise',d['damage']*P,eligible='skill',cd=d['cd'],guard=d['guard']*P)
        for nid in sorted(self.nn):
            d=NAMED[nid];key='named:'+nid
            if nid=='rancune' and self.rancune and self.proc(key,d['cd']):self.damage(e,self.rancune*d['damage']*P);self.rancune=0
            elif nid=='manners' and skill and pressure_loss and self.proc(key,d['cd']):self.shield(d['shield']*P,key)
            elif nid=='fire_share' and snap['afflicted'] and e['dots'] and self.proc(key,d['cd']):
                for dot in e['dots'].values():
                    ext=min(d['seconds'],d['max_extension']-dot['extended']);dot['end']+=ext;dot['extended']+=ext
            elif nid=='right_count' and heat==3:self.put(key,'auto_damage',d['auto']*P,eligible='auto',cd=d['cd'])
            elif nid=='last_rivet' and heat>=2:self.put(key,'shield',d['shield']*P,eligible='builder',cd=d['cd'])
            elif nid=='thorn_whisper' and crit and snap['marked'] and self.proc(key,d['cd']):
                other=next((x for x in self.alive() if x['i']!=e['i']),e);self.damage(other,d['damage']*P)
            elif nid=='punctual' and snap['slowed'] and self.proc(key,d['cd']):self.damage(e,d['damage']*P)
            elif nid=='silent_sisters' and skill and control:self.put(key,'dot',d['dot'],cd=d['cd'],dot_duration=d['duration'])
            elif nid=='quiet_witness' and angle and snap['marked']:self.put(key,'damage',d['damage']*P,eligible='setup',cd=d['cd']);self.last['witness']=True
            elif nid=='no_warning' and angle:
                if self.last.get('warning_target')!=e['i'] or self.counter(key,d['count']):
                    if self.proc(key,d['cd']):self.damage(e,d['damage']*P)
                self.last['warning_target']=e['i']
            elif nid=='dogs_share' and skill and 'companion' in tags and (oldorder or self.last.get('pursuit',-1)>self.t):self.put(key,'heal',d['heal']*P,eligible='companion',cd=d['cd'])
            elif nid=='last_warning' and skill:
                prior=self.last.get('cast:'+s['id'],-100)
                if self.t-prior<=d['window']:self.put(key,'mark_rune',d['mark'],eligible='skill',cd=d['cd'],rune_share=d['rune_share'])
                self.last['cast:'+s['id']]=self.t
            elif nid=='erasure_book' and crit and snap['afflicted'] and self.proc(key,d['cd']):self.damage(e,d['damage']*P,element=s.get('element','physical'))
            elif nid=='semicolon' and skill and oldrune=='trait' and s.get('form')=='circle' and self.proc(key,d['cd']):self.damage(e,d['damage']*P)
            elif nid=='objection' and skill and control and oldrune:self.put(key,'rune',d['rune_share'],eligible='auto',cd=d['cd'],rune=oldrune)
            elif nid=='key' and skill and (dispelled or (oldrune=='seal' and s.get('form')=='trait')):self.put(key,'shield',d['shield']*P,eligible='skill',cd=d['cd'])
            elif nid=='return_thread' and effheal>0:self.put(key,'mark_heal',d['mark'],cd=d['cd'],heal=d['heal']*P)
            elif nid=='arrangement' and snap['shielded'] and self.proc(key,d['cd']):self.hot(d['heal']*P,d['duration'],key)
            elif nid=='overtime' and skill and cd>=d['long_cd']:self.put(key,'auto_damage',d['auto']*P,eligible='auto',cd=d['cd'])
            elif nid=='bad_omen' and dispelled:self.put(key,'damage',d['damage']*P,cd=d['cd'])
        if angle:self.last['pursuit']=self.t+8
        for gid in sorted(self.gg):
            d=GEMS[gid];key='gem:'+gid
            if gid=='ember_live' and self.proc(key,d['cd']):self.dot(e,key,d['dot'],'burn',d['duration'],True)
            elif gid=='open_wound' and crit and self.proc(key,d['cd']):self.dot(e,key,d['dot'],'bleed',d['duration'],True)
            elif gid=='hunter_eye' and self.proc(key,d['cd']):self.mark(e,d['duration'])
            elif gid=='polar_breath' and self.proc(key,d['cd']):self.slow(e,d['slow'],d['duration'])
            elif gid=='rhythm' and self.counter(key,d['count']):self.put(key,'auto_damage',d['auto']*P,eligible='auto',cd=d['cd'])
            elif gid=='fine_assistance' and skill and control and self.proc(key,d['cd']):self.heal(d['heal']*P)
            elif gid=='alternating_guard' and skill and (effheal>0 or native_shield) and self.proc(key,d['cd']):self.shield(d['shield']*P,key)
            elif gid=='return_mark' and snap['marked'] and self.proc(key,d['cd']):self.heal(d['heal']*P)
            elif gid=='tenacious_frost' and snap['slowed'] and self.proc(key,d['cd']):self.damage(e,d['damage']*P,element=s.get('element','physical'))
            elif gid=='ash_shelter' and crit and snap['afflicted'] and self.proc(key,d['cd']):self.shield(d['shield']*P,key)
            elif gid=='cut_patience' and skill and cd>=d['long_cd']:self.put(key,'auto_heal',d['heal']*P,eligible='auto',cd=d['cd'])
            elif gid=='slant_grace' and effheal>0:self.put(key,'damage',d['damage']*P,cd=d['cd'])
            elif gid=='passing_shard' and skill and self.counter(key,d['count']):self.put(key,'auto_damage',d['damage']*P,eligible='auto',cd=d['cd'])
            elif gid=='clean_edge' and skill and (pressure_loss or dispelled or cleansed):self.put(key,'damage',d['damage']*P,cd=d['cd'])
            elif gid=='steady_pulse' and skill and cd<=d['short_cd'] and self.last.get('pulse') not in [None,s['id']]:self.put(key,'auto_shield',d['shield']*P,eligible='auto',cd=d['cd'])
            elif gid=='last_spark' and skill and self.hp/self.hpmax<d['hp_gate'] and self.proc(key,d['cd']):self.shield(d['shield']*P,key)
        if skill and cd<=12:self.last['pulse']=s['id']

    def incoming(self,e,amount):
        active=[x for x in e['weaken'] if x['until']>self.t]
        weak=max([x['amount'] for x in active]+[0]);e['weaken']=[x for x in active if not x['once']]
        if self.has('ronces',3) and e['slow_until']>self.t:amount*=1-SETDATA['ronces']['reduction']
        amount*=(1-self.dr)*(1-weak);self.m['incoming_before_shield']+=amount
        absorbed=0
        for sh in sorted(list(self.shields),key=lambda x:x['end']):
            if amount<=0:break
            take=min(sh['amount'],amount);sh['amount']-=take;amount-=take;absorbed+=take
            if take>0:
                self.m['absorbed']+=take
                if sh['primary']:
                    if self.path=='glyphkeeper':self.ink=min(PATHS[self.path]['knob']*self.p,self.ink+take)
                    if self.has('sceau'):self.sceau_pool=min(SETDATA['sceau']['cap']*self.p,self.sceau_pool+SETDATA['sceau']['share']*take)
                    self.count['debt_absorb']+=take
                if sh.get('plate_damage'):
                    self.damage(e,sh['plate_damage'],'class');sh['plate_damage']=0
            if sh['amount']<=1e-8:
                if sh in self.shields:self.shields.remove(sh)
                if 'return_wave' in self.gg:
                    d=GEMS['return_wave']
                    if self.proc('gem:return_wave',d['cd']):self.damage(e,d['damage']*self.p)
        if absorbed>0 and self.has('enclume'):
            self.absorb_window=[(t,v) for t,v in self.absorb_window if t>self.t-4]+[(self.t,absorbed)]
            d=SETDATA['enclume']
            if sum(v for t,v in self.absorb_window)>=d['threshold']*self.p and self.proc('set:enclume',d['cd']):
                self.absorb_window=[];self.damage(e,d['damage']*self.p);self.shield(d['shield']*self.p,'set:enclume')
        if 'light_debt' in self.nn:
            d=NAMED['light_debt']
            if self.count['debt_absorb']>=d['threshold']*self.p:self.put('named:light_debt','heal',d['heal']*self.p,eligible='healing',cd=d['cd']);self.count['debt_absorb']=0
        if amount>0:
            self.hp-=amount;self.m['hp_lost']+=amount
            if 'rancune' in self.nn and self.last.get('rancune_tick',-1)<=self.t:
                self.rancune=min(NAMED['rancune']['charges'],self.rancune+1);self.last['rancune_tick']=self.t+1
        if e.get('countertrap') and e['countertrap'][1]>self.t:
            self.damage(e,e['countertrap'][0],'class');del e['countertrap']
        self.min_hp=min(self.min_hp,self.hp)
    def expire_shields(self):
        for sh in list(self.shields):
            if sh['end']>self.t:continue
            self.shields.remove(sh)
            if not sh['primary'] or sh['amount']<=0:continue
            if self.has('revers',3):self.heal(SETDATA['revers']['heal_share']*sh['amount'])
            if self.has('revers'):
                d=SETDATA['revers'];self.put('set:revers','damage',min(d['damage_cap']*self.p,d['damage_share']*sh['amount']),cd=d['cd'])
            if 'seal_holds' in self.nn:
                d=NAMED['seal_holds']
                if self.proc('named:seal_holds',d['cd']):self.heal(d['heal']*self.p)
            if 'it_holds' in self.nn:
                d=NAMED['it_holds'];self.put('named:it_holds','heal',d['heal']*self.p,eligible='temper',cd=d['cd'])
    def death(self,e):
        self.m['kills']+=1
        if self.has('passeurs',3):self.put('set:passeurs3','auto_damage',SETDATA['passeurs']['auto']*self.p,eligible='auto',cd=8)
        if self.has('passeurs') and e['dots']:
            d=SETDATA['passeurs'];opts=[x for x in e['dots'].values() if not x['transferred']]
            if opts and self.proc('set:passeurs',d['cd']):
                dot=max(opts,key=lambda x:x['rate']*max(0,x['end']-self.t));others=[x for x in self.alive() if x['i']!=e['i']]
                if others:
                    clone=copy.deepcopy(dot);clone['transferred']=True;clone['secondary']=True;others[0]['dots']['transfer:passeurs']=clone
                else:self.put('set:passeurs_reward','damage',d['damage']*self.p)
        if 'passing_shard' in self.gg:
            d=GEMS['passing_shard'];self.put('gem:passing_shard','auto_damage',d['damage']*self.p,eligible='auto',cd=d['cd'])
    def run(self):
        while self.t<=CFG['fight_limit'] and self.hp>0 and self.alive():
            self.expire_shields()
            for h in list(self.hots):
                while h['next']<=self.t and h['next']<=h['end']:
                    h['next']+=1;self.heal(h['rate'])
                if h['end']<=self.t:self.hots.remove(h)
            for e in list(self.alive()):
                if e['guard_until']<=self.t:e['guard']=0
                for key,d in list(e['dots'].items()):
                    while d['next']<=self.t+1e-8 and d['next']<=d['end']+1e-8 and e['hp']>0:
                        d['next']+=1;self.damage(e,d['rate'],'equipment_dot' if d['secondary'] else 'skill_dot','fire' if d['kind']=='burn' else 'physical')
                    if d['end']<=self.t:
                        fraction=max(0,min(1,d['end']-(d['next']-1)))
                        if fraction and e['hp']>0:self.damage(e,d['rate']*fraction,'equipment_dot' if d['secondary'] else 'skill_dot','fire' if d['kind']=='burn' else 'physical')
                        if key in e['dots']:del e['dots'][key]
                        if self.has('passeurs'):
                            x=SETDATA['passeurs'];self.put('set:passeurs','damage',x['damage']*self.p,cd=x['cd'])
            if not self.alive():break
            if self.has('sceau') and self.t>=self.sceau_next:
                self.sceau_next+=SETDATA['sceau']['period']
                if self.sceau_pool>0:self.shield(self.sceau_pool,'set:sceau');self.sceau_pool=0
            if self.t+1e-8>=self.basic_next:
                basic_element='physical'
                if self.c=='runist':
                    basic_element=self.b.get('basic_element') or collections.Counter(s['element'] for s in self.plan if s['element']!='inherit').most_common(1)[0][0]
                self.cast({'id':'basic','damage':CFG['basic_damage']*self.weapon_period/CFG['basic_period'],'element':basic_element,'tags':[]},True)
                self.basic_next=self.t+self.weapon_period/(1+self.haste)
            if self.alive() and self.t+1e-8>=self.gcd:
                opener=any(not s['opened'] for s in self.plan)
                elig=[s for s in self.plan if s['ready']<=self.t+1e-8 and (not opener or not s['opened'])]
                if elig:
                    s=min(elig,key=lambda x:(x['ready'],self.plan.index(x)))
                    self.cast(s);s['opened']=True;s['ready']=self.t+s['cooldown']/(1+self.haste);self.gcd=self.t+CFG['gcd']
            for e in list(self.alive()):
                if self.t+1e-8>=e['next_hit']:
                    if e['stun']>self.t:e['next_hit']=e['stun']
                    else:
                        self.incoming(e,self.sc['enemy_damage']*(.95+.10*self.enemy_rand.random()))
                        slow=e['slow'] if e['slow_until']>self.t else 0
                        e['next_hit']=self.t+self.sc['enemy_period']/(1-slow)
                if self.sc.get('charge') and self.t>0 and abs(self.t%self.sc['charge_period'])<self.dt/2:
                    self.incoming(e,self.sc['charge'])
                if self.sc.get('shield') and self.t>0 and abs(self.t%self.sc['shield_period'])<self.dt/2:
                    e['guard']=self.sc['shield'];e['guard_until']=self.t+6
                if self.sc.get('regen') and self.t>0 and abs(self.t%self.sc['regen_period'])<self.dt/2:
                    anti=e['antiheal'] if e['antiheal_until']>self.t else 0
                    e['hp']=min(e['maxhp'],e['hp']+self.sc['regen']*(1-anti))
            if self.alive() and self.sc.get('aura') and self.t>0 and abs(self.t%1)<self.dt/2 and self.last.get('aura_clean',-1)<=self.t:self.hp-=self.sc['aura'];self.m['aura_damage']+=self.sc['aura']
            self.min_hp=min(self.min_hp,self.hp);self.t=round(self.t+self.dt,8)
        win=self.hp>0 and not self.alive();duration=max(self.dt,self.t)
        dmg=sum(v for k,v in self.m.items() if k.startswith('damage:'))
        gear_dmg=self.m['damage:equipment']+self.m['damage:equipment_dot']
        return dict(win=win,time=round(duration,3),hp=max(0,self.hp),min_hp=max(0,self.min_hp),damage=dmg,equipment_damage_share=gear_dmg/dmg if dmg else 0,
                    hp_ratio=max(0,self.hp/self.hpmax),metrics=dict(self.m),trace=self.trace if self.trace_on else None)

def summarize(rows):
    wins=[x for x in rows if x['win']]
    return dict(n=len(rows),wins=len(wins),win_rate=len(wins)/len(rows),median_time=statistics.median(x['time'] for x in wins) if wins else None,
                median_hp=statistics.median(x['hp_ratio'] for x in rows),gear_damage_share=statistics.mean(x['equipment_damage_share'] for x in rows),
                mean_pressure=statistics.mean(x['metrics'].get('pressure',0) for x in rows),mean_breaks=statistics.mean(x['metrics'].get('breaks',0) for x in rows))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',type=int,default=12);ap.add_argument('--quick',action='store_true');args=ap.parse_args()
    started=time.time();rows=[];baselines=[]
    for level in [40,80]:
        for b in DATA['builds']:
            for sc in CFG['benchmark_scenarios']:
                runs=[Battle(b,sc,seed,level).run() for seed in range(args.seeds)]
                rows.append(dict(level=level,build_id=b['id'],class_id=b['class_id'],path_id=b['path_id'],scenario=sc['id'],**summarize(runs)))
        for b in DATA['builds'][::3]:
            for sc in CFG['benchmark_scenarios']:
                runs=[Battle(b,sc,seed,level,gear=False).run() for seed in range(args.seeds)]
                baselines.append(dict(level=level,build_id=b['id'],class_id=b['class_id'],path_id=b['path_id'],scenario=sc['id'],**summarize(runs)))
    # Sensibilité sur les mêmes plans ; pas une recherche exhaustive.
    sensitivity=[]
    for scale in [.90,1.10]:
        for b in DATA['builds'][::3]:
            for sc in CFG['benchmark_scenarios']:
                runs=[Battle(b,sc,seed,80,stat_scale=scale).run() for seed in range(min(4,args.seeds))]
                sensitivity.append(dict(scale=scale,build_id=b['id'],path_id=b['path_id'],scenario=sc['id'],**summarize(runs)))
    result=dict(status='independent_design_bench',source_is_game_engine=False,provenance=PROVENANCE,seeds=args.seeds,
                simulations=len(rows)*args.seeds+len(baselines)*args.seeds+len(sensitivity)*min(4,args.seeds),
                seconds=round(time.time()-started,3),rows=rows,baselines=baselines,sensitivity=sensitivity,
                limits=DATA['scope']['not_simulated'],all_curated_rows_win=all(x['win_rate']==1 for x in rows))
    (HERE/'resultats-combat.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    failures=[{k:x[k] for k in ['level','build_id','scenario','win_rate']} for x in rows if x['win_rate']<1]
    print(json.dumps({'simulations':result['simulations'],'seconds':result['seconds'],'failures':failures,'all_curated_rows_win':result['all_curated_rows_win']},ensure_ascii=False))

if __name__=='__main__':main()
