"""Distribution illustrative d'un premier set ; aucune économie simulée.
Une cache par heure NOMINALE victorieuse, focus d'ensemble, huit pièces,
90 % de bonne classe pour les six vêtements, deux emplacements partagés,
une chute par cache ; six chutes donnent une pièce ciblée via un artisan.
Le coût et le temps d'artisanat sont exclus de ce petit calcul.
"""
from pathlib import Path
import json,math,random,statistics,hashlib
HERE=Path(__file__).resolve().parent
DATA=json.loads((HERE/'projet.json').read_text());R=DATA['loot_rules']

def quantile(v,p):return sorted(v)[min(len(v)-1,math.ceil(p*len(v))-1)]
def collect(rng,goal=4,use_scraps=True,shared_slots=2):
 found=set();scraps=0;boxes=0
 while len(found)<goal:
  boxes+=1;scraps+=1;slot=rng.randrange(8)
  if slot>=8-shared_slots or rng.random()<R['smart_loot_class_probability']:found.add(slot)
  if use_scraps and scraps>=R['set_piece_scraps_cost'] and len(found)<goal:
   missing=next(i for i in range(8) if i not in found);found.add(missing);scraps-=R['set_piece_scraps_cost']
 return boxes

def main():
 rng=random.Random(82317);n=100000
 stats={}
 for shared in [1,2]:
  stats[str(shared)]={}
  for use in [False,True]:
   vals=[collect(rng,use_scraps=use,shared_slots=shared) for _ in range(n)]
   stats[str(shared)]['with_crafting' if use else 'drops_only']={'mean_hours':statistics.mean(vals),'median_hours':statistics.median(vals),'p90_hours':quantile(vals,.9),'p95_hours':quantile(vals,.95),'p99_hours':quantile(vals,.99)}
 p=R['named_direct_probability_per_reference_boss'];m=R['named_recipe_fragments'];t=R['reference_seconds']/60
 # Temps jusqu'au drop OU aux matériaux de recette, sous hypothèse d'artisan accessible.
 mean_attempts=(1-(1-p)**m)/p
 result={'data_sha256':hashlib.sha256((HERE/'projet.json').read_bytes()).hexdigest(),'samples_per_case':n,'first_four_piece':stats,
         'named':{'probability':p,'reference_minutes_per_kill':t,'recipe_fragments':m,'no_direct_drop_after_20':(1-p)**m,
                  'mean_minutes_until_drop_or_recipe_materials':mean_attempts*t,'reference_minutes_for_all_recipe_fragments':m*t},
         'recycling_example':{'drops_per_hour':4,'recipe_gathering_minutes':30,'raw_salvage_share':.4,'gathering_minutes_created_per_combat_hour':4*30*.4,'share_of_dedicated_gatherer':4*30*.4/60},
         'scope':'Cache par temps de référence, focus d’ensemble, jet de classe, chutes ciblées ; hors temps/coût d’artisanat, marché, statistiques des objets et amélioration de la vitesse de victoire.'}
 (HERE/'resultats-butin.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
