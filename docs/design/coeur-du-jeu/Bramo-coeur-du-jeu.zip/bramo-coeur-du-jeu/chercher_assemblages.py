"""Criblage des 4+4 : trois plans et leurs talents fixes, pas tous les sorts/affixes.
Première passe : une graine, trois situations. Finalistes : six situations, huit graines.
"""
from pathlib import Path
import collections,copy,itertools,json,statistics,time
from banc_combat import DATA,CFG,Battle,summarize,PROVENANCE
HERE=Path(__file__).resolve().parent

def main():
 started=time.time();screen=[]
 for b in DATA['builds']:
  sets=[x['id'] for x in DATA['sets'] if b['class_id'] in x['classes']]
  for pair in itertools.combinations(sets,2):
   trial={**b,'sets':dict.fromkeys(pair,4)}
   rs=[Battle(trial,sc,seed=931,level=80).run() for sc in CFG['benchmark_scenarios'][:3]]
   score=statistics.mean(r['time'] if r['win'] else CFG['fight_limit']*2 for r in rs)
   screen.append({'base_build':b['id'],'path_id':b['path_id'],'class_id':b['class_id'],'sets':list(pair),'score':score,'screen_times':[r['time'] if r['win'] else None for r in rs]})
 final=[];byid={b['id']:b for b in DATA['builds']}
 for path in sorted({b['path_id'] for b in DATA['builds']}):
  candidates=[x for x in screen if x['path_id']==path]
  selected=[];seen=set()
  # Préserver les gagnants de chaque situation et une représentation de chaque plan.
  ranked=[sorted(candidates,key=lambda x:x['score'])]
  ranked += [sorted(candidates,key=lambda x:x['screen_times'][i] if x['screen_times'][i] is not None else 10000) for i in range(3)]
  ranked += [sorted([x for x in candidates if x['base_build']==b['id']],key=lambda x:x['score']) for b in DATA['builds'] if b['path_id']==path]
  for ranking in ranked:
   for r in ranking[:2]:
    key=(r['base_build'],tuple(r['sets']))
    if key not in seen:seen.add(key);selected.append(r)
  for r in selected:
   b={**byid[r['base_build']],'sets':dict.fromkeys(r['sets'],4)}
   checks=[]
   for sc in CFG['benchmark_scenarios']:
    checks.append(dict(scenario=sc['id'],**summarize([Battle(b,sc,seed,80).run() for seed in range(8)])))
   final.append({**r,'checks':checks})
 stress=[]
 for threat in [1.5,2.0]:
  for b in DATA['builds']:
   for orig in CFG['benchmark_scenarios']:
    sc={**orig,'enemy_damage':orig['enemy_damage']*threat,'charge':orig.get('charge',0)*threat,'aura':orig.get('aura',0)*threat}
    stress.append(dict(build_id=b['id'],path_id=b['path_id'],scenario=sc['id'],threat=threat,**summarize([Battle(b,sc,i,80).run() for i in range(4)])))
 result={'description':'Recherche de 4+4 à statistiques normalisées, plans et talents majeurs fixés ; aucune recherche des jets ni preuve de méta exhaustive.','provenance':PROVENANCE,'screen_seed':931,'final_seeds':list(range(8)),
         'screened_assemblies':len(screen),'screen_simulations':len(screen)*3,'finalists':len(final),'finalist_simulations':len(final)*6*8,
         'stress_simulations':len(stress)*4,'seconds':round(time.time()-started,2),'screen':screen,'final':final,'stress':stress}
 (HERE/'recherche-assemblages.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 best={}
 for p in sorted({b['path_id'] for b in DATA['builds']}):
  best[p]=min(x['score'] for x in screen if x['path_id']==p)
 print(json.dumps({'screened':len(screen),'finalists':len(final),'simulations':len(screen)*3+len(final)*48+len(stress)*4,'seconds':result['seconds'],'best_screen_score':best},ensure_ascii=False))

if __name__=='__main__':main()
