from pathlib import Path
import collections,json,math,statistics,textwrap,hashlib

ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'projet.json').read_text());M=json.loads((ROOT/'modeles-ensembles.json').read_text())
R=json.loads((ROOT/'resultats-combat.json').read_text());SEARCH=json.loads((ROOT/'recherche-assemblages.json').read_text());LOOT=json.loads((ROOT/'resultats-butin.json').read_text());TEST=json.loads((ROOT/'verification-regles.json').read_text())
expected=hashlib.sha256((ROOT/'projet.json').read_bytes()).hexdigest()
engine=hashlib.sha256((ROOT/'banc_combat.py').read_bytes()).hexdigest()
assert R['provenance']==SEARCH['provenance']==TEST['provenance']=={'data_sha256':expected,'engine_sha256':engine}, 'Résultats à relancer pour cette version'
assert R['all_curated_rows_win'], 'Échecs de référence à examiner avant de rédiger une validation'

CL={c['id']:c for c in P['classes']};SP={s['id']:s for s in P['spells']};ST={s['id']:s for s in P['sets']};NM={n['id']:n for n in P['named_items']};GM={g['id']:g for g in P['gems']};BO={b['id']:b for b in P['bosses']};RG={r['id']:r for r in P['regions']};PA={p['id']:p for c in P['classes'] for p in c['paths']}
SLOT={'head':'Coiffe','torso':'Torse','hands':'Gants','legs':'Jambes','feet':'Bottes','cape':'Cape','belt':'Ceinture','ring':'Anneau','ring1':'Anneau 1','ring2':'Anneau 2','necklace':'Collier','weapon':'Arme'}
ELEMENT={'physical':'Physique','fire':'Feu','frost':'Givre','lightning':'Foudre','inherit':'Élément du sort précédent'}
FORM={'trait':'Trait','circle':'Cercle','seal':'Sceau',None:'—'}
ROLE={'damage':'Dégâts','control':'Contrôle','support':'Soutien'}
STAT={'power':'Puissance','crit':'Critique','haste':'Cadence','vitality':'Vitalité','defense':'Défense','tenacity':'Ténacité','penetration':'Pénétration','element_damage':'Dégâts élémentaires'}
FAMILY={'hammer':'Marteau','sword_shield':'Épée et bouclier','axe':'Hache','longbow':'Arc long','crossbow':'Arbalète','daggers':'Dagues','staff':'Bâton','scepter':'Sceptre','grimoire':'Grimoire','jewel':'Bijou'}
out=[]
def add(s=''):out.append(textwrap.dedent(s).strip()+'\n')
def table(headers,rows):
    out.append('| '+' | '.join(headers)+' |\n| '+' | '.join('---' for _ in headers)+' |')
    for row in rows:out.append('| '+' | '.join(str(x).replace('|','/').replace('\n',' ') for x in row)+' |')
    out.append('')
def f(n):return str(round(n,3)).replace('.',',')
def spell_effect(s):
    a=[f"{f(s['damage'])} P de dégâts"+ (f" ; {s['targets']} cibles, secondaires à 55 %" if s['targets']>1 else '')]
    if s.get('heat'):a.append('+1 Braise')
    if 'temper' in s['tags']:a.append('Trempe : dépense les Braises, +0,15 P chacune sur la cible principale')
    if 'setup' in s['tags']:a.append('Repérage : ouvre un Angle')
    if 'exploit' in s['tags']:a.append('Poursuite : exploite un Angle existant')
    if 'companion' in s['tags']:a.append('compétence de compagnon')
    if s.get('form'):a.append('écrit '+FORM[s['form']])
    if s.get('dot'):a.append(f"{'Brûlure' if s['dot_type']=='burn' else 'Saignement'} : {f(s['dot'])} P au total / {s['dot_duration']} s")
    if s.get('heal'):a.append(f"soin {f(s['heal'])} P")
    if s.get('shield'):a.append(f"protection {f(s['shield'])} P / {s.get('duration',6)} s")
    if s.get('slow'):a.append(f"ralentissement {f(s['slow']*100)} % / {s.get('duration',4)} s")
    if s.get('stun'):a.append(f"étourdit {s['stun']} s ; converti en Pression sur boss")
    if s.get('pressure'):a.append(f"Pression {s['pressure']}")
    if s.get('mark'):a.append(f"Marque {s['mark']} s")
    if s.get('weaken'):a.append(f"Affaiblissement {f(s['weaken']*100)} % / {s.get('duration',6)} s")
    if s.get('antiheal'):a.append(f"réduction des soins reçus {f(s['antiheal']*100)} % / {s.get('duration',6)} s")
    if s.get('dispel'):a.append('dissipe une garde ennemie')
    if s.get('cleanse'):a.append('purifie une altération du bénéficiaire')
    if s.get('penetration'):a.append(f"ignore {f(s['penetration']*100)} % de la Défense pour ce sort")
    if s.get('empower_auto'):a.append(f"prochaine attaque de base +{f(s['empower_auto'])} P")
    return ' ; '.join(a)+'.'

add('''
# Bramo — le cœur du jeu

**Classes, voies, sorts, combat automatique, contenu PvE, équipement et obtention.**

Proposition complète de conception · 21 octobre 2026 · version 0.2 · destinée à Louis et Claude.

**Tout ce qui est nouveau dans ce dossier est proposé, pas encore approuvé ni implémenté.** La conversation récente de Louis prime sur les anciens textes du dépôt. Le dépôt reste inchangé.

Le choix central est de donner à chaque classe une mécanique présente dès les premiers combats, transformée par ses voies, puis enrichie par les objets. Les trois classes peuvent partager une partie de leur équipement sans partager leur fonctionnement. Les ennemis valorisent ces différences et la préparation du plan ; ils ne demandent aucune action pendant le combat.

Le dossier contient une cible de contenu complète et un banc de conception reproductible. **Ce banc est indépendant du moteur TypeScript actuel.** Il vérifie des interactions et donne des premiers écarts ; il ne certifie ni l’équilibrage du jeu publié, ni le marché, ni le PvP.

## 1. La proposition en une page

Le Forgefeu accumule jusqu’à trois Braises avec ses Chauffes et choisit comment les dépenser avec ses Trempes. Le Traqueur ouvre un Angle mort sur une Proie puis l’exploite avant sa disparition. Le Runiste lit la rune laissée par le sort précédent et écrit la suivante : l’ordre des sorts devient une grammaire.

Chaque classe a trois voies : dégâts, contrôle, soutien. Une voie transforme l’usage de la mécanique de classe ; elle n’ajoute pas simplement « +10 % de dégâts ». Chacune garde accès aux compétences communes qui lui permettent de se défendre, d’affaiblir un ennemi et de finir un combat seule.

Le joueur prépare quatre sorts avant le niveau 30, puis cinq. Il règle leur première utilisation et leur ordre de priorité. Après l’ouverture, leurs cooldowns déterminent les lancements automatiques. L’ultime du niveau 75 occupe une des cinq places : ce n’est pas une sixième compétence gratuite obligatoire.
''')
table(['Ensemble du projet','Contenu proposé'],[
 ['Classes et voies','3 classes, 9 voies ; une mécanique centrale et un passif de voie distinct'],
 ['Compétences','66 sorts : 22 par classe, dont 12 communs, 9 répartis entre voies, 1 ultime'],
 ['Choix dans une voie','16 sorts accessibles à terme, 5 équipés ; les sorts des deux autres voies sont exclus'],
 ['Ensembles','18 : 12 partagés et 2 propres à chaque classe ; 8 pièces possibles par ensemble, bonus 2/3/4'],
 ['Pièces','144 pièces canoniques, déclinées en 298 modèles de silhouette ou d’arme ; chiffres de statistiques à calibrer'],
 ['Nommés','24 talents fixes : 6 armes par classe et 6 colliers universels'],
 ['Gemmes','18 majeures et 8 familles de mineures statistiques'],
 ['PvE','6 régions, 18 adversaires marquants, 6 parcours de donjon ; profondeurs permanentes'],
 ['Plans d’exemple','27 assemblages, avec choix de sorts aux paliers 40 et 80 et équipement complet'],
 ['Vérification','273 associations 4+4 possibles avec une arme et un collier nommés réservés ; banc de combat et recherche d’assemblages joints']])
add('''
Je garde des sets communs parce qu’ils ouvrent des croisements intéressants. J’ajoute six sets de classe parce qu’une mécanique propre mérite aussi des objets capables de la transformer. **Aucun ensemble n’est réservé à une voie.** Un Enclumier peut chercher des dégâts ; un Tue-Bête peut chercher de la sécurité ; un Glyphiste peut construire une alternance offensive.

Le contenu démarre modestement dans la version à coder : un adversaire de chaque grand type et un donjon suffisent à vérifier le système. La cible de contenu décrite ici sert à éviter de construire cette première version dans une impasse.

## 2. Ce que le dépôt fait réellement et les arbitrages repris
''')
table(['Sujet','État de référence','Traitement dans ce dossier'],[
 ['Classes','Trois classes affichées, poses et tenues ; aucun kit complet exécuté','Les trois mécaniques et les neuf passifs sont nouveaux'],
 ['XP de classe','Prévue uniquement au combat, niveau propre à chaque classe','Conservé ; métiers et armes ne donnent pas une nouvelle XP de combat'],
 ['Voies','Dégâts / contrôle / soutien au niveau 30 ; noms proposés','Conservé ; noms de voies encore modifiables'],
 ['Équipement','769 modèles, paliers 1/10/20, exemplaires, équipement et totaux','Conserver le socle ; ce dossier ajoute une conception de contenu 20+ et 40+'],
 ['Talents nommés','Ancien texte : talents uniquement dans les gemmes','Dernière demande de Louis : talent fixe autorisé, remplaçant une majeure'],
 ['Ensembles','7 définitions illustratives ; ancien texte limité aux 7 vêtements','Proposition : inclure bijoux et armes ; redéfinir les effets avant de les rendre exécutables'],
 ['Gemmes et combat','Exemples de design, pas de moteur complet','Le banc joint est un prototype de règles, pas une intégration au jeu'],
 ['Hors ligne','100 %, 16 h d’autonomie, une activité à la fois','Conservé ; combat et progression de métier restent des activités distinctes'],
 ['Commerce','Entre joueurs ; pas de rachat PNJ, outils de bronze de secours','Pas de création d’or par le butin ; composants et équipement échangeables'],
 ['Usure','150 h de combat prévues pour les pièces ; réparation sans destruction','Conserver ; mettre en pause une répétition avant un équipement devenu inutilisable'],
 ['Artisanat','7 métiers jouables ; autres filières encore en chantier','Définir leurs débouchés sans prétendre qu’ils existent déjà'],
 ['Personnages','Un personnage par compte, plusieurs niveaux de classe conservés','Les builds et classes sont des profils du même personnage ; pas de production parallèle ajoutée']])
add(f"Référence vérifiée : [Kairoli/Bramo, commit {P['source_commit'][:7]}](https://github.com/Kairoli/Bramo/tree/{P['source_commit']}). Les versions des fichiers lus sont consignées dans `sources.json`.")
add('''
Certaines sections historiques de `CLAUDE.md`, `game-design.md` et `monde.md` mentionnent encore une ligne aléatoire unique, une spécialisation supplémentaire au niveau 60, des pertes de durabilité maximale ou d’anciennes saisons. Elles sont dépassées par les décisions plus récentes. Le moteur d’exemplaires et la dernière table de rareté prévoient bien plusieurs lignes aléatoires.

Le bonus de métier de classe reste plafonné et extérieur à la mécanique de combat. Un joueur n’a pas à monter Forge pour que ses Braises fonctionnent, ni Chasse pour obtenir son compagnon de combat, ni Enchantement pour lire ses runes.

## 3. Le combat automatique : un contrat précis

### Le plan

Un plan contient les compétences équipées, leurs délais de première utilisation, leur ordre de priorité, la priorité des cibles et celle des bénéficiaires des protections/soins. Aucun changement de pièce ni aucun clic n’est attendu pendant la rencontre.

Je traduis « première rotation puis cooldowns » par une **ouverture** : chaque compétence équipée se lance une première fois à partir de son horaire ; les répétitions commencent lorsque cette ouverture est terminée. Les cooldowns démarrent dès le lancement de chaque sort et continuent pendant l’ouverture. Ils ne sont pas remis à zéro à sa fin. C’est une proposition d’interprétation à valider, car « première autorisation indépendante » serait une autre règle possible.
''')
table(['Sort','Première utilisation','Cooldown sans Cadence','Ce qui se passe'],[
 ['A','0 s','8 s','Prêt de nouveau à 8 s, attend la fin de l’ouverture'],
 ['B','4 s','12 s','Prêt à 16 s'],
 ['C','10 s','20 s','Clôt l’ouverture ; prêt à 30 s'],
 ['A, deuxième lancement','11 s','8 s','La récupération globale de C prend 1 s ; A n’attend pas 18 s'],
 ['B, deuxième lancement','16 s','12 s','Suit son propre cooldown'],
 ['A, troisième lancement','19 s','8 s','Suit désormais ses répétitions']])
add('''
Les sorts sont instantanés à leur résolution, mais deux compétences du même personnage sont espacées d’au moins une seconde. L’attaque de base continue sur sa propre cadence ; elle n’annule pas un sort. Si plusieurs compétences sont prêtes, la plus ancienne échéance passe d’abord, puis l’ordre du plan départage les égalités. Un décalage fait partir le nouveau cooldown depuis le lancement réel : il n’existe pas de « rattrapage » de plusieurs lancements empilés.

Une place peut rester vide. Le jeu ne doit pas obliger à ajouter un mauvais sort simplement pour remplir cinq cases. Les horaires conseillés doivent rester utilisables sans réglage fin ; un intervalle supérieur à plusieurs secondes déclenche une explication dans l’éditeur, pas une interdiction.

### Cibles, groupes et fin de rencontre

Priorité de base : ennemi principal, puis cible suivante vivante. Le joueur peut préférer un soigneur, un renfort fragile ou un adversaire qui charge. On ne change pas sa cible pour obtenir artificiellement un bonus « nouvelle Proie » : il faut réellement désigner un autre ennemi. Soins et protections visent un bénéficiaire vivant selon le plan ; en solo, le porteur est toujours éligible.

Un effet ciblant une autre cible précise son comportement quand il n’y en a pas. Aucun effet ne copie silencieusement tous les dégâts d’une attaque de zone. Par défaut, les cibles secondaires d’une compétence reçoivent 55 % de ses dégâts et de ses afflictions ; les contrôles annoncés affectent toutes les cibles touchées. Une ressource de classe dépensée renforce la cible principale seulement, sauf mention explicite.

Dans un parcours, les cooldowns continuent entre salles. Le délai de première utilisation de la salle est une borne minimale, jamais un bouton qui rend disponible un sort encore en recharge. Le personnage dispose d’un repos automatique fixe entre rencontres, à calibrer avec les soins ; il ne suffit pas de quitter puis revenir pour réinitialiser sa puissance. Une défaite mène à une récupération puis à un nouvel essai, ou à une pause après des échecs répétés selon le choix du joueur. Pas de perte d’objets ou de progression.

**Le banc joint teste des rencontres isolées.** Le repos, les cooldowns conservés dans tout un donjon et les tentatives successives doivent être vérifiés dans le moteur réel avant de chiffrer les gains à l’heure. Il ne faut pas multiplier un résultat de duel isolé par mille en supposant ces transitions déjà résolues.

### Préparation et tolérance

Les boss annoncent des phases assez longues pour être couvertes par plusieurs réponses. Les timings optimaux améliorent une rencontre ; ils ne doivent pas transformer un décalage d’une seconde en mort assurée. Un contrôle lancé hors de la charge reste utile par sa Pression. Une garde posée tôt peut protéger les coups ordinaires ou récompenser son expiration. Un soin tardif peut récupérer le choc.

Je n’ajoute pas de mana générique commun aux trois classes. Les Braises, Angles et runes donnent déjà une préparation significative ; les cooldowns limitent les soins et les contrôles. Une deuxième barre de ressource sans décision propre alourdirait le jeu.

## 4. Les unités, les statistiques et les règles communes

**P désigne la Puissance utilisée pour résoudre l’effet.** Ce n’est ni le dernier critique, ni les PV maximum, ni le total d’une attaque de zone. Une mention « 0,35 P » produit un montant prévisible, ensuite réduit par les défenses applicables. Les déclenchements d’équipement ne critiquent pas et ne deviennent pas plus forts avec la taille du dernier coup d’arme.

Dans le banc, P vaut 100 et les PV 2 800. Les références 40 et 80 indiquent **les sorts accessibles**, avec les mêmes statistiques normalisées. Elles ne simulent pas la véritable puissance d’un personnage 40 contre un monstre 80. La courbe des statistiques par palier et les coefficients de conversion de l’équipement restent à construire depuis les objets actuels.
''')
table(['Statistique','Rôle','Limite de conception proposée'],[
 ['Puissance','Dégâts, soins et boucliers natifs','Un score de base commun évite une puissance de soin totalement inutilisable en solo'],
 ['Vitalité','Réserve de PV','Ne multiplie pas les dégâts des talents ni des ripostes'],
 ['Défense','Réduit les dégâts reçus','Conversion à rendement décroissant ; asymptote 45 % avant autres réductions'],
 ['Cadence','Attaques de base et cooldowns des compétences','Rendement décroissant ; asymptote +35 % de vitesse ; ne réduit pas les délais internes des talents'],
 ['Critique','Chance des impacts primaires','Plafond initial proposé 50 % ; afflictions et procs exclus'],
 ['Dégâts critiques','Valeur des critiques','Base 150 %, plafond initial proposé 200 % ; le banc utilise 160 %'],
 ['Ténacité','Durée des contrôles reçus','Ne rend pas totalement immunisé ; ne supprime pas une mécanique de boss'],
 ['Pénétration','Ignore une fraction de Défense','N’ignore jamais toutes les réductions et tous les boucliers'],
 ['Bonus élémentaire','Amplifie un type existant','Ne change pas le type d’une arme, n’invente ni sort ni statut'],
 ['Puissance de soutien','Augmente soin et protection','Affixe de spécialisation, au prix d’une ligne offensive'],
 ['Pression','Retire de la Stabilité aux adversaires concernés','Pas de mise à l’échelle avec les PV ni de multiplication par projectile']])
add('''
Formes proposées : `réduction de Défense = plafond × score / (score + K du palier)` ; même forme pour la Cadence. Un cooldown vaut `cooldown de base / (1 + Cadence)`. Les pourcentages d’une même catégorie s’additionnent avant application ; les catégories de mitigation et les limites sont explicites. Les plafonds ci-dessus sont des hypothèses de départ, pas des décisions déjà prises par Louis.

Le banc utilise 25 % de réduction pour le joueur, 10 % pour les ennemis, 20 % de critique et 12 % de Cadence avant effets. Les résistances élémentaires, la Ténacité contre les contrôles reçus et les véritables jets d’affixes ne sont pas simulés. Une résistance PvE doit rester modérée : une région glacée peut être moins favorable au Givre, elle ne doit pas être entièrement immunisée à ce type.

### Armes et cadence

Les compétences restent celles de la classe avec toutes ses armes compatibles. Le visuel s’adapte : une Poursuite du Traqueur peut être un tir ou une lame lancée. L’épée et le bouclier sont un seul objet avec un seul budget, pas deux emplacements cachés. La distance affichée ne donne pas automatiquement une défense dans un combat sans déplacement.
''')
table(['Famille','Intervalle de base proposé','Normalisation'],[[FAMILY[fam],f(t)+' s','Dégâts de base = 0,62 P × intervalle / 2 s'] for fam,t in P['simulation_parameters']['weapon_periods'].items()])
add('''
Ces intervalles restent proches pour contenir les écarts de déclenchement. Une arme rapide ne doit pas doubler les talents et une arme lente ne doit pas recopier son gros impact dans tous les procs. La Cadence modifie les intervalles réels ; les plafonds de fréquence des talents restent intacts. Le banc utilise bien la famille de l’arme nommée du plan, avec des dégâts de base normalisés. Le Runiste choisit l’élément de son attaque de base dans son plan ; le banc prend l’élément dominant des sorts, sans l’imposer à son bâton.

## 5. Les trois mécaniques de classe et les neuf voies
''')
for c in P['classes']:
    add(f"### {c['name']} — {c['core']}\n\n**État visible : {c['resource']}.**\n\n{c['rule']}\n\n**Pourquoi le choisir :** {c['appeal']}\n\n**Ce qui demande un choix :** {c['limitation']}")
    table(['Voie proposée','Rôle','Passif et fonctionnement'],[[p['name'],ROLE[p['role']],f"**{p['passive']}** — {p['rule']}"] for p in c['paths']])
    if c['id']=='forgefire':
        add('''
        Les voies changent ce qui suit une Trempe : attaques de base renforcées, prochaine Chauffe qui profite d’une Assise, ou plaques qui rendent un vrai coup. Le choix porte aussi sur le nombre de Chauffes et de Trempes équipées. Cinq grosses Trempes ne forment pas automatiquement un bon build ; elles se partageraient une préparation insuffisante.

        Un Rémouleur reste un combattant. Son rôle de réparation évoqué dans l’ancien document peut demeurer un service d’artisanat, mais il ne remplace pas ce kit de soutien de combat. Les soins et plaques ne demandent pas de consommer des lingots à chaque attaque.
        ''')
    elif c['id']=='tracker':
        add('''
        Un Angle n’est pas une Braise rebaptisée : il appartient à une cible, n’a qu’un état ouvert/fermé et impose une fenêtre courte. Une Proie n’est pas non plus une Marque partagée de l’équipement. Certaines compétences appliquent les deux, mais les mécanismes restent distincts.

        Le compagnon est un mode d’action du Traqueur. Il n’ajoute pas un second personnage, une seconde file d’activités ou une usine de déclenchements autonomes. Ses interventions sont des compétences du plan. La Chasse reste un métier idle de récolte indépendant du combat. Le second type de dégâts choisi ici est provisoirement la Foudre pour rester dans les quatre types existants ; Nature reste une question ouverte, pas un cinquième type ajouté silencieusement.
        ''')
    else:
        add('''
        Les formes de rune ne sont pas des éléments. Un Trait peut être de Feu, Givre ou Foudre ; un Cercle peut ralentir par sa géométrie sans faire de dégâts de Givre. Un Sigillaire peut donc composer un plan de Givre, mais aussi contrôler avec d’autres écoles. Fulgurant désigne un rythme et une voie de dégâts, pas une obligation de jouer Foudre.

        Exemple : Trait → Sceau → Cercle. Le Sceau lit Trait et ajoute des dégâts à son effet ; le Cercle lit Sceau et protège en attaquant ; le sort suivant lit Cercle. Changer l’ordre change la distribution des protections et impacts. Un ordre T–T–C favorise d’autres talents qu’un T–S–T. Les copies de runes produites par un objet ne réécrivent pas la phrase et ne fabriquent pas d’Encre.
        ''')
add('''
### Ce que les gemmes ne donnent pas

Une gemme peut fournir une Marque, une brûlure ou un petit ralentissement. Elle ne donne ni Braises, ni Angle mort, ni phrase runique. Elle ne donne pas non plus le passif et les trois sorts d’une autre voie. Les mots-clés partagés rendent les croisements possibles ; l’origine de l’action conserve l’identité de la classe.

Deux joueurs équipés des mêmes Cendres + Empreinte peuvent ainsi préparer leurs effets différemment, garder des marges de survie différentes et privilégier d’autres compétences. Les deux petits sets de classe poussent cette distinction plus loin, sans devenir des uniformes obligatoires.

## 6. Répertoire complet des 66 sorts

Les chiffres sont des coefficients de banc à équilibrer. Une affliction indique son **montant total**, pas des dégâts par seconde. Les protections/soins indiqués visent un bénéficiaire, sauf futur sort explicitement collectif. Les sorts hybrides conservent des dégâts utiles : un soutien n’a pas quatre boutons qui font zéro dégât.

Les libellés français peuvent changer. Les identifiants stables, tags, niveaux et coefficients figurent dans `projet.json`. Les compétences sans voie restent communes ; une voie n’a pas accès aux compétences exclusives des deux autres.
''')
for c in P['classes']:
    add(f"### Répertoire du {c['name']}")
    groups=[(None,'Compétences communes')]+[(p['id'],p['name']) for p in c['paths']]
    for pid,label in groups:
        add('**'+label+'**')
        seq=[s for s in P['spells'] if s['class_id']==c['id'] and s['path_id']==pid]
        table(['Sort','Niveau','CD','Type','Effet'],[[s['name']+(' · ultime' if 'ultimate' in s['tags'] else ''),s['level'],str(s['cooldown'])+' s',ELEMENT[s['element']],spell_effect(s)] for s in seq])
add('''
### Ouvertures conseillées

Le Forgefeu essaie d’éviter de dépenser toutes ses Braises juste avant un geste qu’il voulait renforcer. Le Traqueur place au moins un Repérage avant une Poursuite, puis surveille les collisions de cooldowns qui laissent un Angle expirer. Le Runiste choisit d’abord une phrase lisible plutôt qu’une pile de ses cinq plus gros coefficients.

Les plans joints utilisent généralement 0 / 2 / 4 / 7 / 10 s pour donner une ouverture compréhensible. Ce ne sont pas des horaires optimaux universels. Les phases d’un boss et un choix de quatre sorts au lieu de cinq peuvent donner un meilleur résultat. Le banc ne cherche pas toutes les permutations de timings.

## 7. Contrôle et soutien : utiles dans tout le PvE

### La Stabilité des boss

Un boss qui ignore simplement les étourdissements retire une grande partie de leur intérêt aux contrôleurs. À l’inverse, un boss figé en permanence supprime tout combat. Je propose une **Stabilité** : les compétences de contrôle retirent de la Pression à cette barre ; un contrôle dur se convertit en Pression au lieu de faire « immunisé, zéro effet ».

Référence du banc : 80 de Stabilité, 15 de Pression par seconde d’étourdissement convertie, en plus de la Pression inscrite sur le sort. À zéro : **Rupture** pendant 6 s, +8 % de dégâts directs reçus et prochaine attaque directe affaiblie de 25 %. Une période de récupération de 8 s empêche une nouvelle Rupture immédiate. La barre ne gèle ni les scripts ni le combat.

Les ralentissements des boss sont plafonnés à 15 % et affectent leur cadence d’attaque ordinaire ; ils ne déplacent pas arbitrairement tout leur calendrier de phases. Les ennemis ordinaires peuvent être ralentis davantage et brièvement étourdis. Un même sort peut affecter deux ennemis, mais ne crédite qu’une fois ses compteurs d’équipement.

Un contrôle qui retire vraiment de la Stabilité peut qualifier Ronces, Fracture ou un talent qui le dit. Un ralentissement faible de gemme ne donne pas ce crédit de classe. Un ralentissement natif peut qualifier Ronces, mais **ne qualifie pas Fracture s’il n’a retiré aucune Stabilité et rien dissipé**. Ce point fait l’objet d’un test spécifique.

### Une réponse de chaque rôle

Une charge lourde peut être affaiblie par une Rupture, absorbée par une garde ou suivie d’un soin. Des renforts peuvent être détruits vite, ralentis et affaiblis, ou supportés le temps de finir leur chef. Une garde ennemie peut être dissipée, usée par les coups ou laissée expirer en préparant son prochain cycle. Un soin ennemi peut être réduit, interrompu ou dépassé par un débit raisonnable.

Les mécanismes ne sont pas tous équivalents en vitesse, sécurité ou effort de préparation. **La réussite doit rester possible avec chaque classe et chaque voie, avec un build adapté au palier.** Cela ne signifie pas qu’un assemblage aléatoire ou un personnage très sous-équipé réussit tout.

### Le soutien en solo et en groupe

Un soutien garde ses attaques de base, des sorts hybrides et les compétences offensives communes. Ses mécanismes renvoient une partie de l’aide vers la poursuite : plaque qui riposte, Ordre de meute qui soigne et frappe, Encre libérée dans une attaque. Il n’attend pas qu’un allié le porte pour progresser.

Il n’existe pas de bonus caché de dégâts « parce que vous êtes seul ». Les mêmes règles fonctionnent avec le porteur comme bénéficiaire. Les protections en groupe utilisent un budget total fixé : une réserve de 100 ne devient pas quatre réserves de 100 parce qu’il y a quatre alliés. Les réserves d’Encre et de Sceau viennent de l’aide réellement utilisée, pas d’un sursoin gratuit.

Je vise un soutien offensif généralement moins rapide qu’un pur DPS à danger faible, avec une meilleure marge à danger élevé. L’écart exact est à mesurer avec le vrai budget d’objets. La cible de conception est de rester souvent dans un ordre de 10–30 % de temps supplémentaire avec un plan adapté, sans promettre ce chiffre pour tous les boss, toutes les pièces et tous les plans.

Le contenu de groupe futur est un mode à 1–3 participants, ouvert en solo avec une mise à l’échelle. Pas de composition tank/healer/DPS obligatoire pour obtenir une famille d’objets. Les butins sont personnels et ne récompensent pas le dernier coup. Le soin/protection/contrôle réellement utile doit compter dans les contributions d’événement ; le DPS seul n’est pas le score universel de participation.

## 8. Régions, parcours et objectifs durables

Les régions 40+ sont des branches horizontales, ouvertes au même grand palier. Le joueur peut choisir sa source de set et son style de rencontre. Leurs profondeurs 60, 80 et 90 changent les formations et combinaisons de mécaniques, et délivrent des exemplaires de leur rang. Rejouer le rang 40 très vite ne produit pas de composants 90.

### Niveaux et progression des classes

La classe active gagne son XP au combat ; les métiers donnent seulement leur propre XP. Les niveaux des autres classes sont conservés, mais ne progressent pas en parallèle. Changer de classe ou de voie reste gratuit hors d’une rencontre en résolution. Les voies partagent le niveau de leur classe : essayer une autre voie ne recommence pas la montée.

Je reprends comme base de travail la courbe 1–99 du projet et la recommandation de revenu horaire `R(L) = 400 × 2^((L−1)/55)` pour le temps de combat effectif. Le rattrapage proposé dans le dépôt, +50 % pour une classe sous 80 % du niveau de la meilleure, peut rester un paramètre. Ces durées de progression doivent être recalculées avec les vrais combats, les repos et les consommables : les mesures des métiers ne prouvent pas automatiquement la durée d’une classe.

Une tentative interminable sans victoire ne doit pas devenir la meilleure méthode d’XP. Piste à éprouver : créditer le temps effectif, avec une borne de crédit par tentative fondée sur son temps de référence ; une victoire termine normalement le cycle. La progression doit récompenser un plan viable sans réserver l’XP aux seuls dégâts ou au dernier coup. Les affinités de métier et les classements de contribution ne servent pas à fabriquer une seconde XP de classe.

Pour un lancement de contenu, viser des rencontres ordinaires de quelques dizaines de secondes, des élites d’une à deux minutes et des gardiens de quelques minutes est une hypothèse plus utile qu’un unique monstre de dix secondes répété partout. Le banc normalisé sert à comparer les mécaniques ; ses durées ne sont pas encore la calibration définitive de ces contenus.

Les Forges commencent au niveau 20 puis possèdent leur route 40. Les Abords servent à apprendre et leur reprise 40 permet de revisiter un adversaire sans obtenir un objet 40 sur sa version de niveau 10. Un niveau 40 ne doit pas attendre la fin de six régions linéaires pour commencer à construire un set.
''')
table(['Région','Tranches','Parcours de donjon','Intention'],[[r['name'],r['levels'],r['dungeon'],r['purpose']] for r in P['regions']])
for r in P['regions']:
    add(f"### {r['name']}\n\n{r['theme']}\n\n**Matières de filière :** {', '.join(r['gathering'])}. Ces ressources sont récoltées par les métiers appropriés ; le combat fournit surtout trophées, réactifs de boss et pièces. Les noms sont des propositions de contenu, pas des ressources déjà codées.")
    ss=[s['name'] for s in P['sets'] if s['source']==r['id']]
    add('**Ensembles à viser :** '+(', '.join(ss) if ss else 'sources de rattrapage et réactifs pour les familles permanentes ; aucun set obligatoire exclusif')+'.')
    rows=[]
    for bid in r['bosses']:
        b=BO[bid];loot=[NM[n]['name'] for n in b['named_loot']]
        rows.append([b['name'],b['mechanic'],' / '.join(b['answers']),', '.join(loot) if loot else '; '.join(b['loot'])])
    table(['Adversaire','Mécanique','Réponses possibles','Objets nommés ciblables'],rows)
    add(f"**Parcours — {r['dungeon']} :** une formation d’approche, un affrontement intermédiaire qui introduit la contrainte, puis le gardien. Le joueur peut répéter l’élite ou le gardien débloqué pour cibler un objet ; il ne refait pas une promenade vide à chaque tentative. La version longue conserve les transitions et fournit un mélange de composants, de progression d’ensemble et de collection. Leurs gains par minute de référence doivent être comparés avant de rendre l’une strictement supérieure.")
add('''
### Profondeurs et renouvellement
''')
table(['Palier','Ce qui renouvelle le contenu','Ce qui reste accessible'],[
 ['1–19','Mécanique de classe, premières options, classiques et découvertes','Aucun set nécessaire'],
 ['20–29','Deux armes nommées par classe dans les Forges ; premières interactions de talent','Le bon classique reste une alternative avec sa gemme libre'],
 ['30–39','Choix de voie ; premiers outils spécifiques de rôle','Changer de voie n’impose pas un nouveau niveau'],
 ['40–59','Quatre branches, premiers 4 pièces et doubles ensembles ; spécialisation des affixes','Toutes les familles de mécaniques de sets deviennent accessibles dans leurs routes 40'],
 ['60–74','Formations plus riches, nouvelles compétences de voie, nouveaux exemplaires 60','Les effets de set ne sont pas remplacés par des versions entièrement nouvelles'],
 ['75–89','Ultime à intégrer ou à laisser ; profondeur 80 et combinaisons de contraintes','Les mêmes voies gardent plusieurs réponses'],
 ['90–99','Profondeurs finales, meilleurs jets, chefs-d’œuvre et collections longues','Pas de remise à zéro ni de deuxième montée forcée de rareté']])
add('''
Une profondeur ne doit pas ajouter trois contraintes qui exigent simultanément une classe précise, un élément précis et une gemme précise. Chaque fiche de boss contient plusieurs réponses, au moins une accessible aux compétences communes. Les phases de soin ont un débit suffisamment bas pour ne pas créer de mur infini pour un soutien.

Les six régions et leurs variantes ne garantissent pas, à elles seules, un an d’intérêt. Le renouvellement vient ensuite de nouveaux adversaires, variations de formations, objets latéraux, collections, essais de classes et événements récurrents. Leur production doit rester soutenable ; créer d’emblée cent donjons presque identiques ne donnerait pas une meilleure base.

Un habillage d’événement équivalent à un set permanent conserve sa famille mécanique et ses clés de pièce. Changer le nom en « Givre des cimes » ne doit pas permettre de compter deux fois la même mécanique ou de contourner ses délais avec une variante saisonnière. Un véritable nouvel effet latéral porte un identifiant distinct, mais reste soumis aux mêmes familles de cumul. Les reruns ne suppriment ni recettes, ni possessions, ni progrès.

### Objectifs qui ne se réduisent pas au niveau

- **Bestiaire** : découvrir les adversaires, leurs variantes et leurs réponses ; récompenses de collection et apparences.
- **Plans de build** : assembler un premier noyau, essayer un talent nommé, passer d’un plan de groupe à un plan de boss.
- **Objets signés** : commander une pièce adaptée, faire améliorer ses jets, chercher un chef-d’œuvre d’artisan.
- **Collections de région** : reconstituer une histoire par des objets de curiosité ; titres et cosmétiques, sans bonus de dégâts à accumuler sur toutes les classes.
- **Objectifs de clan** : préparer un groupe, fournir gemmes et réparations, partager une source ou un plan de combat ; participation asynchrone.
- **Événements** : versions thématiques et apparences avec reruns ; aucune mécanique indispensable disparue onze mois par an.

Je n’ajoute pas de tournée quotidienne de toutes les régions. Un objectif choisi peut rester actif plusieurs jours, sans date d’expiration ni bonus de présence à une heure précise.

## 9. Butin, malchance et artisanat

### Des sources lisibles

Le plan de butin permet de cibler une famille d’ensemble proposée par la région et, sur un gardien, un nommé de sa table. Les pièces d’un même ensemble partagent ses règles ; un bâton n’est pas redessiné pour Feu, Givre et Foudre. Les jets produisent les variantes statistiques.

Le choix de focus, la classe, la profondeur et la version du contenu sont figés au début de la rencontre. Changer de classe avant de récupérer le résumé d’absence ne reroule pas le butin. Les résultats sont créés et enregistrés par le serveur ; le navigateur ne décide ni rareté ni affixe.

Une victoire avance un budget de butin fondé sur le **temps nominal de la rencontre**, pas sur le temps que le joueur a volontairement laissé durer le combat. Gagner plus vite reste utile ; retenir un ennemi vivant ne multiplie pas ses récompenses. Un boss faible conserve son rang de butin et ne devient jamais une fabrique de matériaux de rang 90.
''')
table(['Canal','Cadence de départ proposée','But'],[
 ['Classiques','4 pièces finies par heure nominale victorieuse','Voir du loot, remplacer les mauvais emplacements, alimenter le marché et le recyclage'],
 ['Progression d’ensemble','1 cache ciblée par heure nominale, à partir du rang 40','Une avancée garantie, sans dépendre uniquement d’une probabilité très faible'],
 ['Cache d’ensemble','8 pièces canoniques ; orientation de classe à 90 % pour les positions non partagées','Laisser du commerce et des objets pour les autres classes sans transformer chaque drop en déception'],
 ['Fragments d’ensemble','1 chute par cache ; 6 donnent accès à une pièce choisie via artisanat','Combattre les doublons ; matériaux ordinaires et service d’artisan à ajouter'],
 ['Nommé ciblé','5 % par victoire de boss de référence de 6 min','Une surprise directe ; rareté du modèle distincte de sa probabilité d’obtention'],
 ['Recette de nommé','1 fragment par victoire de référence ; 20 fragments pour sa part spéciale','Accumuler une matière échangeable même sans drop direct'],
 ['Or','0 ajouté par ce système','Conserver les commandes PNJ comme robinet contrôlé ; échanges de pièces entre joueurs']])
add('''
Ces cadences sont une proposition, pas des taux définitifs à copier sans recettes. Elles sont exprimées en temps nominal : un joueur qui gagne 20 % plus vite les obtient plus vite ; une défaite ne donne pas les pièces prévues pour une victoire. La progression de fragments peut utiliser des fractions internes afin que des rencontres de référence plus courtes ne perdent pas leur part à l’arrondi.

Les six minutes sont une **unité de budget**, pas la durée imposée à tous les boss du jeu. Pour un gardien de référence de 90 s, on accorde un quart de fragment spécial et une probabilité ciblée `1 − 0,95^(90/360)`, soit environ 1,27 %, et non 5 % à chaque petit combat. La progression de cache avance de `temps de référence / 3 600`. Les coefficients du banc et les temps de référence du butin doivent être raccordés une fois les statistiques réelles calibrées ; il ne faut pas attribuer six minutes de récompenses à un adversaire prévu pour quarante-cinq secondes.

La probabilité de nommé concerne le **modèle focalisé**, pas chaque modèle de la table simultanément. Les trois armes de classes différentes d’un même gardien n’offrent pas trois jets de 5 % en parallèle.

Une cache contient une pièce et une chute ; on ne détruit pas obligatoirement la pièce pour recevoir sa progression garantie. Un même anneau d’ensemble ne compte qu’une fois, même porté en deux exemplaires : le deuxième peut garder ses statistiques, servir à une autre classe, se vendre ou se recycler.
''')
rows=[]
for shared,label in [('1','Ensemble avec arme : 1 position partagée'),('2','Ensemble avec collier : 2 positions partagées')]:
    for mode,label2 in [('drops_only','Butin seul'),('with_crafting','Avec chutes ciblées')]:
        v=LOOT['first_four_piece'][shared][mode]
        rows.append([label,label2,f(v['mean_hours'])+' h',f(v['median_hours'])+' h',f(v['p95_hours'])+' h'])
table(['Cas simulé','Méthode','Moyenne premier 4 pièces','Médiane','95e percentile'],rows)
add('''
Le calcul utilise 100 000 parcours par cas, à une cache par heure de référence. Le temps et les matériaux du craft, les achats au marché et le gain de vitesse d’un meilleur build ne sont pas inclus. La médiane décrit un ordre de grandeur de premier noyau de build, pas la durée pour obtenir ses quatre pièces avec les meilleurs affixes.

Pour un nommé, après vingt victoires de référence, environ 35,8 % des joueurs n’auraient toujours pas vu le drop direct à 5 %. Ils auraient néanmoins réuni les vingt fragments spéciaux : deux heures nominales de victoires. **C’est une garantie de matière, pas une garantie d’objet fini en deux heures** : il faut encore les autres ingrédients et l’accès à la fabrication ou au commerce. Le délai moyen jusqu’au drop ou à ces matières est d’environ 77 minutes dans ce modèle simple.

Les plans de base des familles sont appris avec le niveau du métier ; le boss ne verrouille pas à lui seul la connaissance de toutes les recettes. Des plans rares de variations ou d’apparences peuvent se trouver en butin, mais un artisan pur doit pouvoir les acheter. Le combattant fournit les trophées et fragments ; l’artisan fournit le travail, les matières ordinaires, le choix d’une pièce précise et la chance de signature exceptionnelle.

### Répartition des filières
''')
table(['Production','Métier final','Fournisseurs et boucle'],[
 ['Pièces métalliques Forgefeu','Forge','Minage ; lanières de Tannerie ; étoffe commune de Couture'],
 ['Pièces de cuir Traqueur','Tannerie','Chasse pour peaux ; Bûcheronnage pour tanin ; fils de Couture'],
 ['Pièces textiles Runiste et capes','Couture','Agriculture pour fibres ; Tannerie pour attaches ; Enchantement pour gravures avancées'],
 ['Marteaux, haches, épées/boucliers, dagues','Forge','Minage + manches de Menuiserie + attaches'],
 ['Arcs et arbalètes','Menuiserie','Bûcheronnage + composants métalliques de Forge + corde de Couture'],
 ['Bâtons','Menuiserie','Bois préparé + élément gravé d’Enchantement'],
 ['Sceptres et grimoires','Enchantement','Support de Forge/Menuiserie/Joaillerie ou reliure de Couture'],
 ['Colliers et anneaux','Joaillerie','Minage ; perles de Pêche ; réactifs spécifiques'],
 ['Gemmes à talent','Joaillerie','Gemme brute + préparation d’Enchantement + composant de source'],
 ['Repas et potions','Cuisine / Alchimie','Pêche, Agriculture, Herboristerie et Chasse'],
 ['Réparations de combat','Métier de la pièce','Service avec matériaux ; PNJ de secours comme puits d’or, sans destruction de l’objet']])
add('''
Les quantités exactes de recettes sont volontairement différées. La profondeur de chaîne et les besoins de bas niveau doivent respecter le projet : pas dix métiers à haut niveau pour une seule pièce. Un fabricant de cape ne doit pas être obligé de maîtriser Forge pour terminer chaque commande.

### Le risque économique à corriger avant l’ouverture

Un équipement fini qui tombe souvent et rend 40 % de sa recette peut transformer le combat en meilleur récolteur du serveur. Exemple **hypothétique** : quatre pièces par heure, trente minutes de matières de récolte par recette, recyclage à 40 % = **48 minutes de récolte recréées par heure de combat**. On n’a même pas encore compté les caches et nommés. Le taux de 40 % n’est pas équilibré indépendamment du volume de loot.

Je propose pour les équipements de combat un recyclage en **poudres et fragments d’atelier**, utiles au perfectionnement et aux services, au lieu de rendre 40 % de toute leur recette ordinaire. La règle est identique pour une pièce fabriquée ou dropée : pas de différence cachée selon son origine. Les outils gardent leur recyclage actuel ; ce changement pour le combat est un arbitrage explicite, pas une modification déjà faite.

Le budget à surveiller est : `matériaux ordinaires recréés / heure de combat` face au rendement d’un récolteur dédié. Cible initiale proposée : moins de 10 % à temps égal. Si Louis préfère garder strictement 40 % de matières pour les armures aussi, les taux de pièces finies devront être abaissés ou leur coût de recette révisé. On ne peut pas figer les trois nombres séparément.

Les pièces et composants restent échangeables ; pas de rachat PNJ qui convertit ce surplus en or infini. Les fragments ont des versions par rang : aucun échange de composants 40 contre une recette 90 à taux favorable.

## 10. L’architecture des objets

### Classiques, ensembles et nommés
''')
table(['Type','Ce qui le rend intéressant','Compromis'],[
 ['Classique','Deux lignes fixes adaptées, bons jets, majeure libre sur les emplacements concernés','Aucun bonus d’ensemble ; sa souplesse doit valoir quelque chose'],
 ['Pièce d’ensemble','Contribue à une mécanique 2/3/4 ; huit positions au choix','La recherche du bonus impose des emplacements et une orientation de lignes fixes'],
 ['Nommé','Talent fixe particulier et lignes de Légendaire','Remplace la gemme majeure de sa place ; n’appartient pas à un ensemble dans ce lot'],
 ['Chef-d’œuvre','Exemplaire signé : lignes choisies au jet maximal et ligne bonus selon le système existant','Ne donne pas une majeure supplémentaire, ni une rareté supérieure ni un bonus de set 5 pièces']])
add('''
Les nommés de ce lot occupent l’arme ou le collier. Avec un nommé, il reste trois majeures libres ; avec deux, deux. La coiffe et le torse gardent donc une place pour des choix de gemme. Un objet nommé n’est pas automatiquement meilleur qu’un Légendaire classique portant la gemme exacte qu’un joueur recherche.

La rareté fixe le budget et le nombre de lignes, pas l’appartenance à un set. Le lot commence avec des ensembles Épiques et des nommés Légendaires ; une future pièce d’ensemble Légendaire n’aurait pas un deuxième talent caché en plus du set. Les traitements visuels Épique/Légendaire des équipements ordinaires peuvent demeurer.
''')
table(['Rareté du modèle','Lignes fixes','Lignes aléatoires','Talents'],[
 ['Commun','1','0–1','La rareté ne crée aucun talent'],['Rare','2','1–2','La rareté ne crée aucun talent'],['Épique','2','2–3','Set éventuel, majeure éventuelle'],['Légendaire','2','3–4','Majeure libre ou talent fixé pour un nommé']])
add('''
### Affixes et éléments

Les groupes envisagés sont Vitalité, Défense, Cadence, Critique, Dégâts critiques, Ténacité, Pénétration, Dégâts élémentaires, Puissance de soutien, Afflictions, Pression et Attaques de base. Un emplacement n’offre qu’un sous-ensemble cohérent. Il faut conserver assez de groupes distincts pour quatre lignes et la ligne bonus du chef-d’œuvre.

Le groupe élémentaire tire ensuite un type : Physique, Feu, Givre ou Foudre. **Un objet ne tire qu’une ligne de ce groupe.** Un bâton peut donc exister avec Givre sur un exemplaire et Feu sur un autre, sans deux modèles de bâton. Les armes de classe privilégient les types de leur répertoire ; les bijoux communs peuvent proposer les quatre types. Un build atypique de Saignement sur Runiste peut chercher ses lignes physiques sur ces bijoux, sans imposer du Physique à tous les bâtons.

Le nom d’un set n’impose pas son élément. Cendres valorise les afflictions choisies ; Orage valorise une rafale ; Incise valorise les formes de rune. Un affixe Givre n’applique pas un ralentissement et un affixe Feu ne crée pas une brûlure. Une brûlure vient d’un sort ou d’un talent qui la prévoit.

Un plastron offensif de Forgefeu peut porter Puissance + Critique ; il n’est pas forcé de consacrer toutes ses lignes à la Défense parce qu’il ressemble à une armure. Les silhouettes restent liées aux familles compatibles de classe ; les choix statistiques restent ouverts à l’intérieur de ces familles.

### Amélioration, rangs et recherche du bon jet

Je conserve le principe **pas de montée de palier ni de rareté de l’exemplaire en V1**. On trouve ou fabrique un nouvel exemplaire du rang suivant. Le set garde sa mécanique et sa clé de pièce ; il n’a pas besoin d’un nouveau nom et d’une nouvelle liste de bonus tous les dix niveaux.

Les modèles de conception du lot se déclinent aux rangs 40, 60, 80 et 90. Le catalogue classique garde ses tranches plus fréquentes. Cela réduit la redondance des sets sans supprimer les paliers d’équipement de progression. Les 298 modèles listés ici sont les variantes de base ; les futures entrées de palier et leurs chiffres ne sont pas présentées comme déjà créées.

Le perfectionnement améliore une ligne déjà présente, sans changer son type ni en inventer une. Point de départ proposé : +10 points de la plage du jet par service, plafond 90 %, coût croissant. Le chef-d’œuvre reste la manière rare d’obtenir les lignes choisies au maximum et sa ligne supplémentaire. Aucun reroll de talent ou d’élément n’est ajouté silencieusement. Les plafonds et coûts du service attendent les recettes et les prix.

Un mauvais jet peut ainsi se vendre à un budget plus faible, être amélioré si les bonnes lignes sont présentes, servir à une autre classe compatible ou fournir une poudre de service. Tous les modèles ne resteront pas optimaux au niveau 99 : un équipement de palier a déjà une utilité s’il rend une tranche de progression intéressante.

## 11. Les dix-huit ensembles

Chaque ensemble comporte huit pièces possibles par classe compatible, dont six vêtements, un anneau et un collier ou une arme. On en porte deux, trois ou quatre pour ses bonus ; pas de bonus cinq à huit. Deux exemplaires du même anneau ne valent qu’une pièce canonique, même avec un autre rang. Les statistiques des deux anneaux restent utilisables.

Les douze ensembles partagés créent des interactions ; les six propres aux classes modifient leurs mécanismes. Les huit positions sont volontairement généreuses : elles évitent qu’une arme nommée précise rende impossible le mélange recherché.
''')
for idx,s in enumerate(P['sets'],1):
    scope='Trois classes' if len(s['classes'])==3 else CL[s['classes'][0]]['name']
    add(f"### {idx}. {s['name']}\n\n**{scope} · Épique · première version 40 · source : {RG[s['source']]['name']}.**\n\n{s['theme']}\n\n**Lignes fixes proposées :** {' + '.join(STAT[k] for k in s['stat_groups'])}. Les valeurs par emplacement ne sont pas calibrées.")
    table(['Pièces','Bonus'],[[n,s['bonuses'][n]] for n in ['2','3','4']])
    add('**Assemblages à essayer :** '+' '.join(s['synergy'])+'\n\n**Limite :** '+s['watch'])
    rows=[]
    for slot in s['slots']:
        r=[SLOT[slot]]
        for c in P['classes']:
            found=next((m for m in M if m['set_id']==s['id'] and m['slot']==slot and c['id'] in m['classes']),None)
            r.append(found['name'] if found else '—')
        rows.append(r)
    table(['Pièce canonique','Forgefeu','Traqueur','Runiste'],rows)
add('''
### Répartitions d’équipement

4+4 n’est pas le seul objectif. 4+3+2 avec deux nommés est un choix concret des plans joints. Selon les positions disponibles, 4+4+3, 4+3+2+2, 3+3+3+2 ou cinq bonus de deux pièces peuvent aussi être construits ; ils ne réservent pas tous une place à un nommé. Leur puissance doit se comparer au même budget d’objets et de talents.

Les 273 paires contrôlées représentent 91 associations possibles par classe : ses douze sets communs et ses deux sets propres. Chacune peut porter quatre pièces de chaque set avec une arme et un collier nommés. Ce résultat prouve une liberté **d’emplacements** ; il ne prouve pas que chaque paire a une synergie ou le même rendement.

## 12. Les vingt-quatre objets nommés

Tous sont Légendaires dans ce lot : deux lignes fixes, trois à quatre aléatoires, un talent fixé qui occupe une majeure. Le type d’arme oriente sa silhouette et sa cadence, pas l’élément de tous les sorts. Les six premiers modèles de niveau 20 comprennent deux armes par classe ; leurs sources avancées peuvent aussi fournir les nouveaux exemplaires de palier.
''')
for c in P['classes']+[{'id':None,'name':'Colliers universels'}]:
    add('### '+c['name'])
    seq=[n for n in P['named_items'] if (n['classes']==[c['id']] if c['id'] else len(n['classes'])==3)]
    for n in seq:
        source=BO[n['source']]['name']
        if n.get('additional_source'):source+=' ; autre source : '+BO[n['additional_source']]['name']
        add(f"**{n['name']}** · {FAMILY[n['family']]} · premier rang {n['first_tier']} · {source}.\n\n{n['talent']}\n\nÀ essayer : {' '.join(n['synergy'])}\n\nLimite : {n['watch']}")
add('''
Deux talents ont été revus parce qu’ils seraient autrement moins intéressants qu’une gemme libre : le Dernier Avertissement ajoute une relecture de rune à sa Marque conditionnelle ; le Fil du retour rend un soin au bénéficiaire initial en plus du marquage. Un talent fixe avec plus de contraintes et exactement le même résultat qu’une gemme n’a pas une identité suffisante.

## 13. Les gemmes

Une même majeure n’est active qu’une fois. Arme, torse, coiffe et collier fournissent quatre places au total, **nommés inclus**. Les autres places reçoivent des mineures de statistiques, sans déclencheur caché. Un chef-d’œuvre ou une rareté supérieure ne contourne jamais ce total.

Le lot chiffre une version de référence de chaque majeure. Je n’ajoute pas immédiatement quatre raretés qui changent chacune les clauses du talent : ce serait multiplier le nombre de règles avant d’avoir éprouvé la première. Les rangs de gemme et leur progression peuvent ensuite être calibrés avec le moteur réel.
''')
table(['Gemme majeure','Talent','Chemin qu’elle ouvre'],[[g['name'],g['talent'],g['purpose']] for g in P['gems']])
add('### Mineures statistiques')
table(['Famille','Statistique'],[[g['name'],STAT[g['stat_group']]] for g in P['minor_gems']])
add('''
Les majeures s’extraient et se réutilisent avec un coût de matériaux/service ; changer de pièce ne détruit pas le cœur du build. Le niveau du métier sert à fabriquer la gemme, le niveau de classe sert à porter sa version de combat. Les gemmes de métier restent un catalogue distinct, porté par les équipements de métier : aucune obligation de combattre pour le récolteur.

## 14. Synergies, choix et limites

Une association intéressante relie une source et un usage, puis pose un compromis. Deux sets qui ajoutent chacun des dégâts indépendants ne constituent pas automatiquement une interaction. Les exemples suivants sont des chemins ; ils ne sont pas les seuls builds autorisés.
''')
table(['Chaîne','Ce qu’elle permet','Ce qui l’empêche de tout faire'],[
 ['Chauffes → Trempe → Recuit → nouvelle Trempe','Changer le tempo du Forgefeu avec moins de Chauffes intermédiaires','Une seule Braise rendue, délai 8 s ; la suivante n’est pas forcément maximale'],
 ['Trempe-Rouge → Rebattue → Vigie / Rivets','Faire travailler les attaques de base après une dépense','Vigie demande une vraie fenêtre sans compétence ; une nouvelle Trempe remplace sa réserve'],
 ['Enclumier → Assise → Chauffe','Conserver des dégâts utiles tout en préparant Pression et affaiblissement','L’Assise n’est utilisable que par une Chauffe, pas par toutes les ripostes'],
 ['Repérage → Angle → Poursuite → Battue','Garder un jeu de Proie avec une réponse aux groupes','Un seul Angle consommé ; le coup secondaire n’en crée pas un autre'],
 ['Poursuite → Ordre → compétence de compagnon → Meute','Soutien offensif avec une vraie alternance porteur/compagnon','L’Ordre attend une intervention suivante ; ni pet autonome ni déclenchement en cascade'],
 ['Sœurs silencieuses → affliction → Cendres','Un Piégeur peut faire un build d’afflictions','Le contrôle de classe prépare le Saignement, la gemme de ralentissement ne suffit pas'],
 ['T–T–C → Palimpseste / Dernier Avertissement','Revenir à une rune sans recopier un gros sort entier','Les copies restent secondaires, ne s’écrivent pas et ne fabriquent pas d’Encre'],
 ['T–S–T → Incise → sort suivant','Une ponctuation qui combine attaque et protection','L’Incise attend une action suivante ; ce n’est pas un bonus gratuit à chaque alternance'],
 ['Sceau natif → absorption réelle → Encre → Trait','Convertir une protection utile en dégâts de Glyphiste','PV max, sursoin et bouclier d’équipement ne remplissent pas l’Encre'],
 ['Soin natif → Fil du retour → attaque → Marque','Un soutien peut investir Empreinte et continuer à aider','Le soin de retour est secondaire et ne prépare pas un nouveau Fil'],
 ['Bouclier natif → Enclume ou Revers','Couvrir deux issues d’une garde, bris/absorption ou expiration','Prendre les deux sets consomme huit pièces ; une expiration ne vaut jamais un bris'],
 ['Compétence longue → Intervalles → compétence courte','Construire une frappe préparée sur les cooldowns','Seuils de base ≥18 / ≤12 s, pas les cooldowns modifiés par Cadence'],
 ['Marque → Empreinte / Vigie / Murmure-d’épine','Plusieurs façons d’exploiter la désignation d’une cible','Changer de cible perd la préparation d’Empreinte ; tous les effets ne sont pas bons en groupe'],
 ['Brûlures et Saignements → Part du feu → Passeurs','Entretenir plusieurs applications et sauver un investissement à la mort','Trois applications par type/porteur ; extensions bornées ; transfert du restant seulement'],
 ['Pression → Fracture ou Ronces → fenêtre de dégâts','Faire du contrôle une ouverture offensive même sur boss','Vulnérabilités non cumulables ; récupérer de la Stabilité bloque les crédits artificiels']])
add('''
### Des incompatibilités qui doivent être visibles

Un plan sans soin natif ne fait pas fonctionner Fil du retour avec un simple soin de gemme. Un plan sans bouclier de compétence n’alimente pas Encre ou la Réserve à partir de Bastion. Une gemme Souffle polaire ouvre Frimas mais pas les Scellés du Sigillaire. Un set Fracture ne considère pas tout ralentissement comme une perte de Stabilité. Une arme sans affliction et sans gemme appropriée ne suffit pas à lancer Cendres.

Ces limites ne servent pas à punir l’expérimentation : l’éditeur les explique avant le lancement. On peut équiper une combinaison inhabituelle ; le jeu signale simplement « aucune source connue pour ce déclencheur » et montre ce qui manque.

## 15. Vingt-sept plans d’exemple

Chaque voie a trois points de départ. Leurs sorts, leurs déclencheurs et parfois leur répartition de pièces changent. Ils sont vérifiés pour les emplacements, pas proposés comme trois solutions définitives qui remplaceraient la recherche du joueur. Tous réservent quatre talents majeurs au total.
''')
for b in P['builds']:
    add(f"### {b['name']} — {CL[b['class_id']]['name']} / {PA[b['path_id']]['name']}\n\n**Pièces :** "+' + '.join(f"{v} {ST[k]['name']}" for k,v in b['sets'].items())+'.\n\n**Nommés :** '+', '.join(NM[n]['name'] for n in b['named'])+'. **Gemmes majeures :** '+', '.join(GM[g]['name'] for g in b['gems'])+'.')
    table(['Délai d’ouverture','Sort au niveau 40','Sort au niveau 80'],[[str(a['offset'])+' s',SP[a['spell']]['name'],SP[z['spell']]['name']] for a,z in zip(b['plans']['40'],b['plans']['80'])])
    rows=[]
    for slot,item in b['equipment'].items():
        if item.get('model_id'):label=next(m['name'] for m in M if m['id']==item['model_id'])
        elif item.get('named_id'):label=NM[item['named_id']]['name']
        else:label='Classique adapté au plan ; majeure libre si la place en offre une'
        rows.append([SLOT[slot],label])
    table(['Emplacement','Pièce'],rows)
add('''
Le plan Givre du Sigillaire au niveau 80 n’utilise que des sorts de Givre : Trait de gel, Cercle de givre, Sceau d’arrêt, Anneau de silence et Ligne de partage. Il fonctionne par ses formes et son contrôle natif ; il n’a pas besoin d’un bâton nommé « de Givre » différent du bâton de Feu. Au niveau 40, le plan joint emploie une garde Foudre ; un joueur peut préférer quatre sorts de Givre plutôt que remplir sa cinquième place à tout prix.

## 16. Résultats du banc et portée de l’équilibrage
''')
add(f"Le banc joint a exécuté **{R['simulations']:,} combats** pour les plans de référence, les baselines et la sensibilité (séparateurs anglais dans les fichiers de données). La recherche de sets ajoute **{SEARCH['screen_simulations']+SEARCH['finalist_simulations']+SEARCH['stress_simulations']:,} combats** : {SEARCH['screened_assemblies']} assemblages 4+4 criblés sur trois profils, puis {SEARCH['finalists']} finalistes revus sur les six profils et huit graines, ainsi que des essais de danger accru. Les {TEST['tests']} vérifications de règles et de références sont passées.")
add('''
Les 27 plans sont comparés avec le répertoire disponible à 40 puis à 80, douze graines par profil et des statistiques normalisées. Les six profils sont cible durable, groupe compact, charge lourde, usure, garde et soin ennemi. Les neuf baselines sans sets ni majeures conservent les mêmes statistiques de référence : elles testent un kit avec équipement classique neutre, pas un personnage nu.

**Aucun échec observé sur les 324 combinaisons plan/palier/profil du test de référence.** Douze victoires ne prouvent pas un taux réel de 100 % ; les écarts de statistiques et scripts réels restent à tester. Le criblage initial à une graine sert à chercher des problèmes, pas à déclarer une méta officielle.

Dans le tableau suivant, chaque case retient le meilleur temps médian des trois plans de la voie au répertoire 80. C’est un résumé d’efficacité parmi ces plans, pas l’annonce qu’un seul plan gagne tout.
''')
scenarios=P['simulation_parameters']['benchmark_scenarios']
rows=[]
for c in P['classes']:
 for pa in c['paths']:
  vals=[]
  for sc in scenarios:
   rr=[r for r in R['rows'] if r['level']==80 and r['path_id']==pa['id'] and r['scenario']==sc['id'] and r['win_rate']==1]
   vals.append(f(min(x['median_time'] for x in rr))+' s' if rr else 'à revoir')
  rows.append([c['name']+' · '+pa['name']]+vals)
table(['Voie']+[s['name'] for s in scenarios],rows)
rows=[]
for c in P['classes']:
 for pa in c['paths']:
  v=[x for x in R['rows'] if x['level']==80 and x['path_id']==pa['id']]
  rows.append([pa['name'],f(100*statistics.mean(x['median_hp'] for x in v))+' %',f(100*statistics.mean(x['gear_damage_share'] for x in v))+' %'])
table(['Voie','PV finaux moyens des médianes · plans et situations confondus','Part moyenne des dégâts directement produits par l’équipement'],rows)
add('''
La dernière colonne ne mesure pas la valeur totale de l’équipement : ses statistiques, protections, états et multiplicateurs influencent aussi la rencontre. Elle sert seulement à surveiller un système où le personnage ne ferait qu’activer des coups gratuits. Les résultats ne permettent pas de quantifier la valeur d’un soigneur dans un vrai groupe.

### Ce que les essais ont fait changer

Orage était trop généraliste : alterner deux compétences quelconques était presque gratuit pour toutes les classes. Il demande maintenant une rafale de deux sorts différents à deux secondes d’intervalle au plus, avec un Écho limité. Vigie demandait elle aussi une alternance trop facile ; son quatre pièces exige désormais une place réelle laissée aux attaques de base. Palimpseste privilégie la relecture d’une forme, tandis qu’Incise privilégie A–B–A.

Les plans de soutien ont reçu de vraies variantes de groupe et d’attaque plutôt que trois plans monocibles presque identiques. Le passif Enclumier conserve une Assise offensive pour sa prochaine Chauffe. Deux nommés ont gagné une identité supplémentaire pour éviter d’être des versions plus contraintes d’une gemme.

Les tests vérifient notamment qu’un Ordre nouvellement créé attend la prochaine intervention, que la dépense de Braises ne se multiplie pas sur toutes les cibles, que les contrôles de zone affectent les bonnes cibles sans multiplier les compteurs, qu’un remplacement n’est pas une expiration et qu’un soin secondaire ne recharge pas une réserve native.

### Ce qu’il reste à vérifier

Le banc est volontairement limité : les trois plans de sorts par voie sont fixés ; la recherche change leurs paires de sets mais pas tous leurs talents majeurs, jets et horaires. Les statistiques sont normalisées. Les valeurs d’affixes, budgets par emplacement, résistances élémentaires et effets de Ténacité reçue ne sont pas évalués. Les six profils ne sont pas les dix-huit scripts détaillés de boss.

Les ensembles de protection comme Sceau, Revers et Rivets ne doivent pas être jugés seulement sur une course de vitesse à faible danger. Leur compétitivité en groupe n’est pas prouvée. Ils doivent rester en validation tant que les dégâts évités, les soins utiles et les parcours difficiles ne sont pas mesurés dans le moteur réel. Ajouter un set au catalogue ne suffit pas à lui garantir une place.

Les essais à +50 % et +100 % de dégâts ennemis servent de stress tests. Une difficulté à laquelle une voie n’a plus de réponse dans ses plans courants n’est pas à publier telle quelle ; on essaie d’abord d’autres sorts et équipements de cette voie avant d’exiger un changement de classe. Les résultats bruts sont joints, y compris les échecs. Ils ne sont pas effacés pour afficher une validation verte.

La cible de diversité reste au moins trois assemblages de fonctionnement différent proches du meilleur sur plusieurs types de rencontre. Il faut rechercher une domination sur le **gain attendu par heure, la fiabilité et le coût**, pas seulement le meilleur temps d’un combat déjà facile. Cette cible n’est pas certifiée pour tous les objets par le présent dossier.
''')
add('**Lecture des stress tests :** à +50 % de dégâts ennemis, chaque voie dispose d’au moins un de ses trois plans gagnant les quatre graines dans chacune des six situations. À dégâts doublés, le groupe compact révèle les limites ci-dessous. Ce petit échantillon n’est pas une probabilité finale de succès et ne recherche pas d’autres sorts ou jets défensifs.')
stress_rows=[]
for c in P['classes']:
 for pa in c['paths']:
  v=[r for r in SEARCH['stress'] if r['path_id']==pa['id'] and r['scenario']=='pack' and r['threat']==2.0]
  best=max(x['win_rate'] for x in v)
  stress_rows.append([pa['name'],f(best*100)+' %','Ne pas publier ce réglage comme passage obligatoire' if best<1 else 'Réussite de référence, pas garantie universelle'])
table(['Voie','Meilleur des trois plans · groupe à dégâts ×2 · 4 graines','Interprétation'],stress_rows)
add('''
Ces échecs sont un signal utile : avant de créer un rang supérieur en multipliant simplement tous les dégâts par deux, il faut tester d’autres sorts, budgets défensifs et formations pour chacune des neuf voies. Un rang permanent ne doit pas transformer une préférence de classe en blocage.

## 17. Contrat des effets et protection contre les abus

### Origine, action et résolution

Chaque action porte un identifiant racine, un propriétaire, une cible et une origine. On distingue attaque de base, compétence, mécanique native de classe, effet d’équipement et état persistant. Un multi-projectile est une seule action pour les compteurs ; le compagnon ne crée pas un second propriétaire qui contourne les plafonds.

Les conditions lisent l’état au début de l’action. Les préparations déjà présentes peuvent être consommées par l’action éligible. La compétence et sa mécanique native se résolvent ; les compteurs de l’équipement avancent une seule fois. Une préparation acquise pendant cette action attend la suivante. Un effet secondaire n’envoie pas un nouvel événement primaire et ne se déclenche pas lui-même.

Un état secondaire peut être une condition d’une **future** action primaire : la brûlure d’une gemme peut permettre au coup suivant d’avancer Cendres. Une fin d’affliction peut préparer un jeton pour une future action, avec son délai ; elle ne produit pas une attaque en chaîne. Les déclenchements différés ont une durée de vie, huit secondes par défaut. Les cooldowns de ces effets démarrent à leur consommation/activation effective ; un jeton expiré n’inflige rien.

Un effet ne peut pas relire comme événements primaires ses propres dégâts, soins ou contrôles. Les copies de rune d’un objet restent des copies d’équipement. La rune native lue par la classe fait partie de l’action de compétence ; sa protection peut contribuer à Encre. Les plaques passives et barrières d’équipement gardent leur origine et ne deviennent pas des protections de compétence par commodité.

### Plafonds et règles de cumul
''')
table(['Objet de la règle','Contrat proposé'],[
 ['Majeures','4 au total, doublon d’une même gemme inactif ; nommés inclus'],
 ['Pièce de set','Clé canonique set + pièce stable à travers classes, rangs et raretés ; anneau identique compté une fois'],
 ['Vulnérabilité','La valeur active la plus forte, jamais la somme ; limite initiale 10 %'],
 ['Affaiblissement','La plus forte réduction applicable ; les réserves à un coup sont consommées par un vrai coup'],
 ['Ralentissements','La valeur la plus forte ; cap boss 15 %, pas de gel de tout le calendrier'],
 ['Boucliers','Même source remplacée ; ni remplacement ni fin de combat ne déclenche une expiration'],
 ['Réserve secondaire','Banc : au plus 1,60 P de boucliers d’équipement simultanés ; total des gardes 4,50 P'],
 ['Sceau / Encre','Aide effective et absorption réelle, origine autorisée seulement ; pas de sursoin'],
 ['Afflictions','Une application par source et cible, trois par type et porteur ; rafraîchissement borné'],
 ['Extensions et transferts','Extension limitée par application ; transfert du montant restant, jamais des dégâts déjà faits'],
 ['Délais','Par porteur et identifiant d’effet, pas par cible, exemplaire, projectile ou compagnon'],
 ['PV maximum','Réserve de survie ; aucune conversion implicite en dégâts offensifs gratuits'],
 ['Changement de build','Pas de remise à zéro des délais ; snapshot au début d’une rencontre'],
 ['Mort et nouvelle cible','Cible vraiment vivante et distincte ; les préparations de cible ne revivent pas par changement d’interface']])
add('''
Les plafonds de bouclier en P sont un point de départ du banc, pas une limite finale. Ils permettent d’étudier les boucles sans faire d’un empilement de Vitalité une source d’invulnérabilité et de DPS à la fois. Il faudra leur donner une traduction claire dans le vrai budget de statistiques et l’interface.

### Sauvegarde et simulation hors ligne

L’autorité reste serveur. Il faut sauvegarder le snapshot de build, la rencontre, son index, l’horloge logique, les cooldowns, états, réserves et la position du générateur aléatoire. Réclamer un résumé deux fois ne peut ni rejouer les gains ni réinitialiser les tirages. Les tirages sont séparés par flux/logique pour qu’une variation d’animation ou un jet d’attaque ennemi ne reroule pas un affixe.

Je recommande une résolution déterministe par événements, avec reprise/checkpoint et un budget de calcul mesuré. Un échantillon de vingt combats peut servir à un **aperçu** du rendement ; il ne suffit pas, tel quel, pour attribuer le butin et garantir qu’un joueur qui ouvre l’onglet toutes les cinq minutes reçoit la même progression qu’un absent de seize heures. Les transitions, ressources et cooldowns rendent une extrapolation naïve fausse.

Il n’est pas nécessaire d’avoir une boucle permanente pour tous les joueurs : la résolution peut se faire à la demande, en lots, avec reprise si le calcul est long. Le moteur TypeScript partagé doit servir au serveur et au simulateur. Le banc Python livré ici n’a pas vocation à devenir une deuxième vérité de production.

Les coups de fouet s’appliquent au temps d’activité crédité : ils accélèrent la progression du temps de combat simulé et donc le nombre de rencontres, sans changer les cooldowns relatifs du plan ni offrir des statistiques PvP. L’autonomie de seize heures demeure une limite de temps réel. Cette intégration devra être vérifiée avec `advance`, les consommables et l’usure.

## 18. Préparer le PvP sans prétendre le régler maintenant

Le PvE et le PvP partageront classes, états, actions et règles de provenance. Les profils de résistance, de contrôle et les coefficients de mode doivent être séparés dans les données. Une correction de soin ou de bouclier en arène ne doit pas obliger à rendre un soutien injouable en donjon.

Les actions au même horodatage demandent une règle symétrique : résoudre les événements par phases ou par lot, pas toujours faire agir « joueur A » avant « joueur B ». L’ordre stable des effets doit aussi être indépendant de l’ordre d’un tableau de gemmes ou de l’identifiant de compte. Le banc solo fixe l’ordre de ses effets ; il ne résout pas encore les échanges simultanés d’un duel.

Je ne réintroduis pas de triangle automatique mêlée > tir > magie comme solution d’équilibrage. Les classes ont déjà des séquences et réponses ; un avantage de catégorie risquerait de remplacer le choix de build par le contre-classe gratuit. C’est une recommandation pour la suite, pas la suppression d’une décision PvP déjà définitive.

Le PvP a besoin d’une limite de contrôle dur propre au bénéficiaire. Piste testable : une réserve de Résolution qui autorise un budget de contrôle, se recharge avec le temps et transforme les tentatives excédentaires en une compensation modeste et bornée. Les ralentissements, silences et étourdissements ne doivent pas contourner mutuellement le même budget en changeant leur libellé.

Les boucliers et soins se testent en duel puis à trois, avec des durées cibles, des limites de pression et éventuellement une fatigue commune après un long combat. Pas de règle PvE « boss immunisé » copiée aveuglément sur un joueur. Pas de PvP obligatoire pour obtenir une gemme ou un set indispensable au PvE.

Les emplacements, les quatre majeures, la normalisation des procs, les préparations différées et les limites de cumul sont les fondations réutilisables. **Aucun duel PvP ni combat de groupe n’a été simulé ici.** Les valeurs de Résolution, le matchmaking et une éventuelle normalisation de l’équipement restent à concevoir au moment du prototype PvP.

## 19. Lisibilité pour le joueur

Le joueur doit pouvoir comprendre sa classe sans ouvrir ce dossier.

- **Forgefeu** : trois Braises visibles ; les sorts indiquent Chauffe ou Trempe. Le passif de voie tient en une courte carte.
- **Traqueur** : une Proie et un Angle visible ; les sorts indiquent Repérage, Poursuite ou intervention de compagnon.
- **Runiste** : une rune précédente visible ; chaque sort montre ce qu’il lit et ce qu’il écrit.
- **Plan** : cinq cartes, une ligne d’ouverture, des cooldowns ; priorité des cibles et exemple utilisable.
- **Objets** : deux lignes fixes, jets regroupés, bonus actifs et progression du set. Les détails de formule restent dans le volet avancé.
- **Compatibilité** : explication d’un déclencheur sans source, d’un doublon de gemme ou d’un anneau déjà compté.
- **Journal** : « Angle exploité », « 2 Braises dépensées », « Rune Sceau lue », « 15 Stabilité retirée » ; le résultat explique le choix.

Les douze groupes d’affixes sont une bibliothèque de données, pas douze jauges à afficher autour du personnage. Les compteurs internes des sets restent des petites préparations d’état, pas une seconde interface de classe. Les informations avancées se déplient à la demande.

Un atelier de simulation sans gain permet de comparer deux plans possédés sur un adversaire déjà découvert. Les simulations n’inventent pas d’objets et n’augmentent pas l’XP. Les presets et le partage de build restent gratuits. Le chat et le clan peuvent rester ouverts pendant que l’activité continue : aucun besoin de surveiller une animation pour recevoir son butin.

## 20. Plan d’intégration au jeu actuel

### Étape A — contrats et moteur partagé

Formaliser les types de statistiques, d’états, de cibles et d’événements dans `packages/shared`. Ajouter le niveau par classe, les emplacements de plan et les snapshots. Garder le contenu en données validées. Le validateur vérifie les références, compatibilités et conditions de construction ; pas de valeurs de talent cachées dans React.

Les premiers tests portent sur l’ordre de résolution, les collisions de cooldowns, la dépense des ressources, la fin de cible, le contrôle converti et la reprise d’un combat. Le moteur de production et son simulateur utilisent les mêmes fonctions. Mesurer le coût d’une absence de seize heures sur le homeserver avant de choisir une stratégie de cache.

### Étape B — trois classes jouables, une tranche complète

Implémenter les mécaniques et les sorts communs des premiers niveaux, puis le premier passif et sort de chacune des neuf voies. Tester six adversaires simples : cible durable, groupe, charge, usure, garde, soin. Rendre visibles le plan, le journal et les métriques de réussite. Aucune nouvelle région ne compense une classe dont le kit ne tient pas.

La tranche verticale inclut les trois classes, pas un seul personnage privilégié. Les niveaux, changements de classe et sauvegardes de plans doivent fonctionner sans partager leur XP. Le terrain d’entraînement reste selon la règle validée : progression réduite et plafonnée au niveau de classe 40 pour ceux qui ne veulent pas affronter le contenu.

### Étape C — loot et filières

Brancher les victoires sur la création d’exemplaires existante, ajouter le snapshot des sources, les affixes à identifiants stables et la vitrine unitaire. Introduire les gemmes et leurs quatre places, deux nommés par classe puis quelques sets mécaniquement différents. Ajouter les filières de Tannerie, Couture, Joaillerie et Enchantement nécessaires aux recettes avant l’ouverture publique de la boucle complète.

Les quantités de recettes, le recyclage de combat et les taux de pièces finies se calibrent **ensemble**. Relancer le simulateur de marché avec les sources et puits de combat. Vérifier une population de vingt joueurs, pas seulement un marché idéal de deux cents spécialistes.

### Étape D — catalogue et contenu cible

Porter les 66 sorts, les 18 ensembles et les 24 talents nommés après les premiers retours. Déployer les branches de régions, leurs sources ciblées et les profondeurs. Mesurer temps de premier build, coût des services, pièces inutilisées, raisons de défaite et diversité réelle. Revoir ou retirer un modèle qui ne sert à aucun objectif à budget comparable.

Un set nouveau doit modifier une interaction identifiable ou occuper une niche de coût/progression ; un nouveau nom et une autre couleur ne suffisent pas. Les noms, variantes de silhouette et sources de ce dossier servent de catalogue, pas d’obligation de dessiner 298 fichiers avant de tester une seule mécanique.

### Étape E — groupes et PvP

Tester d’abord un groupe asynchrone de trois avec snapshots, bénéficiaires et butin personnel. Puis une arène de duel sans récompense de puissance exclusive. Ajouter les coefficients de mode et la Résolution seulement avec leurs tests. Un buff de groupe est évalué sur son budget total, pas sur une copie intégrale à chaque allié.

### Migrations à prévoir explicitement
''')
table(['Fichier ou système actuel','Travail nécessaire'],[
 ['`data/classes.yaml`','Références vers mécanique, voies, sorts et versions de règles ; conserver apparence et métier'],
 ['`gear_sets.yaml`','Passer d’une classe unique aux classes compatibles et d’un texte illustratif aux effets structurés'],
 ['`gear.yaml`','Créer les vraies entrées de palier et statistiques ; les modèles de conception JSON ne sont pas importables tels quels'],
 ['`gear_pools.yaml`','Identifiants de groupes, type élémentaire paramétré, conversion de score ; supprimer « élément de l’arme » ambigu'],
 ['`equipment.ts`','Compter les pièces canoniques, exposer les quatre majeures, rattacher les effets à leurs origines'],
 ['Schémas zod','Statistiques manquantes, règles d’effet, cibles, validité du plan et références de source'],
 ['`advance` et sauvegarde','Horloge de combat, état reprenable, idempotence des gains et version de contenu'],
 ['Marché / artisanat','Exemplaires échangeables, fabrication ciblée, perfectionnement et extraction de gemmes'],
 ['Anciens sets de démonstration','Ne pas additionner leurs anciens bonus aux nouveaux ; garder les prototypes hors des nouvelles tables tant que la migration n’est pas décidée']])
add('''
## 21. Arbitrages, risques et critères de validation

Je recommande d’adopter d’abord les mécaniques et les contrats d’événements. Les chiffres de talent et les taux de butin restent des paramètres. Il faut éviter d’engager l’illustration et toutes les recettes sur une règle qui n’a encore jamais été exécutée par le vrai moteur.
''')
table(['Point','Position proposée','Pourquoi il reste à valider'],[
 ['Ouverture','Une première rotation complète, puis répétitions sur cooldowns déjà écoulés','Autre interprétation possible : premières autorisations indépendantes'],
 ['Cinq sorts et ultime','5 dès 30 ; ultime prend une place','Choix lisible, mais à essayer en interface et sur les premiers joueurs'],
 ['Trois mécaniques','Braises / Angle ciblé / rune précédente','Différences de fonctionnement à confirmer par le ressenti, pas seulement par le DPS'],
 ['Ensembles','12 communs + 2 par classe ; huit pièces possibles','Conserver leur choix réel sans produire dix-huit solutions dont dix inutiles'],
 ['Nommés','Talent fixe qui remplace la majeure','Éviter de cumuler quatre gemmes et plusieurs talents gratuits'],
 ['Boss contrôlables','Stabilité et conversion des contrôles durs','Ni immunité totale, ni neutralisation permanente'],
 ['Puissance partagée','Dégâts, soins et gardes utilisent P ; affixes spécialisent','Préserver le soutien solo tout en donnant un coût aux meilleurs soins de groupe'],
 ['Recyclage combat','Poudres/fragments, pas 40 % de la recette entière','Changerait une généralisation possible de la règle actuelle ; arbitrage économique important'],
 ['Obtention','Focus, progression de cache, fragments échangeables','Les taux dépendent des recettes, de la vitesse réelle et du marché'],
 ['Statistiques','Scores et rendements décroissants','La multiplication des pourcentages actuels par les rangs ne peut pas s’extrapoler sans limite'],
 ['Rangs de sets','Nouveaux exemplaires 40/60/80/90, mêmes mécaniques','Compromis entre chasse au loot et remplacement répétitif'],
 ['Hors ligne','Même moteur, reprise déterministe, aperçu distinct des gains','Les échantillons moyens ne garantissent pas l’équivalence de progression'],
 ['PvP','Architecture prévue, coefficients et contrôle à éprouver plus tard','Aucune preuve d’équilibrage arène avec ce banc solo']])
add('''
Avant une bêta ouverte, les critères doivent inclure : au moins un plan utilisable par chacune des neuf voies dans chaque famille de rencontre ; plusieurs assemblages de fonctionnement distinct proches du meilleur ; aucune source de gain infini par recyclage, changement de cible ou répétition de requête ; mêmes résultats en avançant une activité par petits lots ou par une seule absence ; coût de calcul acceptable ; absence de métier de combat obligatoire pour un artisan ou récolteur.

Les joueurs doivent pouvoir expliquer pourquoi ils préfèrent une classe à une autre. S’ils ne parlent que du bonus quatre pièces et jamais de Braises, Proie ou runes, l’équipement a pris trop de place. S’ils ne peuvent pas changer de set sans casser tout leur personnage, la classe et la voie n’en ont pas assez.

## 22. Fichiers, reproduction et lecture par Claude

Le fichier principal constitue la proposition commune. Les données et scripts ne sont pas des migrations prêtes à appliquer au dépôt. Ils permettent de retrouver chaque référence, tester une modification et vérifier les effets avant de les porter au moteur partagé.
''')
table(['Fichier','Usage'],[
 ['`Bramo-coeur-du-jeu.md`','Texte complet à lire et annoter ; source du dossier de lecture'],
 ['`Bramo-coeur-du-jeu.html`','Même dossier, navigation, recherche et tableaux consultables hors ligne'],
 ['`projet.json`','Classes, voies, 66 sorts, sets, nommés, gemmes, contenu et 27 plans'],
 ['`modeles-ensembles.json`','298 variantes de base ; clés de pièce, classes, emplacements, familles et groupes fixes'],
 ['`sources.json`','Commit du dépôt et empreintes des fichiers de référence'],
 ['`banc_combat.py`','Banc solo indépendant ; `python3 banc_combat.py --seeds 12`'],
 ['`chercher_assemblages.py`','Criblage 4+4 et stress tests ; `python3 chercher_assemblages.py`'],
 ['`verifier.py`','Références, équipement et invariants ; `python3 verifier.py`'],
 ['`calculer_butin.py`','Estimation du premier 4 pièces et des fragments de nommé'],
 ['`resultats-*.json` et `recherche-assemblages.json`','Résultats bruts avec périmètre ; les échecs de stress restent visibles'],
 ['`verification-*.json`','Emplacements, références et règles contrôlées'],
 ['`diagnostic-diversite-initial.json`','Diagnostic initial qui a motivé la révision des effets trop généralistes']])
add('''
Ordre conseillé pour Claude : sections 1–7 pour les règles, 8–10 pour la boucle d’obtention, 11–15 pour le catalogue et les exemples, 16–18 pour les limites et garanties techniques, puis 20–21 pour préparer l’intégration. Confronter toute proposition aux dernières décisions de Louis. Ne pas transformer les coefficients du banc en valeurs définitives par simple copie.

Pour modifier les données : éditer `projet.json`, puis exécuter `verifier.py`, `banc_combat.py`, `chercher_assemblages.py` et `calculer_butin.py`. Les noms de fichier de résultat sont remplacés à chaque exécution ; conserver une version si l’on veut une comparaison. Reproduire une expérience implique de garder à la fois la version des données et celle du banc.

### Sources de référence
''')
for path in ['CLAUDE.md','docs/game-design.md','docs/design/combat-items.md','docs/design/monde.md','docs/design/metiers.md','docs/design/economie.md','docs/design/marche.md','data/classes.yaml','data/gear.yaml','data/gear_pools.yaml','data/gear_sets.yaml','data/gear_slots.yaml','packages/shared/src/engine/equipment.ts','packages/shared/src/schemas/gear.ts','sim/README.md']:
    add(f"- [{path}](https://github.com/Kairoli/Bramo/blob/{P['source_commit']}/{path})")
add('''
Les règles confirmées viennent du dépôt et de la conversation. Les sorts, mécanismes détaillés, chiffres, nouvelles sources et choix de cadence de ce dossier sont des propositions originales. Aucun conseil sur un autre jeu ni chiffre emprunté à The Division n’a servi de preuve d’équilibrage.
''')
text='\n'.join(out)
# Les listes de sources générées une à une doivent rester une liste continue.
import re
text=re.sub(r'(?m)^(\- \[[^\n]+)\n\n(?=\- \[)',r'\1\n',text)
(ROOT/'Bramo-coeur-du-jeu.md').write_text(text,encoding='utf-8')
print(json.dumps({'bytes':len(text.encode()),'words':len(text.split()),'headings':len(re.findall(r'^#{1,4} ',text,re.M))},ensure_ascii=False))
