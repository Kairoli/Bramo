"""Références, emplacements et invariants du banc ; pas des tests du jeu livré."""
from pathlib import Path
import collections,copy,itertools,json,re,unittest
from banc_combat import DATA,CFG,SPELLS,Battle,PROVENANCE
HERE=Path(__file__).resolve().parent
MODELS=json.loads((HERE/'modeles-ensembles.json').read_text())

class Structure(unittest.TestCase):
 def test_unique_ids(self):
  for key in ['classes','spells','sets','named_items','gems','regions','bosses','builds']:
   seq=DATA[key];self.assertEqual(len(seq),len({s['id'] for s in seq}),key)
   for s in seq:self.assertRegex(s['id'],r'^[a-z][a-z0-9_]*$')
 def test_counts(self):
  self.assertEqual([len(DATA[x]) for x in ['classes','spells','sets','named_items','gems','regions','bosses','builds']],[3,66,18,24,18,6,18,27])
  self.assertEqual(len(MODELS),298)
 def test_cross_references(self):
  classes={c['id']:c for c in DATA['classes']};bosses={b['id'] for b in DATA['bosses']};regions={r['id'] for r in DATA['regions']}
  for s in DATA['spells']:
   self.assertIn(s['class_id'],classes)
   if s['path_id']:self.assertIn(s['path_id'],[p['id'] for p in classes[s['class_id']]['paths']])
   self.assertIn(s['element'],DATA['rules']['element_types']+['inherit'])
  for s in DATA['sets']:self.assertIn(s['source'],regions)
  for n in DATA['named_items']:self.assertIn(n['source'],bosses)
  for b in DATA['bosses']:self.assertIn(b['region'],regions)
 def test_three_plans_per_path(self):
  self.assertEqual(set(collections.Counter(b['path_id'] for b in DATA['builds']).values()),{3})
  for b in DATA['builds']:
   for lvl,plan in b['plans'].items():
    self.assertEqual(len(plan),5);self.assertEqual(len({s['spell'] for s in plan}),5)
    for row in plan:
     s=SPELLS[row['spell']];self.assertEqual(s['class_id'],b['class_id']);self.assertLessEqual(s['level'],int(lvl))
     self.assertIn(s['path_id'],[None,b['path_id']])
 def test_eleven_places(self):
  md={m['id']:m for m in MODELS};nd={n['id']:n for n in DATA['named_items']}
  for b in DATA['builds']:
   eq=b['equipment'];self.assertEqual(set(eq),{'head','torso','hands','legs','feet','cape','belt','ring1','ring2','necklace','weapon'})
   count=collections.Counter();keys=[];names=[]
   for slot,item in eq.items():
    if 'model_id' in item:
     m=md[item['model_id']];self.assertIn(b['class_id'],m['classes']);self.assertEqual(m['slot'],'ring' if slot.startswith('ring') else slot)
     count[m['set_id']]+=1;keys.append(m['canonical_piece'])
    if 'named_id' in item:
     n=nd[item['named_id']];self.assertEqual(n['slot'],slot);self.assertIn(b['class_id'],n['classes']);names.append(n['id'])
   self.assertEqual(dict(count),b['sets']);self.assertEqual(len(keys),len(set(keys)));self.assertEqual(set(names),set(b['named']))
 def test_four_major_and_compatibility(self):
  for b in DATA['builds']:
   self.assertEqual(len(b['named'])+len(b['gems']),4);self.assertEqual(len(b['gems']),len(set(b['gems'])))
   for k in b['sets']:
    st=next(s for s in DATA['sets'] if s['id']==k);self.assertIn(b['class_id'],st['classes'])
 def test_all_pairs(self):
  v=json.loads((HERE/'verification-emplacements.json').read_text())
  self.assertEqual(v['total_pairs'],273);self.assertEqual(v['feasible'],273)
  checked=0
  for c in DATA['classes']:
   available=[s['id'] for s in DATA['sets'] if c['id'] in s['classes']]
   for a,b in itertools.combinations(available,2):
    sa={m['slot'] for m in MODELS if m['set_id']==a and c['id'] in m['classes'] and m['slot'] not in ['weapon','necklace']}
    sb={m['slot'] for m in MODELS if m['set_id']==b and c['id'] in m['classes'] and m['slot'] not in ['weapon','necklace']}
    feasible=False
    for choice in itertools.combinations(sa,4):
     used=set(choice);left=len((sb-{'ring'})-used)+(1 if 'ring' in sb else 0)
     # A et B peuvent prendre chacun leur anneau distinct ; capacité totale deux.
     if left>=4:feasible=True;break
    self.assertTrue(feasible,(c['id'],a,b));checked+=1
  self.assertEqual(checked,273)

def make(path='red_temper',gear=False):
 b=next(x for x in DATA['builds'] if x['path_id']==path)
 sc=copy.deepcopy(CFG['benchmark_scenarios'][0]);sc['hp']=100000;sc['enemy_damage']=0
 return Battle(b,sc,42,80,trace=True,gear=gear)

class Mechanics(unittest.TestCase):
 def test_cold_temper_still_hits(self):
  b=make();b.cast(SPELLS['fg_quench']);self.assertGreater(b.m['damage:skill'],0);self.assertEqual(b.heat,0)
 def test_heat_cap_and_spending(self):
  b=make()
  for i in range(5):b.cast(SPELLS['fg_workshop'])
  self.assertEqual(b.heat,3);b.cast(SPELLS['fg_quench']);self.assertEqual(b.heat,0);self.assertEqual(b.m['heat_spent'],3)
 def test_assise_waits_for_builder(self):
  b=make('anvil');b.heat=3;b.cast(SPELLS['fg_quench']);self.assertIn('class:assise',b.preps)
  b.t+=1;b.cast(SPELLS['fg_return']);self.assertIn('class:assise',b.preps)
  b.t+=1;b.cast(SPELLS['fg_workshop']);self.assertNotIn('class:assise',b.preps);self.assertGreater(b.m['damage:class'],0)
 def test_hunt_needs_existing_angle(self):
  b=make('beastslayer');b.cast(SPELLS['tr_pursuit']);self.assertEqual(b.m['angles_consumed'],0)
  b.t+=1;b.cast(SPELLS['tr_read']);b.t+=1;b.cast(SPELLS['tr_pursuit']);self.assertEqual(b.m['angles_consumed'],1)
 def test_new_pack_order_waits(self):
  b=make('packleader');b.cast(SPELLS['tr_read']);b.t+=1;b.cast(SPELLS['tr_packbeat']);self.assertEqual(b.m['pack_orders'],0);self.assertGreater(b.order,b.t)
  b.t+=1;b.cast(SPELLS['tr_whistle']);self.assertEqual(b.m['pack_orders'],1)
 def test_old_order_consumed_new_order_preserved(self):
  b=make('packleader');b.cast(SPELLS['tr_read']);b.t+=1;b.cast(SPELLS['tr_pursuit']);b.t+=1;b.cast(SPELLS['tr_read']);b.t+=1;b.cast(SPELLS['tr_packbeat'])
  self.assertEqual(b.m['pack_orders'],1);self.assertGreater(b.order,b.t)
 def test_rune_reads_previous(self):
  b=make('glyphkeeper');b.cast(SPELLS['rn_ember']);self.assertEqual(b.m['damage:class'],0);self.assertEqual(b.rune,'trait')
  b.t+=1;b.cast(SPELLS['rn_guard']);self.assertGreater(b.m['damage:class'],0);self.assertEqual(b.rune,'seal')
  b.t+=1;b.cast(SPELLS['rn_lightning']);self.assertTrue(any(x['source']=='native_rune' for x in b.shields))
 def test_element_does_not_invent_status(self):
  b=make('fulgurant');b.cast(SPELLS['rn_lightning']);e=b.enemies[0];self.assertEqual(e['slow_until'],0);self.assertFalse(e['dots'])
 def test_secondary_damage_no_action_credit(self):
  b=make();before=b.action;b.damage(b.enemies[0],500,'equipment');self.assertEqual(b.action,before);self.assertEqual(b.m['primary_actions'],0)
 def test_surplus_heal_not_support_credit(self):
  b=make('whetter',True);self.assertEqual(b.heal(100,True),0);self.assertEqual(b.sceau_pool,0)
 def test_secondary_heal_cannot_feed_reserve(self):
  b=make('whetter',True);b.hp-=200;b.heal(100,False);self.assertEqual(b.sceau_pool,0);b.heal(50,True);self.assertGreater(b.sceau_pool,0)
 def test_secondary_shield_cannot_make_ink(self):
  b=make('glyphkeeper');e=b.enemies[0];b.shield(100,'gear',False);b.incoming(e,100);self.assertEqual(b.ink,0)
  b.shields=[];b.shield(100,'spell',True);b.incoming(e,100);self.assertGreater(b.ink,0)
 def test_replacement_no_expiration(self):
  b=make('glyphkeeper',True);b.shield(100,'same',True);b.t=1;b.shield(100,'same',True);self.assertEqual(len([x for x in b.shields if x['source']=='same']),1);self.assertEqual(b.m['procs:named:seal_holds'],0)
 def test_replacement_releases_capacity_first(self):
  b=make();b.shield(CFG['total_shield_cap']*b.p,'big',True);b.shield(100,'big',True);self.assertEqual(sum(x['amount'] for x in b.shields),100)
 def test_secondary_shield_cap(self):
  b=make();b.shield(10000,'a');b.shield(10000,'b');self.assertLessEqual(sum(x['amount'] for x in b.shields),CFG['secondary_shield_cap']*b.p+1e-8)
 def test_boss_control_becomes_pressure(self):
  b=make('anvil');b.cast(SPELLS['fg_ring_anvil']);e=b.enemies[0];self.assertEqual(e['stun'],0);self.assertLess(e['stability'],CFG['stability'])
 def test_weak_slow_is_not_a_new_control(self):
  b=make();e=b.enemies[0];self.assertTrue(b.slow(e,.25,6));self.assertFalse(b.slow(e,.10,2))
 def test_slow_alone_not_fracture_credit(self):
  b=make('fulgurant');b.ss={'fracture':4};b.cast(SPELLS['rn_ash_ring']);b.t=1;b.cast(SPELLS['rn_ember'])
  self.assertNotIn('set:fracture',b.preps);self.assertEqual(b.m['pressure'],0)
 def test_weapon_base_dps_normalization(self):
  for family,period in CFG['weapon_periods'].items():
   damage=CFG['basic_damage']*period/CFG['basic_period'];self.assertAlmostEqual(damage/period,CFG['basic_damage']/CFG['basic_period'])
 def test_proc_does_not_consume_itself(self):
  b=make();b.action=1;b.put('test','damage',100);s={'tags':[],'element':'physical'}
  b.consume_preps(s,b.enemies[0],False);self.assertIn('test',b.preps);b.action=2;b.consume_preps(s,b.enemies[0],False);self.assertNotIn('test',b.preps)
 def test_vulnerability_strongest_only(self):
  b=make();e=b.enemies[0];b.vulnerability(e,.05,4);b.vulnerability(e,.06,4);d=b.damage(e,100,'equipment');self.assertAlmostEqual(d,95.4)
 def test_regen_is_not_instant(self):
  b=make();b.hp-=100;b.hot(40,4,'test');self.assertEqual(b.hp,b.hpmax-100)
 def test_opening_and_global_recovery(self):
  b=make();b.run();casts=[x for x in b.trace if x['kind']=='cast']
  first=casts[:5];self.assertEqual([x['t'] for x in first],[0,2,4,7,10]);self.assertEqual(len({x['spell'] for x in first}),5)
  self.assertTrue(all(y['t']-x['t']>=CFG['gcd'] for x,y in zip(casts,casts[1:])))
 def test_deterministic_seed(self):
  a=make('sigilbinder',True);b=make('sigilbinder',True);self.assertEqual(a.run(),b.run())
 def test_effect_input_order_irrelevant(self):
  source=next(b for b in DATA['builds'] if b['path_id']=='glyphkeeper');other=copy.deepcopy(source)
  other['sets']=dict(reversed(list(other['sets'].items())));other['named'].reverse();other['gems'].reverse()
  sc=CFG['benchmark_scenarios'][3]
  self.assertEqual(Battle(source,sc,41).run(),Battle(other,sc,41).run())
 def test_all_spell_handlers_smoke(self):
  for s in DATA['spells']:
   path=s['path_id'] or next(p['id'] for c in DATA['classes'] if c['id']==s['class_id'] for p in c['paths'])
   b=make(path);b.cast(s);self.assertGreater(b.m['damage:skill'],0,s['id'])
 def test_aoe_one_counter_credit(self):
  base=next(b for b in DATA['builds'] if b['path_id']=='red_temper');sc=copy.deepcopy(CFG['benchmark_scenarios'][1]);sc['hp']=100000
  b=Battle(base,sc,1,80,gear=False);b.ss={'cendres':4}
  for e in b.enemies:b.dot(e,'prior',1,'burn',30)
  b.cast(SPELLS['fg_furnace']);self.assertEqual(b.count['set:cendres'],1)
 def test_aoe_temper_bonus_main_target_only(self):
  base=next(b for b in DATA['builds'] if b['path_id']=='whetter');sc=copy.deepcopy(CFG['benchmark_scenarios'][1]);sc['hp']=100000
  cold=Battle(base,sc,4,80,gear=False);hot=Battle(base,sc,4,80,gear=False);hot.heat=3
  cold.cast(SPELLS['fg_great_temper']);hot.cast(SPELLS['fg_great_temper'])
  self.assertLess(hot.enemies[0]['hp'],cold.enemies[0]['hp']);self.assertEqual(hot.enemies[1]['hp'],cold.enemies[1]['hp'])
 def test_aoe_slow_hits_each_target_once(self):
  base=next(b for b in DATA['builds'] if b['path_id']=='sigilbinder');sc=copy.deepcopy(CFG['benchmark_scenarios'][1]);sc['hp']=100000
  b=Battle(base,sc,4,80,gear=False);b.cast(SPELLS['rn_frost_circle'])
  self.assertGreater(b.enemies[0]['slow_until'],0);self.assertGreater(b.enemies[1]['slow_until'],0);self.assertEqual(b.enemies[2]['slow_until'],0)

if __name__=='__main__':
 suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(Structure),unittest.defaultTestLoader.loadTestsFromTestCase(Mechanics)])
 runner=unittest.TextTestRunner(verbosity=2);result=runner.run(suite)
 report={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'successful':result.wasSuccessful(),'provenance':PROVENANCE,'scope':'Banc indépendant et références du dossier, pas le moteur de jeu TypeScript.'}
 (HERE/'verification-regles.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 raise SystemExit(0 if result.wasSuccessful() else 1)
