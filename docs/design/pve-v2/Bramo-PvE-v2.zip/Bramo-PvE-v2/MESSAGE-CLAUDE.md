# Pour Claude — révision zones et outils de situation

Lis `Bramo-PvE-v2.md`, puis `verification/RESULTATS.md`. Base étudiée : `main` au commit `c120336036ae2ee6bff6d9f509ede1d26c892094`.

La refonte remplace les anciennes « réponses par rôle » par six familles de mécanique, chacune reliée à deux zones : fenêtres, érosion, lourds/charges, renforts, garde et aura. Six sets avec paliers2/3/4 qui améliorent un même effet, six gemmes majeures alternatives, six préparations. Pas de classe ou d’élément obligatoire ; set/gemme/préparation de même famille ne s’additionnent pas. Les noms déjà utilisés remplacent leurs anciens effets après rapprochement des identifiants, pas en parallèle.

Les douze rencontres de `sim/proposals/zones-v2/combat.yaml` passent le schéma et `buildCombatContent` actuels. `zones-v2-fury` ajoute des délais de fureur mesurés sur une référence équilibrée. Elles ont été jouées avec `fight()` du jeu ; les sorties complètes sont fournies. Le témoin sans fureur sert à isoler les réponses, pas à produire une route infinie sans limite de durée.

**Aucune affinité d’équipement n’a été simulée** : les effets ne sont pas encore dans le moteur. `design/*.yaml` est un contrat de conception, pas du `CombatPatch` directement chargeable. Les gains1,25–1,40 sont des objectifs. Les primitives et leur ordre exact sont dans `design/extensions-moteur.md`.

À surveiller avant de conclure :

- l’actuel `combat-search` ne monte que les dégâts ennemis et commence les sorts à0 ; brancher PV×danger^1,5, recherche d’ouverture≤10 s, équipement et priorité de cible ;
- l’aura ignore `enemyDamageScale` ; aura/érosion ignorent la fureur : corriger sans double multiplication ;
- la priorité renfort/chef n’existe pas encore ; son contrat prépare le ciblage sans action en combat et respecte l’Angle du Traqueur ;
- Repli couvert proposé :12 % PV max personnels pendant8 s, cooldown18 s ; pas `shield:3.36` fixé à P100, ni relèvement global des caps ;
- le +10 % de P/PV des tests est une ancre synthétique, pas encore la courbe réelle des objets ;
- le groupe4 DPS requiert actuellement+15 %, alors que le critère strict est+10 % : le résultat reste à rapprocher du but ;
- une gemme de situation occupe une majeure existante ; un talent de nommé conserve le même coût. Aucun emplacement supplémentaire.

Après les statistiques réelles (5a), intégrer les effets et rejouer les acceptations de `design/verification.yaml`. Publier les échecs et les cas les plus faibles, pas seulement une moyenne. Au moins six zones doivent donner+25 % de mur pour chaque voie avec leur outil adapté ; chaque famille set/gemme doit être première dans deux zones ; chaque voie doit atteindre×1,5 avec son meilleur outil. Rejouer les quatre principes de groupe, dont l’écart d’équipement≤10 % et l’absence de domination des groupes sans DPS.

Les scripts de `verification/` ne contiennent aucun moteur séparé : ils importent directement celui du dépôt. Commandes dans `README.md`. Ne pas présenter ce catalogue comme adopté ou équilibré avant ces essais.
