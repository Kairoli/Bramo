# Bramo — PvE v2

Lire d’abord `Bramo-PvE-v2.md` (ou le HTML autonome), puis `verification/RESULTATS.md` et `MESSAGE-CLAUDE.md`.

## Nature des fichiers

- `sim/proposals/zones-v2/combat.yaml` : rencontres natives, sans fureur, pour isoler les mécaniques.
- `sim/proposals/zones-v2-fury/combat.yaml` : variante native avec fureur, point de départ pour la route.
- `design/` : données de conception **non exécutées** par le moteur actuel ; elles demandent les extensions décrites.
- `verification/` : scripts qui importent le moteur TypeScript du dépôt, résultats complets et audit des rapports sources.

Les gains d’affinité sont des cibles ; seuls les essais identifiés comme mesurés dans `RESULTATS.md` ont été exécutés. Ni les fichiers du jeu ni les valeurs de production n’ont été modifiés par ce dossier.

## Rejouer la validation et les essais de base

Depuis un checkout du dépôt ayant ses dépendances installées, remplacer le chemin d’exemple par celui où le ZIP a été extrait :

```bash
pnpm --filter @bramo/sim exec tsx /chemin/Bramo-PvE-v2/verification/verify-native.mts "$PWD"
pnpm --filter @bramo/sim exec tsx /chemin/Bramo-PvE-v2/verification/reference-fury.mts "$PWD"
```

Le premier script réécrit seulement `verification/fumee-moteur.json` dans le dossier extrait. Le second régénère la variante `zones-v2-fury` et son rapport dans ce même dossier. Ils ne copient rien dans le dépôt et ne modifient pas le moteur. Ils ont été exécutés sur le commit indiqué, avec les dépendances TypeScript/yaml/zod du projet.

Pour la recherche native existante, copier volontairement le dossier de proposition `zones-v2` sous `sim/proposals/`, puis :

```bash
pnpm --filter @bramo/sim sim combat-search --proposal zones-v2 --levels 40,80
```

Cette commande actuelle teste **le kit seul et le danger sur les dégâts seuls**. Elle est utile pour comparer au témoin de Claude ; elle ne vérifie pas encore la pente couplée, les nouveaux talents ni les ouvertures optimisées. Les extensions à ajouter sont spécifiées dans `design/verification.yaml` ; leurs noms ne sont pas des flags CLI existants.

## Provenance et statut

Dépôt `Kairoli/Bramo`, commit `c120336036ae2ee6bff6d9f509ede1d26c892094`,22 octobre2026. Audit source SHA-256 dans `verification/sources-et-rapports.json`. Toutes les valeurs nouvelles sont **proposées, à équilibrer**. L’économie et les activités collectives du dossier précédent restent la base ; pas de nouveaux quotas, résistances élémentaires ou classes à monter obligatoirement.
