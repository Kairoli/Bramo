# Contrats d’exécution — proposition PvE v2

Ces extensions sont **à développer dans le moteur partagé**, puis à tester dans `sim combat-search`. Le dossier ne contient aucun second moteur de combat. `design/*.yaml` n’est pas du `CombatPatch` : ces fichiers ne doivent pas être copiés dans `data/combat` sans schéma et adaptateur.

## 1. Événements, origines et compteurs

Chaque événement porte `time`, `actionId`, `actorId`, `targetId`, `origin`, `source`, `amountBefore`, `amountAfter`, `usefulAmount`. Une action peut toucher plusieurs cibles, mais un effet n’est jamais réappliqué au même dégât. Origines natives : attaque de base, sort, mécanique de classe, dégât périodique natif. Origines secondaires : équipement, gemme, nommé, réflexion, restitution Interstice. Aucun effet secondaire ne redéclenche talent, Angle, Braises, phrase, Encre, critique, vol de vie ou effet « à la mort », sauf exception explicitement inscrite et testée dans le catalogue.

Toutes les actions restent serveur, déterministes, sans interaction pendant le combat. Les fenêtres sont des états de l’ennemi, pas des invitations à cliquer. Les réserves et délais démarrent à chaque rencontre ; aucune réserve ne se transporte dans le combat suivant. Les consommables de secours gardent leur stock entre salles. Les délais de sorts entre salles suivent la règle de donjon retenue ; les essais actuels les réinitialisent, limitation à conserver dans les rapports.

**Résolution de famille au départ :** choisir une seule variante active selon la priorité explicite set4 > gemme > set3 > préparation > set2. Les rangs sont une règle de résolution, pas une estimation automatique du meilleur rendement théorique. Afficher les autres comme redondantes ; ne jamais réveiller une variante plus faible pendant le délai de la variante retenue. Un Rinçage ne consomme aucun stock si une variante permanente de priorité supérieure est équipée. Les variantes d’une famille partagent donc un seul état et un seul délai, sans rotation cachée de procs.

Les PV maximum de référence d’un effet défensif sont ceux du porteur **au début du combat, repas compris**. Aucune hausse temporaire de PV ne permet de recréer gratuitement une réserve. Un soin secondaire ignore `supportPower` et ne peut pas ressusciter. Le budget de gemmes majeures et de talents nommés reste celui déjà décidé ; un nommé occupe la place d’une majeure.

## 2. Ordre des opérations

**Dégâts sortants natifs** : coefficient natif → critique/défense/vulnérabilité existants → multiplicateur Battue si renfort → fenêtre → collecte de la perte réellement imputable à cette fenêtre → garde et Fracture → PV. La restitution Interstice est un montant déjà calculé après les multiplicateurs natifs ; on ne lui applique pas à nouveau critique, défense ou vulnérabilité. Elle subit la garde présente, sans bonus Fracture, et ne part que dans une fenêtre ouverte.

**Dégâts entrants directs** : danger → fureur → réduction native du personnage → affaiblissement natif ennemi le plus fort → atténuation Impact → boucliers natifs existants → réserve de Repli couvert → PV. Impact est une atténuation conditionnelle, pas un bouclier : il ne remplit pas les plafonds actuels en P et n’alimente pas l’Encre. Le plafond de 75 % concerne uniquement l’atténuation d’équipement sur ce résidu ; il ne remplace pas les règles natives. La famille Impact utilise au plus 65 % de ce résidu et 25 % des PV max par déclenchement.

**Érosion** : application d’une charge → effet de purification natif déjà lancé ce pas, s’il existe selon l’ordre du moteur → événement `erosion_stack_applied` → une seule purge d’équipement disponible → dégât périodique. Aucun soin de Reprise sur ce dégât.

**Aura** : immunité native de purification → danger et fureur → autres atténuations explicitement compatibles avec l’aura → perte de PV → si le porteur est encore vivant, alimentation Reprise → restitution disponible en fin de pas. Une aura létale tue avant la restitution ; aucun « remboursement » rétroactif ne sauve ce coup.

Le moteur actuel lance les actions des personnages avant les phases ennemies du pas. On conserve cette convention : une purification qui vient de partir peut retirer les anciennes charges, puis une nouvelle charge arriver juste après. Ne pas traiter la purification native comme une immunité future à l’érosion.

## 3. Six primitives d’équipement

### A. `store_window_loss` — Interstice

Le calcul reçoit le dégât natif avant fenêtre `x`, le dégât après fenêtre `y`, et la capacité encore utile de la cible `C = PV + garde`. Perte éligible : `max(0, min(x,C) - min(y,C))`. Cela évite de stocker du sur-dégât théorique sur une cible presque morte. Ajouter `perte × storeFraction` à une réserve indexée par chef, avec un plafond global par porteur `bankCapPower × puissance de début de combat`.

À la première **attaque de base ou action de sort native** qui touche ce même chef dans la fenêtre ouverte suivante, vider sa réserve en un seul dégât `window_release`. Un tick de DoT ne déclenche pas la restitution. Un sort déjà lancé avant l’ouverture ne change pas rétroactivement d’horaire. Une seule restitution par porteur et par cycle, même si plusieurs projectiles touchent. La réserve inutilisée expire à la fin de la fenêtre ouverte ; elle ne s’empile pas sur plusieurs cycles. La mort du chef efface sa réserve, sans report sur un renfort.

Une fenêtre fermée réduit encore les dégâts immédiats : même à 100 % de stockage, le joueur attend l’ouverture et doit survivre jusque-là. Hors fenêtres, le talent vaut zéro. Les paliers 2/3/4 remplacent le taux et le plafond précédents ; ils ne créent pas trois réserves.

### B. `remove_erosion_stacks` — Pluie

Après l’application d’une charge, si le total atteint deux et si le délai interne est prêt, retirer `min(removeStacks, charges présentes)`. Le délai commence uniquement si une charge est réellement retirée. Il est partagé entre toutes les sources de Pluie du porteur.

Set 4 : deux charges, délai 10 s. Gemme : deux charges, délai 16 s. Le moteur ne doit pas émettre en retour un événement « purification native » : pas d’immunité à l’aura, pas de soin ni de conversion de classe. Une potion de rinçage s’emploie seulement si aucune variante permanente plus forte n’a purgé l’événement ; elle ne consomme pas une charge de stock inutilement. Après une purge, l’érosion peut immédiatement recommencer à monter au prochain horaire prévu.

### C. `conditional_absorb` — Impact

Pour un résidu entrant `d` marqué `heavy_attack` ou `charge` :

`évité = min(d × incomingFraction, PVmax × maxHpFraction)`.

Retirer ce montant une fois, puis déclencher le délai interne. Les coups ordinaires, aura et érosion ne le déclenchent pas. Le délai est **par porteur**, partagé entre charges et lourds, pas par ennemi. Un événement réduit à zéro avant Impact ne consomme pas son délai. La variante la plus forte éligible s’applique ; aucune addition set + gemme + baume.

Exemple set 4, PV2800 : un résidu lourd de1000 perd650 ; un résidu de2000 perd700, le plafond de25 % PV. Le deuxième coup n’est donc pas réduit de moitié par miracle à toute profondeur. Les coefficients en part du coup et en part des PV sont tous deux nécessaires.

### D. `add_damage_multiplier` — Battue

Multiplier par1,8 au set4 les dégâts natifs visant un renfort actuellement présent (`add=true`, `arriveAt<=time`). Le supplément ne touche jamais un chef, ne se reporte pas par excédent et ne crée pas de buff de mise à mort. DoT natifs et dégâts de classe sont éligibles une seule fois ; les procs d’équipement et les restitutions ne le sont pas. Contre un boss sans renfort, le bonus vaut zéro.

La fin de rencontre reste la mort du groupe principal. Le jeu n’impose pas le détour par chaque renfort : une course au chef reste une solution valide. Éliminer un auxiliaire soigneur doit seulement permettre de gagner plus tôt.

### E. `guard_only_multiplier` — Fracture

Avec garde `g`, dégât natif final `d`, multiplicateur de garde `m` :

`garde de base = min(g,d)` ; `supplément = min(g - garde de base, garde de base × (m-1))` ; `dégât PV = max(0,d-g)`.

Soustraire à la garde les deux premiers montants ; appliquer aux PV seulement le dernier. **Le supplément ne devient jamais du dégât PV.** Exemple garde100, coup70, multiplicateur2 : garde détruite, zéro dégât PV ; pas40 PV de débordement. Coup130 sur garde100 : garde détruite et30 PV, comme sans Fracture. Une dissipation native retire toujours la garde sans créer de bonus Fracture. Pas de vulnérabilité générique après rupture.

### F. `recover_aura_loss` — Reprise

À chaque perte réelle de PV due à `aura` uniquement, ajouter `perte × recoverFraction` à une réserve, sans dépasser `perPulseMaxHpFraction × PVmax`. À la fin du pas, si le porteur vit et si son délai interne est prêt, restituer un soin secondaire plafonné par les PV manquants, la réserve et le reliquat du plafond glissant des30 dernières secondes. Le délai démarre seulement si un soin utile est rendu. Soustraire de la réserve ce qui est rendu ; le surplus au plafond de réserve est perdu.

Pas de sur-soin, pas de soin d’un allié, pas de crédit sur un dégât évité par immunité. Set4 :75 % du dégât d’aura pris, réserve/soin au plus8 % PV, délai 6 s, soins utiles au plus30 % PV sur30 s. Gemme :45 %, réserve5 %, délai 8 s, plafond20 % PV/30 s. Reprise ne fonctionne pas sur érosion, lourds, charge ou dégât volontaire. Un soutien ne multiplie pas cette restitution avec son passif.

## 4. Priorité de cible préparée avant le combat

Ajouter un réglage optionnel du plan, pas une nouvelle action : `targetPriority: chief | adds_first | unguarded_first`. Défaut `chief`, compatible avec les combats existants. À chaque nouvelle **action native** (pas chaque sous-projectile), choisir une cible présente et vivante :

- `chief` : groupe principal, puis ordre d’apparition stable ;
- `adds_first` : renfort vivant par heure d’arrivée puis identifiant, sinon chef ;
- `unguarded_first` : chef sans garde, sinon chef à la plus faible garde ; les renforts ne sont pas une cible prioritaire de ce mode.

Définir un ordre stable pour les cibles secondaires de zone, en suivant d’abord cette priorité puis l’identifiant. Un renfort futur ne doit jamais être sélectionné. Réévaluer au prochain lancer après apparition/mort/changement de garde ; aucune sélection manuelle en combat.

**Traqueur :** changer volontairement de cible ne transporte pas gratuitement un Angle. Il reste attaché à sa proie et n’est exploitable qu’en revenant sur elle avant expiration ; seul le report à la mort déjà prévu garde son fonctionnement. Les effets et DoT restent sur leur cible. Ceci évite que la nouvelle priorité crée des Angles infinis.

## 5. Danger et fureur des dégâts périodiques

Au commit étudié, `enemyDamageScale` agit sur coups, charges et érosion ; **pas sur l’aura**. La fureur n’agit que sur coups et charges. Une route qui monte uniquement les options existantes favorise donc artificiellement certaines défenses à grande profondeur.

Choix proposé : centraliser le calcul `danger × fureur` pour chaque source entrante, y compris aura/érosion, en conservant leurs autres propriétés. Les périodiques contournent toujours armure et boucliers natifs si c’est la règle actuelle. Une fois ce changement fait, **ne pas prémultiplier leurs valeurs dans le YAML** : le danger doit être appliqué exactement une fois. Garde et soin ennemis suivent déjà `enemyHpScale` ; ne pas les multiplier deux fois non plus.

Conserver l’essai actuel de Claude en régression, puis refaire les seuils de fureur : étendre la fureur à l’aura peut avancer les murs de ces zones. La variante de données avec fureur livrée dans le ZIP est un point de départ mesuré au normal, pas une calibration finie de la route.

## 6. Contrôle : viser le danger sans annuler le boss

`rules.enemy.onceWeakenTarget: heavy` existe déjà et figure dans la proposition native. Il réserve les affaiblissements « une attaque » pour une charge ou un lourd quand la rencontre en possède. Les affaiblissements de durée continuent d’agir pendant leur durée ; le ralentissement ne touche que les attaques ordinaires.

Correction conseillée de consommation : si plusieurs affaiblissements « une attaque » coexistent, consommer uniquement celui effectivement retenu, les autres gardant leur expiration. Ne pas allonger implicitement la durée d’un jeton pour attendre indéfiniment une charge.

**Extension facultative, hors catalogue initial :** état télégraphié `charging` pendant3 s avant une charge fixe, avec les mêmes horaires pour tous. Il permettrait plus tard une gemme de Pression conditionnelle. Je ne livre pas cette gemme maintenant : elle n’aurait pas encore deux zones vérifiées où être la meilleure, et ajouter des Ruptures sans mesurer les passifs du Sigillaire/Enclumier serait risqué. Les six familles proposées n’en dépendent pas.

## 7. Vérifications indispensables à l’implémentation

Vérifier les formules ci-dessus, puis les cas de conservation : aucune restitution Interstice supérieure à la perte éligible stockée ; aucun supplément Fracture en PV ; aucun soin Reprise sur dommage évité ou létal ; aucune double consommation set/gemme/consommable ; mêmes résultats graine/données/plan identiques. Vérifier chaque fois petit coup, énorme coup, deux ennemis au même pas, mort du porteur, mort du chef, expiration exacte et combat suivant.

Pour Repli, vérifier336 à PV2800 et672 à PV5600, sans plafonnement caché par `secondaryShield=1,6 P`. Pour le groupe, chaque effet reste propre à son porteur et toutes les métriques séparent utile/demandé. Ces tests ciblent des risques de boucle ou de double comptage ; ils ne remplacent pas la recherche de builds.
