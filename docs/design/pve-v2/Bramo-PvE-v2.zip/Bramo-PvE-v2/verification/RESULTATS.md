# Essais réellement exécutés

Source : moteur TypeScript du jeu au commit c120336036ae2ee6bff6d9f509ede1d26c892094. Date :22 octobre2026. Scripts portables fournis dans ce dossier ; ils importent directement les sources du dépôt. Aucun simulateur de combat indépendant.

## Compatibilité

-12 rencontres validées par le schéma actuel, sans aucun champ inconnu retiré silencieusement.
-Construction du contenu combat :0 erreur de référence.
-6 familles couvrant exactement2 zones chacune ;24 fiches d’effet structurées et six gemmes majeures. Ce contrôle vérifie les données, pas leur exécution.
-Variante avec fureur également validée au format natif.

## Base, sans ensemble ni rework de classe

Répertoire80 ; plans \*\_advised actuellement dans le jeu, sans nouvelle recherche ; P100, PV2800+3 % de repas ; trois potions8 % sous35 % des PV, délai90 s. Danger1. Douze graines par case (1000 à1011), soit1296 combats. **0 échec ; 0 case sous90 %.**

La plage des temps est celle des médianes par voie ; elle n’est pas un intervalle de confiance. Certains plans génériques restent plus lents que80 s face aux gardes ; les temps de référence sont mesurés séparément.

| Zone | Pire succès des9 voies | Temps des3 DPS | Temps des9 voies | Groupe équilibré témoin | Seuil de fureur proposé |
|---|---:|---:|---:|---:|---:|
| La Chaussée des lanternes | 100 % | 68,5–72,4 s | 68,5–82,6 s | 79,3 s | 87,18 s |
| Les Fossés gris | 100 % | 40,8–46,1 s | 40,8–53,3 s | 47,3 s | 51,98 s |
| La Cour des trois coups | 100 % | 40,6–45,5 s | 40,6–51,3 s | 46,3 s | 50,88 s |
| Les Vergers de verre | 100 % | 40,6–45,5 s | 40,6–51,3 s | 46,3 s | 50,88 s |
| Le Cloître des balances | 100 % | 56,5–69,3 s | 56,5–84,0 s | 69,3 s | 76,18 s |
| Les Fours de recuit | 100 % | 42,3–47,0 s | 42,3–53,8 s | 47,8 s | 52,53 s |
| La Salle des échos | 100 % | 66,0–71,3 s | 66,0–85,3 s | 69,3 s | 76,18 s |
| Le Gué des plaies | 100 % | 40,6–45,5 s | 40,6–51,3 s | 46,3 s | 50,88 s |
| La Chambre aux deux sceaux | 100 % | 59,3–69,5 s | 59,3–87,0 s | 68,5 s | 75,35 s |
| Les Terrasses de la vigie | 100 % | 42,3–47,0 s | 42,3–53,8 s | 47,8 s | 52,53 s |
| L’Atelier des mauvais jours | 100 % | 53,3–59,5 s | 53,3–67,8 s | 60,0 s | 66,00 s |
| Le Belvédère des trois vents | 100 % | 42,3–47,0 s | 42,3–53,8 s | 47,6 s | 52,39 s |

Au normal de ce témoin seulement, Trempe-Rouge est le plus rapide de sa classe dans12/12 zones, Tue-Bête dans11/12, Fulgurant dans12/12. Les combinaisons équipées au mur peuvent modifier ce classement : le critère final reste à rejouer.

## Référence de groupe et variante avec fureur

Référence : Trempe-Rouge + Fulgurant + Glyphiste + Sigillaire ; plans de groupe pour le soutien ; P100 par membre ; mêmes repas/potions ; PV ennemis×4, cadence ordinaire×4, ciblage réparti. Douze graines (3000 à3011) par zone :144 combats, **0 échec**. Les délais YAML sont1,1 fois la médiane de ce groupe au danger1, arrondis au centième.

Puis les9 voies solo sont rejouées sur cette variante avec12 autres graines (4000 à4011) :1296 combats, **0 échec**. Ce contrôle porte sur le normal, sans ensemble et sans Repli revalorisé. Il ne vérifie ni les714 compositions, ni le donjon enchaîné, ni la difficulté profonde. Les seuils devront être recalibrés après correction de la fureur des périodiques et intégration des outils.

Total : **2736 combats dans le moteur partagé**. Fichiers bruts : fumee-moteur.json et reference-fureur.json ; tous les résultats, y compris une défaite si elle apparaît lors d’un rejeu, sont conservés.

## Ce qui n’a PAS été validé

| Acceptation demandée | Statut |
|---|---|
| Outil adapté :+25 % de mur dans au moins6 zones | Non mesuré : effets absents du moteur |
| Chaque set/gemme premier dans2 zones | Matrice cible livrée ; pas un résultat |
| Toutes les voies atteignent×1,5 avec meilleur outil | Non mesuré |
| DPS le plus rapide dans la majorité des zones équipées | Témoin normal favorable ; verdict final non mesuré |
| Compositions1–4, écart d’équipement≤10 % | À rejouer ; ancien rapport4 DPS à+15 % |
| Courbe réelle du premier circuit | Statistiques d’objets à brancher en5a |
| Rendement de butin/h entre compositions | À mesurer avec coûts et échecs |

Le dossier n’annonce donc pas que ces critères sont tenus. Il fournit les données, contrats et sorties de référence nécessaires pour mesurer les échecs de la prochaine itération.
