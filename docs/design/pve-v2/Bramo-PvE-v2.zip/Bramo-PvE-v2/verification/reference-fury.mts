/** Produit une variante native avec fureur depuis une référence mesurée par fight() du jeu. */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
const repo=path.resolve(process.argv[2]??process.cwd());
const folder=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const require=createRequire(path.join(repo,'sim/package.json'));const {parse,stringify}=require('yaml');
const read=(p:string)=>parse(fs.readFileSync(path.join(folder,p),'utf8'));
const {patchCombat}=await import(pathToFileURL(path.join(repo,'sim/src/load.ts')).href);
const {readRawContent}=await import(pathToFileURL(path.join(repo,'packages/shared/src/node/index.ts')).href);
const {buildCombatContent}=await import(pathToFileURL(path.join(repo,'packages/shared/src/combat/content.ts')).href);
const {encountersFileSchema}=await import(pathToFileURL(path.join(repo,'packages/shared/src/schemas/combat.ts')).href);
const {fight}=await import(pathToFileURL(path.join(repo,'packages/shared/src/combat/engine.ts')).href);
const patch=read('sim/proposals/zones-v2/combat.yaml');const raw=readRawContent(path.join(repo,'data'));
const built=buildCombatContent(patchCombat(raw.combat,patch),(raw.classes as any[]).map(c=>c.id));assert.deepEqual(built.errors,[]);
const combat=built.combat!;const members=['red_temper','fulgurant','glyphkeeper','sigilbinder'];
const median=(xs:number[])=>{const a=[...xs].sort((a,b)=>a-b);return a.length%2?a[a.length>>1]:(a[a.length/2-1]+a[a.length/2])/2;};
const setups=members.map((id,i)=>{const p=combat.plans[`${id}_group`]??combat.plans[`${id}_advised`];return {id:`p${i+1}`,classId:p.class,pathId:id,weapon:p.weapon,plan:p.levels['80'],stats:{maxHp:2884},beneficiary:combat.paths[id].role==='support'?'lowest':'self',potions:{count:3,heal:.08,below:.35,cooldown:90}}});
const references:any[]=[];const referenceRuns:any[]=[];const furyRuns:any[]=[];
for(const e of patch.encounters){
 const rs=Array.from({length:12},(_,i)=>{const r=fight(combat,setups,e,{seed:3000+i,enemyHpScale:4,enemyAttackRateScale:4,targeting:'rotate'});return {encounter:e.id,seed:3000+i,win:r.win,time:r.time,fallen:r.team.filter((p:any)=>!p.alive).length}});
 referenceRuns.push(...rs);assert(rs.every(r=>r.win),`Référence échoue : ${e.id}`);
 const ref=median(rs.map(r=>r.time));const after=Math.round(ref*1.1*100)/100;
 references.push({encounter:e.id,party:members,referenceMedianSeconds:ref,enrageAfterSeconds:after,perSecond:.10});
 e.enrage={after,perSecond:.10};
}
assert.deepEqual(encountersFileSchema.parse(patch.encounters),patch.encounters);
patch.note='Variante de fureur GPT v2 : seuil1,1×médiane du groupe équilibré au danger1. Données natives, sans effets d’équipement. Profondeur et fureur périodique nécessitent les extensions décrites.';
const furyDir=path.join(folder,'sim/proposals/zones-v2-fury');fs.mkdirSync(furyDir,{recursive:true});fs.writeFileSync(path.join(furyDir,'combat.yaml'),stringify(patch,{lineWidth:110}));
// Vérification indépendante des graines de référence ; ce n’est pas une recherche de builds.
for(const [id,p] of Object.entries(combat.paths) as any){const plan=combat.plans[`${id}_advised`];for(const e of patch.encounters)for(let seed=4000;seed<4012;seed++){
 const r=fight(combat,[{id:'p1',classId:p.class,pathId:id,weapon:plan.weapon,plan:plan.levels['80'],stats:{maxHp:2884},potions:{count:3,heal:.08,below:.35,cooldown:90}}],e,{seed});
 furyRuns.push({path:id,encounter:e.id,seed,win:r.win,time:r.time,hpRatio:r.team[0].hpRatio});
}}
const out={kind:'native_reference_and_fury_smoke',status:'equipment_not_active_periodic_fury_not_corrected',config:{level:80,danger:1,stats:'P100, PV2800+3 % repas',potions:'3 ×8 %, seuil35 %, délai90 s',referenceSeeds:'3000..3011',soloCheckSeeds:'4000..4011',scale:'Référence4 joueurs : HP×4, cadence×4, rotate ; solo : HP×1, cadence×1'},references,summary:{referenceRuns:referenceRuns.length,referenceFailures:referenceRuns.filter(r=>!r.win).length,soloRuns:furyRuns.length,soloFailures:furyRuns.filter(r=>!r.win).length},referenceRuns,soloRuns:furyRuns};
fs.writeFileSync(path.join(folder,'verification/reference-fureur.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({summary:out.summary,references},null,2));
