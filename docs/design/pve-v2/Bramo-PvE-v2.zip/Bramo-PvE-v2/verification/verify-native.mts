/** Validation et fumée dans le moteur du jeu. Aucun moteur de combat propre au dossier. */
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
const repo=path.resolve(process.argv[2]??process.cwd());
const folder=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const require=createRequire(path.join(repo,'sim/package.json'));
const {parse}=require('yaml');
const schema=await import(pathToFileURL(path.join(repo,'packages/shared/src/schemas/combat.ts')).href);
const {patchCombat}=await import(pathToFileURL(path.join(repo,'sim/src/load.ts')).href);
const {readRawContent}=await import(pathToFileURL(path.join(repo,'packages/shared/src/node/index.ts')).href);
const {buildCombatContent}=await import(pathToFileURL(path.join(repo,'packages/shared/src/combat/content.ts')).href);
const {fight}=await import(pathToFileURL(path.join(repo,'packages/shared/src/combat/engine.ts')).href);
const read=(p:string)=>parse(fs.readFileSync(path.join(folder,p),'utf8'));
const patch=read('sim/proposals/zones-v2/combat.yaml');
// Les schémas courants retirent silencieusement les champs inconnus : vérifier la conservation exacte.
const encounters=schema.encountersFileSchema.parse(patch.encounters);
assert.deepEqual(encounters,patch.encounters,'Un champ des rencontres a été retiré par zod.');
assert.deepEqual(Object.keys(patch).sort(),['encounters','note','rules']);
assert.equal(new Set(encounters.map((e:any)=>e.id)).size,12);
for(const e of encounters){assert(!e.windows||e.windows.open<=e.windows.period);assert(!e.guard||e.guard.duration<=e.guard.period);}
const raw=readRawContent(path.join(repo,'data'));
const built=buildCombatContent(patchCombat(raw.combat,patch),(raw.classes as any[]).map(c=>c.id));
assert.deepEqual(built.errors,[]);
const combat=built.combat!;
const catalog=read('design/equipements-situation.yaml');
assert.equal(catalog.families.length,6);
const assigned:number[]=[];
for(const f of catalog.families){
 assert.equal(f.zones.length,2);assigned.push(...f.zones);
 assert.deepEqual(f.setBonuses.map((b:any)=>b.pieces),[2,3,4]);
 for(const effect of [...f.setBonuses.map((b:any)=>b.effect),f.majorGem.effect]){
   for(const key of ['id','trigger','condition','operation','parameters','internalCooldownSeconds','cap','stacking'])assert(key in effect,`${effect.id}: ${key}`);
   assert(effect.internalCooldownSeconds>=0);
 }
}
assert.deepEqual(assigned.sort((a,b)=>a-b),Array.from({length:12},(_,i)=>i+1));
const median=(xs:number[])=>{const a=[...xs].sort((a,b)=>a-b);return a.length?a.length%2?a[a.length>>1]:(a[a.length/2-1]+a[a.length/2])/2:null;};
const rows:any[]=[];const runs:any[]=[];
for(const [pathId,p] of Object.entries(combat.paths) as any){
 const plan=combat.plans[`${pathId}_advised`];
 for(const enc of encounters){
  const cases=[];
  for(let seed=1000;seed<1012;seed++){
   const r=fight(combat,[{id:'p1',classId:p.class,pathId,weapon:plan.weapon,plan:plan.levels['80'],stats:{maxHp:2800*1.03},potions:{count:3,heal:.08,below:.35,cooldown:90}}],enc,{seed});
   const one={path:pathId,encounter:enc.id,seed,win:r.win,time:r.time,hpRatio:r.team[0].hpRatio,potions:r.team[0].metrics.potions??0};
   cases.push(one);runs.push(one);
  }
  rows.push({path:pathId,encounter:enc.id,winRate:cases.filter(r=>r.win).length/cases.length,medianTime:median(cases.filter(r=>r.win).map(r=>r.time)),medianHp:median(cases.map(r=>r.hpRatio))});
 }
}
const out={sourceCommit:'c120336036ae2ee6bff6d9f509ede1d26c892094',kind:'native_engine_smoke_only',status:'equipment_affinities_not_tested',config:{level:80,seeds:'1000..1011',opening:combat.rules.opening,preparation:'Repas +3 % PV, 3 potions de 8 % PV sous 35 %, délai 90 s',power:100,maxHpBeforeMeal:2800,enemyDanger:1,enemyHpScale:1,gear:'none',trackerRework:'not_active',enrage:'none_in_base_encounters'},validation:{encounters:12,unknownEncounterFieldsRemoved:0,combatContentErrors:0,families:6,structuredEffects:24},summary:{runs:runs.length,failures:runs.filter(r=>!r.win).length,rowsBelow90:rows.filter(r=>r.winRate<.9).length},rows,runs};
fs.writeFileSync(path.join(folder,'verification/fumee-moteur.json'),JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify({validation:out.validation,summary:out.summary,byZone:encounters.map((e:any)=>({id:e.id,minWinRate:Math.min(...rows.filter(r=>r.encounter===e.id).map(r=>r.winRate)),medianTimes:rows.filter(r=>r.encounter===e.id).map(r=>[r.path,r.medianTime])}))},null,2));
